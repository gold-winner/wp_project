<?php

/**
 * @param string $type
 * @return string[]
 */
function graphinaDiviColors($type = 'color')
{
    if ($type === 'gradientColor') {
        return ['#6C25FB', '#3499FF', '#ff7179', '#654ae8', '#f8576f', '#31317a', '#fe6f7e', '#7D02EB', '#E02828', '#D56767', '#26A2D6', '#6C25FB', '#ff7179', '#654ae8', '#f8576f', '#31317a', '#fe6f7e', '#7D02EB', '#E02828', '#D56767', '#26A2D6', '#6C25FB', '#ff7179', '#654ae8', '#f8576f', '#31317a', '#fe6f7e', '#7D02EB', '#E02828', '#D56767', '#26A2D6', '#6C25FB', '#ff7179', '#654ae8', '#f8576f', '#31317a', '#fe6f7e', '#7D02EB', '#E02828', '#D56767', '#26A2D6'];
    }
    return ['#3499FF', '#3499FF', '#e53efc', '#f9a243', '#46adfe', '#2c80ff', '#e23cfd', '#7D02EB', '#8D5B4C', '#F86624', '#2E294E', '#3499FF', '#e53efc', '#f9a243', '#46adfe', '#2c80ff', '#e23cfd', '#7D02EB', '#8D5B4C', '#F86624', '#2E294E', '#3499FF', '#e53efc', '#f9a243', '#46adfe', '#2c80ff', '#e23cfd', '#7D02EB', '#8D5B4C', '#F86624', '#2E294E', '#e23cfd', '#3499FF', '#e53efc', '#f9a243', '#46adfe', '#2c80ff', '#e23cfd', '#7D02EB', '#8D5B4C', '#F86624', '#2E294E'];
}

/**
 * @param $type
 * @param int $length
 * @return string
 */
function graphinaDiviGenerateRandomString($type, $moduleId)
{
    return $type . '_apex_' . $moduleId;
}

/**
 * @param $type
 * @param int $length
 * @return string
 */
function graphinaDiviGoogleGenerateRandomString($type, $moduleId)
{
    return $type . '_google_' . $moduleId;
}

/**
 * @param $this_ele
 * @param $chartId
 */
function graphinaDiviCommonChartHtml($this_ele, $chartId){
     ?>
    <div class="grahina-divi <?php echo (esc_html($this_ele->props['show_card']) == 'on') ? 'graphina-divi-chart-card' : ''; ?>"    style="background: <?php echo esc_html($this_ele->props['show_card']) =='on'? esc_html($this_ele->props['card_color']) : "none"; ?>">
       <?php  if( esc_html($this_ele->props['show_card']) === 'on' ){?>
        <div class="graphina-divi-title" style="text-align: <?php echo esc_html($this_ele->props['card_title_align']); ?>">
            <h4>
                <?php echo esc_html($this_ele->props['title']); ?>
            </h4>
            <p>
                <?php echo esc_html($this_ele->props['description']); ?>
            </p>
        </div>
        <?php } ?>
        <div style="<?php echo !empty($this_ele->props['element_count']) && in_array($this_ele->props['element_count'], [1, '1']) && $this_ele->type === 'gauge_google' ? 'display: flex; justify-content: center; align-items: center' : '' ?>">
            <div id='<?php echo esc_html($chartId); ?>'></div>
            <div id="loader-chart-icon<?php echo esc_html($chartId); ?>" style="display:none;justify-content: center;align-items: center;">
                <?php echo  wp_kses( apply_filters('graphina_divi_loader_icon', '<div class="double-lines-spinner"></div>'), 'post' ) ; ?>
            </div>
        </div>
    </div>
<?php
}

/**
 * @param $num
 * @param $type
 * @return array
 */
function graphinaDiviRange($num, $type)
{

    $data = [];
    $count = graphinaDiviGetElementCount();
    for ($i = $num; $i <= $count; $i++) {
        if ($type == 'element') {
            $data[] = strval($i);
        }
    }

    return $data;
}


/**
 * @param $type
 * @return array
 */
function get_all_user_names(){
        $users = get_users();

    // Initialize an empty array to store usernames
    $usernames = array();

    // Extract usernames from user objects
    foreach ($users as $user) {
        $usernames[] = $user->user_login;
    }

    return $usernames;


}

function get_all_user_role(){
    $roles = wp_roles();

// Get all role objects
$all_roles = $roles->roles;

// Extract role names from role objects
$role_names = array_keys($all_roles);

return $role_names ;
}


function graphinadatatable_psettings($type){


$field['restricted_content_access'] = array(
    'label' => esc_html__('Restricted Content Access', 'et_builder'),
    'type' => 'select',
    'option_category' => 'basic_option',
    'options' => array(
        'no' => __('No', 'grdi-graphina-divi'),
        'user_role_based' => __('User Role Based Access', 'grdi-graphina-divi'),
        'password_protected'=> __('Password Protected', 'grdi-graphina-divi'), 
        'user_name_based' => __('User Name Based Access', 'grdi-graphina-divi'),  
    ),
    'default'=>'no',
    'toggle_slug' => 'restriction_access_control',
    
);


// Select User Names Field
$field['user_names'] = array(
    'label' => esc_html__('Select User Names', 'et_builder'),
    'type' => 'multiple_checkboxes',
    'options' => get_all_user_names(),
    'option_category' => 'basic_option',
    'toggle_slug' => 'restriction_access_control',
    'show_if' => array(
        'restricted_content_access' => 'user_name_based',
    ),
);

// Select User Roles Field
$field['user_roles'] = array(
    'label' => esc_html__('Select User Roles', 'et_builder'),
    'type' => 'multiple_checkboxes',
    'options' => get_all_user_role(),
    'option_category' => 'basic_option',
    'toggle_slug' => 'restriction_access_control',
    'show_if' => array(
        'restricted_content_access' => 'user_role_based',
    ),
);

// Password Field
$field['password'] = array(
    'label' => esc_html__('Password', 'et_builder'),
    'type' => 'text',
    'option_category' => 'basic_option',
    'toggle_slug' => 'restriction_access_control',
    'show_if' => array(
        'restricted_content_access' => 'password_protected',
    ),
    
);

 return $field;

}

function graphinaDiviChartPlotoptionSetting($type){
    $field = [];

    if (in_array($type, ['column', 'bar', 'mixed', 'distributed_column'])) {
        $field['bar_border_radius']  = array(
            'label'             => __('Border Radius', 'grdi-graphina-divi'),
            'type'              => 'number',
            'option_category'   => 'basic_option',
            'value_type'        => 'int',
            'description'       => __("Border Radius", 'grdi-graphina-divi'),
            'toggle_slug'       => 'main_content',
            'default'  => 5,
        );
        if (in_array($type, ['mixed'])) {
            $field['stroke_line_cap'] = array(
                'label' => __("Stroke Line", 'grdi-graphina-divi'),
                'type' => 'select',
                'toggle_slug' => 'main_content',
                'default' => 'square',
                'options' => array(
                    'square' => __('Square', 'grdi-graphina-divi'),
                    'butt' => __('Butt', 'grdi-graphina-divi'),
                    'round' => __('Round', 'grdi-graphina-divi')
                )
            );
            $field['stroke_dash'] = array(
                'label' => __('Stroke Dash', 'grdi-graphina-divi'),
                'type' => 'number',
                'value_type' => 'int',
                'toggle_slug' => 'main_content',
                'default' => 0
            );
            $field['marker_size'] = array(
                'label' => __('Marker Size', 'grdi-graphina-divi'),
                'type' => 'number',
                'option_category' => 'basic_option',
                'value_type' => 'int',
                'toggle_slug' => 'main_content',
                'default' => 5,
            );
            $field['marker_stroke_width'] = array(
                'label' => __('Marker Width', 'grdi-graphina-divi'),
                'type' => 'number',
                'value_type' => 'int',
                'toggle_slug' => 'main_content',
                'default' => 0
            );
            $field['drop_shadow_enable'] = array(
                'label' => __('Drop Shadow', 'grdi-graphina-divi'),
                'type' => 'select',
                'toggle_slug' => 'main_content',
                'options' => array(
                    'true'  => __('Yes', 'grdi-graphina-divi'),
                    'false' => __('No', 'grdi-graphina-divi'),
                ),
                'default' => 'false',
            );
            $field['drop_shadow_left'] = array(
                'label' => __('Drop Left', 'grdi-graphina-divi'),
                'type' => 'number',
                'toggle_slug' => 'main_content',
                'default' => 0,
                'min' => 0,
                'show_if' => array(
                    'drop_shadow_enable' => 'true'
                )
            );
            $field['drop_shadow_top'] = array(
                'label' => __('Drop Top', 'grdi-graphina-divi'),
                'type' => 'number',
                'toggle_slug' => 'main_content',
                'default' => 0,
                'min' => 0,
                'show_if' => array(
                    'drop_shadow_enable' => 'true'
                )
            );
        }
        if (!in_array($type, ['mixed'])) {
            if ($type === 'distributed_column') {
                $field['bar_direction'] = array(
                    'label'            => __('Direction', 'grdi-graphina-divi'),
                    'type'             => 'select',
                    'option_category'  => 'basic_option',
                    'toggle_slug'     => 'main_content',
                    'options'          => array(
                        'true'  => __('Horizontal', 'grdi-graphina-divi'),
                        'false' => __('Vertical', 'grdi-graphina-divi'),
                    ),
                    'default'         => 'false',
                );
            }

            $field['column_width'] = array(
                'label'             => __('Column Width', 'grdi-graphina-divi'),
                'type'              => 'range',
                'toggle_slug'       => 'main_content',
                'option_category'   => 'basic_option',
                'allowed_units'     => array('px'),
                'range_settings'    => array(
                    'min'  => '0',
                    'max'  => '100',
                    'step' => '1',
                ),
                'default'           => 70,
                'mobile_options'    => true,
                'important' => false
            );
            if ($type !== 'distributed_column') {
                $field['stacked'] = array(
                    'label'            => __('Stacked Columns', 'grdi-graphina-divi'),
                    'type'             => 'select',
                    'option_category'  => 'basic_option',
                    'toggle_slug'     => 'main_content',
                    'options'          => array(
                        'true'  => __('YES', 'grdi-graphina-divi'),
                        'false' => __('NO', 'grdi-graphina-divi'),
                    ),
                    'default'         => 'false',
                );
            }
        }
    }

    if (in_array($type, ['polar'])) {
        $field['fill_color_opacity'] = array(
            'label' => __('Fill Opacity', 'grdi-graphina-divi'),
            'type' => 'range',
            'toggle_slug' => 'plotoptions',
            'option_category' => 'basic_option',
            'range_settings' => array(
                'min' => '0',
                'max' => '1',
                'step' => '0.1',
            ),
            'default' => 0.6,
            'mobile_options' => true,
            'important' => false
        );
        $field['fill_type'] = array(
            'label' => __('Fill Type', 'grdi-graphina-divi'),
            'type' => 'select',
            'option_category' => 'basic_option',
            'toggle_slug' => 'plotoptions',
            'options' => array(
                'solid' => __('Solid', 'grdi-graphina-divi'),
                'gradient' => __('Gradient', 'grdi-graphina-divi'),
            ),
            'default' => 'solid',
        );
        $field['gradient_opacity_from'] = array(
            'label' => __('From Opacity', 'grdi-graphina-divi'),
            'type' => 'range',
            'toggle_slug' => 'plotoptions',
            'option_category' => 'basic_option',
            'range_settings' => array(
                'min' => '0',
                'max' => '1',
                'step' => '0.1',
            ),
            'default' => 0.3,
            'mobile_options' => true,
            'important' => false,
            'show_if' => array(
                'fill_type' => 'gradient'
            )
        );
        $field['gradient_opacity_to'] = array(
            'label' => __('To Opacity', 'grdi-graphina-divi'),
            'type' => 'range',
            'toggle_slug' => 'plotoptions',
            'option_category' => 'basic_option',
            'range_settings' => array(
                'min' => '0',
                'max' => '1',
                'step' => '0.1',
            ),
            'default' => 0.3,
            'mobile_options' => true,
            'important' => false,
            'show_if' => array(
                'fill_type' => 'gradient'
            )
        );
        $field['yaxis_fontsize'] = array(
            'label' => __('Font Size', 'grdi-graphina-divi'),
            'type'  => 'range',
            'toggle_slug' => 'plotoptions',
            'option_category' => 'basic_option',
            'allowed_units' => array('px'),
            'range_settings' => array(
                'min' => '0',
                'max' => '100',
                'step' => '1',
            ),
            'default' => 18,
            'mobile_options' => true,
            'important' => false,
        );
    }


    if (in_array($type, ['radar'])) {
        $field['radar_size'] = array(
            'label' => __('Radar Size', 'grdi-graphina-divi'),
            'type' => 'number',
            'option_category' => 'basic_option',
            'value_type' => 'int',
            'description' => __("Radar Size", 'grdi-graphina-divi'),
            'toggle_slug' => 'plotoptions',
            'default' => 140,
        );
        $field['radar_offset_x'] = array(
            'label' => __('Offset X', 'grdi-graphina-divi'),
            'type' => 'number',
            'option_category' => 'basic_option',
            'value_type' => 'int',
            'description' => __("radar offset Offset-X", 'grdi-graphina-divi'),
            'toggle_slug' => 'plotoptions',
            'default' => 0,
        );
        $field['radar_offset_y'] = array(
            'label' => __('Offset Y', 'grdi-graphina-divi'),
            'type' => 'number',
            'option_category' => 'basic_option',
            'value_type' => 'int',
            'description' => __("radar offset Offset-Y", 'grdi-graphina-divi'),
            'toggle_slug' => 'plotoptions',
            'default' => 0,
        );
        $field['radar_storke_color'] = array(
            'label' => __('Stroke Color', 'grdi-graphina-divi'),
            'type' => 'color-alpha',
            'toggle_slug' => 'plotoptions',
            'mobile_options' => true,
            'sticky' => true,
            'default' => '#e8e8e8',
        );
        $field['radar_storke_fill_color'] = array(
            'label' => __('Stroke Fill Color', 'grdi-graphina-divi'),
            'type' => 'color-alpha',
            'toggle_slug' => 'plotoptions',
            'mobile_options' => true,
            'sticky' => true,
            'default' => '#fff'
        );
        $field['radar_connector_color'] = array(
            'label' => __('Connector Color', 'grdi-graphina-divi'),
            'type' => 'color-alpha',
            'toggle_slug' => 'plotoptions',
            'mobile_options' => true,
            'sticky' => true,
            'default' => '#e8e8e8',
        );
        $field['radar_stroke_width'] = array(
            'label' => __('Stroke Width', 'grdi-graphina-divi'),
            'type' => 'range',
            'toggle_slug' => 'plotoptions',
            'option_category' => 'basic_option',
            'allowed_units' => array('px'),
            'range_settings' => array(
                'min' => '0',
                'max' => '100',
                'step' => '1',
            ),
            'default' => 1,
            'mobile_options' => true,
            'important' => false
        );
        /* fill & plotoptions */
        $field['fill_color_opacity'] = array(
            'label' => __('Fill Opacity', 'grdi-graphina-divi'),
            'type' => 'range',
            'toggle_slug' => 'plotoptions',
            'option_category' => 'basic_option',
            'range_settings' => array(
                'min' => '0',
                'max' => '1',
                'step' => '0.1',
            ),
            'default' => 0.3,
            'mobile_options' => true,
            'important' => false
        );
        $field['fill_type'] = array(
            'label' => __('Fill Type', 'grdi-graphina-divi'),
            'type' => 'select',
            'option_category' => 'basic_option',
            'toggle_slug' => 'plotoptions',
            'options' => array(
                'solid' => __('Solid', 'grdi-graphina-divi'),
                'gradient' => __('Gradient', 'grdi-graphina-divi'),
            ),
            'default' => 'solid',
        );
        $field['gradient_opacity_from'] = array(
            'label' => __('From Opacity', 'grdi-graphina-divi'),
            'type' => 'range',
            'toggle_slug' => 'plotoptions',
            'option_category' => 'basic_option',
            'range_settings' => array(
                'min' => '0',
                'max' => '1',
                'step' => '0.1',
            ),
            'default' => 0.3,
            'mobile_options' => true,
            'important' => false,
            'show_if' => array(
                'fill_type' => 'gradient'
            )
        );
        $field['gradient_opacity_to'] = array(
            'label' => __('To Opacity', 'grdi-graphina-divi'),
            'type' => 'range',
            'toggle_slug' => 'plotoptions',
            'option_category' => 'basic_option',
            'range_settings' => array(
                'min' => '0',
                'max' => '1',
                'step' => '0.1',
            ),
            'default' => 0.3,
            'mobile_options' => true,
            'important' => false,
            'show_if' => array(
                'fill_type' => 'gradient'
            )
        );
        $field['marker_size'] = array(
            'label' => __('Marker Size', 'grdi-graphina-divi'),
            'type' => 'number',
            'option_category' => 'basic_option',
            'value_type' => 'int',
            'description' => __("Marker Size", 'grdi-graphina-divi'),
            'toggle_slug' => 'plotoptions',
            'default' => 5,
        );
        $field['marker_hover_size'] = array(
            'label' => __('Marker Hover Size', 'grdi-graphina-divi'),
            'type' => 'number',
            'option_category' => 'basic_option',
            'value_type' => 'int',
            'description' => __("Marker Size", 'grdi-graphina-divi'),
            'toggle_slug' => 'plotoptions',
            'default' => 10,
        );
    }

    if (in_array($type, ['pie', 'donut', 'radial'])) {
        $field['label_show'] = array(
            'label' => __('Element Show', 'grdi-graphina-divi'),
            'type' => 'select',
            'option_category' => 'basic_option',
            'default' => 'true',
            'options' => array(
                'true' => __('Show', 'grdi-graphina-divi'),
                'false' => __('Hide', 'grdi-graphina-divi'),
            ),
            'toggle_slug' => 'plotoptions',

        );
        $field['value_show'] = array(
            'label' => __('Value Show', 'grdi-graphina-divi'),
            'type' => 'select',
            'option_category' => 'basic_option',
            'default' => 'true',
            'options' => array(
                'true' => __('Show', 'grdi-graphina-divi'),
                'false' => __('Hide', 'grdi-graphina-divi'),
            ),
            'toggle_slug' => 'plotoptions',
            'show_if' => array(
                'label_show' => 'true'
            )
        );
        $field['total_show'] = array(
            'label' => __('Title Show', 'grdi-graphina-divi'),
            'type' => 'select',
            'option_category' => 'basic_option',
            'default' => 'true',
            'options' => array(
                'true' => __('Show', 'grdi-graphina-divi'),
                'false' => __('Hide', 'grdi-graphina-divi'),
            ),
            'toggle_slug' => 'plotoptions',
            'show_if' => array(
                'label_show' => 'true'
            )
        );
        if (in_array($type, [ 'radial' ])) {
            $field['title_value_show'] = array(
                'label' => __('Title and Value Show', 'grdi-graphina-divi'),
                'type' => 'select',
                'option_category' => 'basic_option',
                'default' => 'true',
                'options' => array(
                    'true' => __('Show', 'grdi-graphina-divi'),
                    'false' => __('Hide', 'grdi-graphina-divi'),
                ),
                'description' => __('For Initial Value Show','grdi-graphina-divi'),
                'toggle_slug' => 'plotoptions',
                'show_if' => array(
                    'label_show' => 'true', 
                )
            );
        }
        $field['total_title'] = array(
            'label' => __('Title', 'grdi-graphina-divi'),
            'type' => 'text',
            'dynamic_content' => 'text',
            'option_category' => 'basic_option',
            'description' => __('Input your desired heading here.', 'simp-simple-extension'),
            'toggle_slug' => 'plotoptions',
            'default' => 'Total',
            'show_if' => array(
                'total_show' => 'true',
                'label_show' => 'true',
            )
        );
        if ($type == 'radial') {
            $field['total_title']['show_if']['title_value_show'] = 'true';
        }
        $field['label_fontsize'] = array(
            'label' => __('Font Size', 'grdi-graphina-divi'),
            'type' => 'range',
            'toggle_slug' => 'plotoptions',
            'option_category' => 'basic_option',
            'allowed_units' => array('px'),
            'range_settings' => array(
                'min' => '0',
                'max' => '100',
                'step' => '1',
            ),
            'default' => 18,
            'mobile_options' => true,
            'important' => false,
            'show_if' => array(
                'total_show' => 'true',
                'label_show' => 'true',
            )
        );
        $field['labelvalue_fontsize'] = array(
            'label' => __('Value Font Size', 'grdi-graphina-divi'),
            'type' => 'range',
            'toggle_slug' => 'plotoptions',
            'option_category' => 'basic_option',
            'allowed_units' => array('px'),
            'range_settings' => array(
                'min' => '0',
                'max' => '100',
                'step' => '1',
            ),
            'default' => 15,
            'mobile_options' => true,
            'important' => false,
            'show_if' => array(
                'total_show' => 'true',
                'label_show' => 'true',
            )
        );
        $field['label_color'] = array(
            'label' => __('Label Color', 'grdi-graphina-divi'),
            'type' => 'color-alpha',
            'toggle_slug' => 'plotoptions',
            'description' => __('Label Color', 'grdi-graphina-divi'),
            'mobile_options' => true,
            'default' => '#000000',
            'sticky' => true,
            'show_if' => array(
                'label_show' => 'true',
            )
        );
        if (in_array($type, ['radial'])) {
            $field['total_color'] = array(
                'label' => __('Total Color', 'grdi-graphina-divi'),
                'type' => 'color-alpha',
                'toggle_slug' => 'plotoptions',
                'description' => __('Toal Color', 'grdi-graphina-divi'),
                'mobile_options' => true,
                'default' => '#000000',
                'sticky' => true,
                'show_if' => array(
                    'total_show' => 'true',
                    'label_show' => 'true'
                )
            );
        }
        
        if (!in_array($type, ['radial'])) {
            $field['total_show_always'] = array(
                'label' => __('Show Total Always', 'grdi-graphina-divi'),
                'type' => 'select',
                'default' => 'true',
                'options' => array(
                    'true' => __('Show', 'grdi-graphina-divi'),
                    'false' => __('Hide', 'grdi-graphina-divi'),
                ),
                'toggle_slug' => 'plotoptions',
                'show_if' => array(
                    'total_show' => 'true',
                    'label_show' => 'true',
                )
            );
        }
        if ($type == 'radial') {
            $field['chart_angle'] = array(
                'label' => __('Chart Angle', 'grdi-graphina-divi'),
                'type' => 'select',
                'option_category' => 'basic_option',
                'toggle_slug' => 'plotoptions',
                'options' => array(
                    'circle' => __('Circle', 'grdi-graphina-divi'),
                    'semi_circle' => __('Semi Circle', 'grdi-graphina-divi'),
                    'custom' => __('Custom', 'grdi-graphina-divi'),
                ),
                'default' => 'circle',
            );
            $field['chart_start_angle'] = array(
                'label' => __('Start Angle', 'grdi-graphina-divi'),
                'type' => 'range',
                'toggle_slug' => 'plotoptions',
                'option_category' => 'basic_option',
                'range_settings' => array(
                    'min' => '0',
                    'max' => '315',
                    'step' => '5',
                ),
                'default' => '0',
                'mobile_options' => true,
                'important' => false,
                'show_if' => array(
                    'chart_angle' => 'custom'
                )
            );
            $field['chart_end_angle'] = array(
                'label' => __('End Angle', 'grdi-graphina-divi'),
                'type' => 'range',
                'toggle_slug' => 'plotoptions',
                'option_category' => 'basic_option',
                'range_settings' => array(
                    'min' => '45',
                    'max' => '360',
                    'step' => '5',
                ),
                'default' => '270',
                'mobile_options' => true,
                'important' => false,
                'show_if' => array(
                    'chart_angle' => 'custom'
                )
            );
            $field['datalabel_label_prefix'] = array(
                'label'             => __('Label Prefix', 'grdi-graphina-divi'),
                'type'              => 'text',
                'dynamic_content' => 'text',
                'option_category'   => 'basic_option',
                'toggle_slug'       => 'plotoptions',
                'default'           => '',
                'description'       => __("It will display after page refresh", 'grdi-graphina-divi'),
                'show_if' => [
                    'label_show' => 'true'
                ]
            );
            $field['datalabel_label_postfix'] = array(
                'label'             => __('Label Postfix', 'grdi-graphina-divi'),
                'type'              => 'text',
                'dynamic_content' => 'text',
                'option_category'   => 'basic_option',
                'toggle_slug'       => 'plotoptions',
                'default'           => '',
                'description'       => __("It will display after page refresh", 'grdi-graphina-divi'),
                'show_if' => [
                    'label_show' => 'true'
                ]
            );
            $field['datalabel_thousand_seperator_enable'] = array(
                'label' => __('Format number', 'grdi-graphina-divi'),
                'type' => 'select',
                'option_category' => 'basic_option',
                'toggle_slug' => 'plotoptions',
                'options' => array(
                    'on' => __('Yes', 'grdi-graphina-divi'),
                    'off' => __('No', 'grdi-graphina-divi'),
                ),
                'show_if'         => array(
                    'label_show' => 'true'
                ),
                'default' => 'off',
            );
            $field['datalabel_decimal_point'] = array(
                'label' => __('Decimal Point', 'grdi-graphina-divi'),
                'type' => 'number',
                'option_category' => 'basic_option',
                'value_type' => 'int',
                'show_if'         => array(
                    'label_show' => 'true'
                ),
                'toggle_slug' => 'plotoptions',
                'default' => 0,
            );
        }
    }

    if ($type === 'bubble') {

        $field['fill_opacity'] = array(
            'label' => __('Fill Opacity', 'grdi-graphina-divi'),
            'type' => 'number',
            'option_category' => 'basic_option',
            'value_type' => 'float',
            'default' => 1,
            'min' => 0,
            'max' => 1,
            'toggle_slug' => 'plotoptions',
        );

        $field['stroke_width'] = array(
            'label' => __('Stroke Width', 'grdi-graphina-divi'),
            'type' => 'number',
            'option_category' => 'basic_option',
            'value_type' => 'int',
            'default' => 0,
            'min' => 0,
            'toggle_slug' => 'plotoptions',
        );

        $field['stroke_color'] = array(
            'label' => __('Stroke Color', 'grdi-graphina-divi'),
            'type' => 'color-alpha',
            'toggle_slug' => 'plotoptions',
            'description' => __('Stroke Color', 'grdi-graphina-divi'),
            'mobile_options' => true,
            'default' => '#000000',
            'sticky' => true,
        );

        $field['three_d_chart'] = array(
            'label' => __('3D chart', 'grdi-graphina-divi'),
            'type' => 'select',
            'default' => 'false',
            'options' => array(
                'true' => __('Show', 'grdi-graphina-divi'),
                'false' => __('Hide', 'grdi-graphina-divi'),
            ),
            'toggle_slug' => 'plotoptions',
        );
    }
    return $field;
}


/**
 * @param $type
 * @return array[]
 */
function graphinadiviCardSetting($type)
{
    //general chart settings
    $field['show_card'] = array(
            'label'            => __( 'Show Card', 'grdi-graphina-divi' ),
            'type'             => 'yes_no_button',
            'option_category'  => 'configuration',
            'options'          => array(
                'on'  => __('Yes', 'grdi-graphina-divi' ),
                'off' => __('No', 'grdi-graphina-divi' ),
            ),
            'toggle_slug'      => 'card_setting',
            'default' => 'on',
            'mobile_options'   => true,
            'hover'            => 'tabs',
        );

    $field['title'] = array(
        'label'           => __('Title', 'grdi-graphina-divi'),
        'type'            => 'text',
        'dynamic_content' => 'text',
        'option_category' => 'basic_option',
        'description'     => __('Input your desired heading here.', 'simp-simple-extension'),
        'toggle_slug'     => 'card_setting',
        'default'         => ucfirst(str_replace('_', ' ', $type)) . ' Chart',
        'show_if' => [
            'show_card' => 'on'
        ]
    );

    $field['description'] = array(
        'label'           => __('Description', 'grdi-graphina-divi'),
        'type'            => 'textarea',
        'dynamic_content' => 'text',
        'option_category' => 'basic_option',
        'toggle_slug'     => 'card_setting',
        'default'         => 'This is chart Description demo text',
        'show_if' => [
            'show_card' => 'on'
        ]
    );

    $field['card_title_align'] = array(
        'label'    => __('Text Align', 'et_builder'),
        'type'            => 'text_align',
        'options'         => et_builder_get_text_orientation_options(array('justified')),
        'toggle_slug'     => 'card_setting',
        'default'  => $type === 'counter' ? 'center' : 'left',
        'mobile_options'  => true,
        'show_if'         => array(
            'show_card'     => 'on'
        )
    );

    $field['card_color'] = array(
        'label'    => __('Card Background Color', 'et_builder'),
        'type'            => 'color-alpha',
        'toggle_slug'     => 'card_setting',
        'default'  => 'RGBA(255,255,255,0)',
        'mobile_options'  => true,
        'show_if'         => array(
            'show_card'     => 'on'
        )
    );

    return $field;
}

/**
 * @param $type
 * @return array[]
 */
function graphinaDiviDataLabelSetting($type)
{
    $field['data_label'] = array(
        'label'            => __('Data Label', 'grdi-graphina-divi'),
        'type'             => 'select',
        'option_category'  => 'basic_option',
        'default'          => 'false',
        'options'          => array(
            'true'  => __('Show', 'grdi-graphina-divi'),
            'false' => __('Hide', 'grdi-graphina-divi'),
        ),
        'toggle_slug'     => 'datalabel',
    );
    $field['datalabel_fontsize'] =  array(
        'label'             => __('Font Size', 'grdi-graphina-divi'),
        'type'              => 'range',
        'toggle_slug'       => 'datalabel',
        'option_category'   => 'basic_option',
        'allowed_units'     => array('px'),
        'range_settings'    => array(
            'min'  => '0',
            'max'  => '100',
            'step' => '1',
        ),
        'default'        => 18,
        'mobile_options' => true,
        'important'      => false,
        'show_if'        => array(
            'data_label' => 'true'
        )
    );
    $field['datalabel_color'] = array(
        'label'          => __('Data Text Color', 'grdi-graphina-divi'),
        'type'           => 'color-alpha',
        'toggle_slug'    => 'datalabel',
        'mobile_options' => true,
        'sticky'         => true,
        'default'        => '#000000',
        'show_if'        => array(
            'data_label' => 'true'
        )
    );
    $condition = array(
        'data_label' => 'true'
    );
    if (in_array($type, ['pie', 'donut'])) {
        $field['datalabel_percentage']  = array(
            'label'            => __('Show background', 'grdi-graphina-divi'),
            'type'             => 'select',
            'option_category'  => 'basic_option',
            'default'          => 'true',
            'options'          => array(
                'true' => __('Percentage', 'grdi-graphina-divi'),
                'false'  => __('Value', 'grdi-graphina-divi'),
            ),
            'description'       => __("It will display after page refresh", 'grdi-graphina-divi'),
            'toggle_slug'     => 'datalabel',
            'show_if'        => array(
                'data_label' => 'true'
            )
        );
        $condition['datalabel_percentage'] = 'false';
    }
    $field['datalabel_label_prefix'] =  array(
        'label'             => __('Label Prefix', 'grdi-graphina-divi'),
        'type'              => 'text',
        'dynamic_content' => 'text',
        'option_category'   => 'basic_option',
        'toggle_slug'       => 'datalabel',
        'default'           => '',
        'description'       => __("It will display after page refresh", 'grdi-graphina-divi'),
        'show_if' => $condition
    );
    $field['datalabel_label_postfix'] = array(
        'label'             => __('Label Postfix', 'grdi-graphina-divi'),
        'type'              => 'text',
        'dynamic_content' => 'text',
        'option_category'   => 'basic_option',
        'toggle_slug'       => 'datalabel',
        'default'           => '',
        'description'       => __("It will display after page refresh", 'grdi-graphina-divi'),
        'show_if' => $condition
    );
    if (in_array($type, ['bar', 'column', 'mixed', 'distributed_column'])) {
        $field['bar_datalabel_position'] = array(
            'label'            => __('Datalabel Position', 'grdi-graphina-divi'),
            'type'             => 'select',
            'option_category'  => 'basic_option',
            'toggle_slug'     => 'datalabel',
            'options'          => array(
                'top'  => __('Top', 'grdi-graphina-divi'),
                'bottom' => __('Bottom', 'grdi-graphina-divi'),
                'center' => __('Center', 'grdi-graphina-divi'),
            ),
            'default'         => $type === 'mixed' ? 'top' : 'center',
            'show_if'        => array(
                'data_label' => 'true'
            )
        );
    }

    if (in_array($type, ['pie', 'donut'])) {
        $field['datalabel_showbg']  = array(
            'label'            => __('Show background', 'grdi-graphina-divi'),
            'type'             => 'select',
            'option_category'  => 'basic_option',
            'default'          => 'false',
            'options'          => array(
                'true'  => __('Show', 'grdi-graphina-divi'),
                'false' => __('Hide', 'grdi-graphina-divi'),
            ),
            'toggle_slug'     => 'datalabel',
            'show_if'        => array(
                'data_label' => 'true'
            )
        );
        $field['datalabel_color'] = array(
            'label'          => __('Datalabel Color', 'grdi-graphina-divi'),
            'type'           => 'color-alpha',
            'toggle_slug'    => 'datalabel',
            'mobile_options' => true,
            'sticky'         => true,
            'default'        => '#000000',
            'show_if' => [
                'data_label' => 'true',
                'datalabel_showbg' => 'true'
            ]
        );
        $field['datalabel_bodercolor'] = array(
            'label'          => __('Border color', 'grdi-graphina-divi'),
            'type'           => 'color-alpha',
            'toggle_slug'    => 'datalabel',
            'mobile_options' => true,
            'sticky'         => true,
            'default'        => 'red',
            'show_if' => [
                'data_label' => 'true',
                'datalabel_showbg' => 'true'
            ]
        );
    }
    $field['datalabel_thousand_seperator_enable'] = array(
        'label' => __('Format number', 'grdi-graphina-divi'),
        'type' => 'select',
        'option_category' => 'basic_option',
        'toggle_slug' => 'datalabel',
        'options' => array(
            'on' => __('Yes', 'grdi-graphina-divi'),
            'off' => __('No', 'grdi-graphina-divi'),
        ),
        'show_if' => $condition,
        'default' => 'off',
    );
    $field['datalabel_decimal_point'] = array(
        'label' => __('Decimal Point', 'grdi-graphina-divi'),
        'type' => 'number',
        'option_category' => 'basic_option',
        'value_type' => 'int',
        'show_if'         => array(
            'data_label' => 'true',
        ),
        'toggle_slug' => 'datalabel',
        'default' => 0,
    );

    return $field;
}


/**
 * @param $type
 * @return array[]
 */
function graphinaDiviLegendSetting($type)
{
    $field = [
        /* legend */
        'legend_show'  => array(
            'label'            => __('Legend', 'grdi-graphina-divi'),
            'type'             => 'select',
            'option_category'  => 'basic_option',
            'default'          => 'true',
            'options'          => array(
                'true'  => __('Show', 'grdi-graphina-divi'),
                'false' => __('Hide', 'grdi-graphina-divi'),
            ),
            'toggle_slug'     => 'legend',
        ),
        'legend_position'  => array(
            'label' => __('Position', 'grdi-graphina-divi'),
            'type'  => 'select',
            'option_category'  => 'basic_option',
            'options'          => array(
                'top'    => __('Top', 'grdi-graphina-divi'),
                'bottom' => __('Bottom', 'grdi-graphina-divi'),
                'left'   => __('Left', 'grdi-graphina-divi'),
                'right'  => __('Right', 'grdi-graphina-divi'),
            ),
            'default'  => 'bottom',
            'toggle_slug' => 'legend',
            'show_if'         => array(
                'legend_show'     => 'true'
            )
        ),
        'legend_alignment' => array(
            'label'           => __('Legend Alignment', 'divi_flash'),
            'type'            => 'text_align',
            'options'         => et_builder_get_text_orientation_options(array('justified')),
            'toggle_slug'     => 'legend',
            'default'  => 'center',
            'mobile_options'  => true,
            'show_if'         => array(
                'legend_show'     => 'true'
            )
        ),
        'lenend_color' => array(
            'label'          => __('Legend Color', 'grdi-graphina-divi'),
            'type'           => 'color-alpha',
            'toggle_slug'    => 'legend',
            'description'    => __('Legend Color', 'grdi-graphina-divi'),
            'mobile_options' => true,
            'default'        => '#000000',
            'sticky'         => true,
            'show_if'         => array(
                'legend_show'     => 'true'
            )
        ),
        'lenend_fontsize' => array(
            'label'             => __('Font Size', 'grdi-graphina-divi'),
            'type'              => 'range',
            'toggle_slug'       => 'legend',
            'option_category'   => 'basic_option',
            'allowed_units'     => array('px'),
            'range_settings'    => array(
                'min'  => '0',
                'max'  => '100',
                'step' => '1',
            ),
            'default'           => 18,
            'mobile_options'    => true,
            'important' => false,
            'show_if'         => array(
                'legend_show'     => 'true'
            )
        )
    ];
    return $field;
}


/**
 * @param $type
 * @return array[]
 */
function graphinaDiviAnimationSetting($type)
{
    $field = [
        // Animation
        'animation'  => array(
            'label'            => __('Animation', 'grdi-graphina-divi'),
            'type'             => 'select',
            'option_category'  => 'basic_option',
            'toggle_slug'     => 'main_content',
            'options'          => array(
                'true'  => __('Show', 'grdi-graphina-divi'),
                'false' => __('Hide', 'grdi-graphina-divi'),
            ),
            'default' => 'false',
        ),
        'animation_speed' => array(
            'label'             => __('Speed', 'grdi-graphina-divi'),
            'type'              => 'number',
            'option_category'   => 'basic_option',
            'value_type'        => 'int',
            'description'       => __("Animation speed", 'grdi-graphina-divi'),
            'toggle_slug'       => 'main_content',
            'default'         => 800,
            'show_if'         => array(
                'animation' => 'true',
            ),
        )
    ];

    return $field;
}

/**
 * @param $type
 * @return array[]
 */
function graphinaDiviChartToolTip($type)
{
    $field = [
        'tooltip'  => array(
            'label'  => __('Tooltip', 'grdi-graphina-divi'),
            'type'   => 'select',
            'option_category'  => 'basic_option',
            'toggle_slug'      => 'tooltip',
            'options' => array(
                'true'  => __('Show', 'grdi-graphina-divi'),
                'false' => __('Hide', 'grdi-graphina-divi'),
            ),
            'default' => 'true',
        ),
        'tooltip_theme'  => array(
            'label'  => __('Theme', 'grdi-graphina-divi'),
            'type'   => 'select',
            'option_category'  => 'basic_option',
            'toggle_slug'      => 'tooltip',
            'options' => array(
                'light'  => __('Light', 'grdi-graphina-divi'),
                'dark' => __('Dark', 'grdi-graphina-divi'),
            ),
            'default' => 'light',
            'show_if' => [
                'tooltip' => 'true'
            ]
        )
    ];
    if ($type === 'heatmap') {
        $field = [
            'tooltip'  => array(
                'label'  => __('Tooltip', 'grdi-graphina-divi'),
                'type'   => 'select',
                'option_category'  => 'basic_option',
                'toggle_slug'      => 'tooltip',
                'options' => array(
                    'true'  => __('Show', 'grdi-graphina-divi'),
                    'false' => __('Hide', 'grdi-graphina-divi'),
                ),
                'default' => 'true',
            ),
            'tooltip_theme'  => array(
                'label'  => __('Theme', 'grdi-graphina-divi'),
                'type'   => 'select',
                'option_category'  => 'basic_option',
                'toggle_slug'      => 'tooltip',
                'options' => array(
                    'light'  => __('Light', 'grdi-graphina-divi'),
                    'dark' => __('Dark', 'grdi-graphina-divi'),
                ),
                'default' => 'light',
                'show_if' => [
                    'tooltip' => 'true'
                ]
            ),
            'tooltip_label_prefix' => array(
                'label'             => __('Prefix', 'grdi-graphina-divi'),
                'type'              => 'text',
                'option_category'  => 'basic_option',
                'toggle_slug'       => 'tooltip',
                'show_if' => [
                    'tooltip' => 'true'
                ]
            ),
            'tooltip_label_postfix' => array(
                'label'             => __('Postfix', 'grdi-graphina-divi'),
                'type'              => 'text',
                'option_category'  => 'basic_option',
                'toggle_slug'       => 'tooltip',
                'default'          => '',
                'show_if' => [
                    'tooltip' => 'true'
                ]
            ),
            'tooltip_decimal_point' => array(
                'label'             => __('Decimal Point', 'grdi-graphina-divi'),
                'type'              => 'number',
                'option_category'   => 'basic_option',
                'value_type'        => 'int',
                'show_if'           => [
                    'tooltip' => 'true',
                ],
                'toggle_slug'       => 'tooltip',
                'default'           => 0,
            ),
            'tooltip_thousand_seperator_enable' => array(
                'label'             => __('Format number', 'grdi-graphina-divi'),
                'type'              => 'select',
                'option_category'   => 'basic_option',
                'toggle_slug'       => 'tooltip',
                'options'           => [
                    'on' => __('Yes', 'grdi-graphina-divi'),
                    'off' => __('No', 'grdi-graphina-divi'),
                ],
                'show_if'           => [
                    'tooltip'           => 'true',
                ],
                'default'           => 'off',
            )
        ];
    }

    return $field;
}


/**
 * @param $type
 * @return array[]
 */
function graphinaDiviChartTitleSetting($type)
{
    $field = [
        // title
        'chart_title' => array(
            'label'           => __('Title', 'grdi-graphina-divi'),
            'type'            => 'text',
            'dynamic_content' => 'text',
            'option_category' => 'basic_option',
            'description'     => __('Add your heading here', 'grdi-graphina-divi'),
            'toggle_slug'     => 'chart_title',
            'default'         => ucfirst(str_replace('_', ' ', $type)) . ' Chart',
        ),
        'chart_title_fontsize' => array(
            'label'             => __('Font Size', 'grdi-graphina-divi'),
            'type'              => 'range',
            'toggle_slug'       => 'chart_title',
            'option_category'   => 'basic_option',
            'allowed_units'     => array('px'),
            'range_settings'    => array(
                'min'  => '0',
                'max'  => '100',
                'step' => '1',
            ),
            'default'           => 18,
            'mobile_options'    => true,
            'important' => false
        ),
        'chart_title_color' => array(
            'label'          => __('Title Color', 'grdi-graphina-divi'),
            'type'           => 'color-alpha',
            'toggle_slug'    => 'chart_title',
            'mobile_options' => true,
            'sticky'         => true,
            'default'        => '#000000',
        ),
        'title_alignment' => array(
            'label'           => __('Title Alignment', 'divi_flash'),
            'type'            => 'text_align',
            'options'         => et_builder_get_text_orientation_options(array('justified')),
            'toggle_slug'     => 'chart_title',
            'default'  => 'left',
            'mobile_options'  => true,
        )
    ];

    return $field;
}


/**
 * @param $type
 * @return array[]
 */
function graphinaDiviToolbarSetting($type)
{
    $field = [
        // toolbar
        'toolbar'  => array(
            'label'            => __('Toolbar', 'grdi-graphina-divi'),
            'type'             => 'select',
            'option_category'  => 'basic_option',
            'toggle_slug'     => 'main_content',
            'options'          => array(
                'true'  => __('Show', 'grdi-graphina-divi'),
                'false' => __('Hide', 'grdi-graphina-divi'),
            ),
            'default'         => 'true',
        ),
        'toolbar_offset_x'             => array(
            'label'             => __('Offset X', 'grdi-graphina-divi'),
            'type'              => 'number',
            'option_category'   => 'basic_option',
            'value_type'        => 'int',
            'description'       => __("Toolbar offset Offset-X", 'grdi-graphina-divi'),
            'toggle_slug'       => 'main_content',
            'default'         => 0,
            'show_if'         => array(
                'toolbar' => 'true',
            ),
        ),
        'toolbar_offset_y'             => array(
            'label'             => __('Offset Y', 'grdi-graphina-divi'),
            'type'              => 'number',
            'option_category'   => 'basic_option',
            'value_type'        => 'int',
            'description'       => __("Toolbar offset Offset-Y", 'grdi-graphina-divi'),
            'toggle_slug'       => 'main_content',
            'default'         => 0,
            'show_if'         => array(
                'toolbar' => 'true',
            ),
        ),
    ];
    return $field;
}


/**
 * @param $type
 * @return array[]
 */
function graphinaDiviChartHeightColorSetting($type)
{
    $field = [
        'chart_id' => array(
            'label'             => __('Chart Unique Id', 'grdi-graphina-divi'),
            'type'              => 'text',
            'value_type'       => 'string',
            'dynamic_content' => 'text',
            'option_category'   => 'basic_option',
            'description'       => __( "Add Unique Chart ID,Every Chart Must Have Unique id <p style='color:red !important;'>A unique ID always starts with a character or an underscore.</p> ", 'grdi-graphina-divi' ),
            'toggle_slug'       => 'main_content',

        ),
        'chart_height'             => array(
            'label'             => __('Chart Height', 'grdi-graphina-divi'),
            'type'              => 'number',
            'option_category'   => 'basic_option',
            'value_type'        => 'int',
            'description'       => __("Add your chart height here", 'grdi-graphina-divi'),
            'toggle_slug'       => 'main_content',
            'default'         => 350,
        ),
        'chart_bg_color'       => array(
            'label'          => __('Chart Background Color', 'grdi-graphina-divi'),
            'type'           => 'color-alpha',
            'default'          => '#FFFFFF',
            'toggle_slug'    => 'main_content',
            'description'    => __('Chart Background Color.', 'grdi-graphina-divi'),
            'mobile_options' => true,
            'sticky'         => true,
            'hover'          => 'tabs',
        ),
    ];

    return $field;
}

function graphinaGoogleHeightWidthSetting($type)
{
    $field = [];
    $field['google_chart_id'] = array(
        'label'             => __('Chart Unique Id', 'grdi-graphina-divi'),
        'type'              => 'text',
        'dynamic_content' => 'text',
        'option_category'   => 'basic_option',
        'description'       => __( "Add Unique Chart ID,Every Chart Must Have Unique id <p style='color:red !important;'>A unique ID always starts with a character or an underscore.</p> ", 'grdi-graphina-divi' ),
        'toggle_slug'       => 'google_main_content',
    );

    $field['google_chart_height'] = array(
        'label'             => __('Chart Height', 'grdi-graphina-divi'),
        'type'              => 'number',
        'option_category'   => 'basic_option',
        'value_type'        => 'int',
        'description'       => __("Add your chart height here", 'grdi-graphina-divi'),
        'toggle_slug'       => 'google_main_content',
        'default'         => 350,
    );

    if (!in_array($type, ['geo_google'])) {
        $field['google_chart_width'] = array(
            'label'  => __('Chart Width', 'grdi-graphina-divi'),
            'type'              => 'number',
            'option_category'   => 'basic_option',
            'value_type'        => 'int',
            'description'       => __("Add your chart width here", 'grdi-graphina-divi'),
            'toggle_slug'       => 'google_main_content',
        );
    }

    return $field;
}

function graphinaDiviGaugeTickSetting()
{
    $field = [];

    $field['minor_ticks'] = array(
        'label' => __('Minor Ticks', 'grdi-graphina-divi'),
        'type'              => 'number',
        'option_category'   => 'basic_option',
        'value_type'        => 'int',
        'toggle_slug'       => 'ticks_settings',
        'default'  => 5,
    );

    $field['major_ticks'] = array(
        'label' => __('Major Ticks', 'grdi-graphina-divi'),
        'type'              => 'textarea',
        'option_category'   => 'basic_option',
        'toggle_slug'       => 'ticks_settings',
        'default'           => '0,50,100,150,200'
    );

    $field['min_ticks'] = array(
        'label' => __('Min Ticks', 'grdi-graphina-divi'),
        'type'              => 'range',
        'option_category'   => 'basic_option',
        'toggle_slug'       => 'ticks_settings',
        'range_settings'    => array(
            'min'  => '0',
            'step' => '1',
        ),
        'default'           => 0,
        'mobile_options'    => true,
        'important' => false,
    );

    $field['max_ticks'] = array(
        'label' => __('Max Ticks', 'grdi-graphina-divi'),
        'type'              => 'range',
        'option_category'   => 'basic_option',
        'toggle_slug'       => 'ticks_settings',
        'range_settings'    => array(
            'min'  => '0',
            'step' => '1',
        ),
        'default'           => 200,
        'mobile_options'    => true,
        'important' => false,
    );

    $field['green_color'] = array(
        'label' => __('Green Color', 'grdi-graphina-divi'),
        'type'  => 'color-alpha',
        'option_category' => 'basic_option',
        'toggle_slug'     => 'ticks_settings',
        'mobile_options' => true,
        'sticky'         => true,
        'default'         => '#109618'
    );

    $field['yellow_color'] = array(
        'label' => __('Yellow Color', 'grdi-graphina-divi'),
        'type'  => 'color-alpha',
        'option_category' => 'basic_option',
        'toggle_slug'     => 'ticks_settings',
        'mobile_options' => true,
        'sticky'         => true,
        'default'         => '#FF9900'
    );

    $field['red_color'] = array(
        'label' => __('Red Color', 'grdi-graphina-divi'),
        'type'  => 'color-alpha',
        'option_category' => 'basic_option',
        'toggle_slug'     => 'ticks_settings',
        'mobile_options' => true,
        'sticky'         => true,
        'default'         => '#DC3912'
    );

    $field['green_from'] = array(
        'label' => __('Green From', 'grdi-graphina-divi'),
        'type'  => 'range',
        'option_category'   => 'basic_option',
        'toggle_slug'       => 'ticks_settings',
        'range_settings'    => array(
            'min'  => '0',
            'step' => '1',
        ),
        'default'           => 0,
        'mobile_options'    => true,
        'important' => false,
    );

    $field['green_to'] = array(
        'label' => __('Green To', 'grdi-graphina-divi'),
        'type'  => 'range',
        'option_category'   => 'basic_option',
        'toggle_slug'       => 'ticks_settings',
        'range_settings'    => array(
            'min'  => '0',
            'step' => '1',
        ),
        'default'           => 50,
        'mobile_options'    => true,
        'important' => false,
    );

    $field['yellow_from'] = array(
        'label' => __('Yellow From', 'grdi-graphina-divi'),
        'type'  => 'range',
        'option_category'   => 'basic_option',
        'toggle_slug'       => 'ticks_settings',
        'range_settings'    => array(
            'min'  => '0',
            'step' => '1',
        ),
        'default'           => 50,
        'mobile_options'    => true,
        'important' => false,
    );

    $field['yellow_to'] = array(
        'label' => __('Yellow To', 'grdi-graphina-divi'),
        'type'  => 'range',
        'option_category'   => 'basic_option',
        'toggle_slug'       => 'ticks_settings',
        'range_settings'    => array(
            'min'  => '0',
            'step' => '1',
        ),
        'default'           => 150,
        'mobile_options'    => true,
        'important' => false,
    );

    $field['red_from'] = array(
        'label' => __('Red From', 'grdi-graphina-divi'),
        'type'  => 'range',
        'option_category'   => 'basic_option',
        'toggle_slug'       => 'ticks_settings',
        'range_settings'    => array(
            'min'  => '0',
            'step' => '1',
        ),
        'default'           => 150,
        'mobile_options'    => true,
        'important' => false,
    );

    $field['red_to'] = array(
        'label' => __('Red To', 'grdi-graphina-divi'),
        'type'  => 'range',
        'option_category'   => 'basic_option',
        'toggle_slug'       => 'ticks_settings',
        'range_settings'    => array(
            'min'  => '0',
            'step' => '1',
        ),
        'default'           => 200,
        'mobile_options'    => true,
        'important' => false,
    );

    return $field;
}

/**
 * @param $type
 * @return array
 */
function graphinaDiviChartStrokeGridSetting($type)
{
    $field = [];
    /* grid */
    if (!in_array($type, ['radar', 'polar', 'radial', 'gauge_google'])) {

        $field['grid_line'] = array(
            'label'            => __('Show Line', 'grdi-graphina-divi'),
            'type'             => 'select',
            'option_category'  => 'basic_option',
            'toggle_slug'     => 'main_content',
            'options'          => array(
                'true'  => __('Show', 'grdi-graphina-divi'),
                'false' => __('Hide', 'grdi-graphina-divi'),
            ),
            'default' => 'true',
        );

        $field['grid_line_color'] = array(
            'label'          => __('Line Color', 'grdi-graphina-divi'),
            'type'           => 'color-alpha',
            'toggle_slug'    => 'main_content',
            'description'    => __('This will change  y-axis line color.', 'grdi-graphina-divi'),
            'mobile_options' => true,
            'sticky'         => true,
            'default'          => '#000000',
            'show_if'         => array(
                'grid_line' => 'true',
            ),
        );
    }
    if (in_array($type, ['line', 'area', 'scatter', 'heatmap', 'radar', 'polar', 'radial', 'mixed'])) {
        if (in_array($type, ['radar', 'radial'])) {
            $field['stroke'] = array(
                'label'            => __('Strock', 'grdi-graphina-divi'),
                'type'             => 'select',
                'option_category'  => 'basic_option',
                'toggle_slug'      => 'main_content',
                'options'          => array(
                    'true'   => __('Show', 'grdi-graphina-divi'),
                    'false'  => __('Hide', 'grdi-graphina-divi'),
                ),
                'default'         => 'true',
            );
        } else {
            //stroke
            if (!in_array($type, ['polar', 'scatter', 'heatmap'])) {
                $field['stroke'] = array(
                    'label'            => __('Stroke', 'grdi-graphina-divi'),
                    'type'             => 'select',
                    'option_category'  => 'basic_option',
                    'toggle_slug'      => 'main_content',
                    'options'          => array(
                        'smooth'   => __('Smooth', 'grdi-graphina-divi'),
                        'straight' => __('Straight', 'grdi-graphina-divi'),
                        'stepline' => __('Stepline', 'grdi-graphina-divi'),
                    ),
                    'default'         => 'smooth',
                );
            }
        }
        if ($type !== 'scatter') {
            $field['strock_width'] = array(
                'label'             => __('Stroke Width', 'grdi-graphina-divi'),
                'type'              => 'range',
                'toggle_slug'       => 'main_content',
                'option_category'   => 'basic_option',
                'range_settings'    => array(
                    'min'  => '0',
                    'max'  => '100',
                    'step' => '1',
                ),
                'default'           => in_array($type, ['polar']) ? 3 : 8,
                'mobile_options'    => true,
                'important' => false
            );
        }


        if (in_array($type, ['polar'])) {
            $field['stroke_color'] = array(
                'label'          => __('Stroke Color', 'grdi-graphina-divi'),
                'type'           => 'color-alpha',
                'option_category'  => 'basic_option',
                'toggle_slug'    => 'main_content',
                'mobile_options' => true,
                'sticky'         => true,
                'default'  => '#696969',
            );
            $field['connector_color'] = array(
                'label'          => __('Connector Color', 'grdi-graphina-divi'),
                'type'           => 'color-alpha',
                'option_category'  => 'basic_option',
                'toggle_slug'    => 'main_content',
                'mobile_options' => true,
                'sticky'         => true,
                'default'  => '#000000',
            );
        }

        //stroke rounded
        if (in_array($type, ['radial'])) {
            $field['chart_is_stroke_rounded'] = array(
                'label'             => __('Stroke Rounded', 'grdi-graphina-divi'),
                'type'   => 'select',
                'option_category'  => 'basic_option',
                'toggle_slug'      => 'main_content',
                'options' => array(
                    'true'  => __('Show', 'grdi-graphina-divi'),
                    'false' => __('Hide', 'grdi-graphina-divi'),
                ),
                'default' => 'false',
            );
        }
    }

    return $field;
}


/**
 * @param $type
 * @return array[]
 */
function graphinaDiviXaxisSetting($type)
{
    $field = [
        'xaxis_label'          => array(
            'label'            => __('X-axis Label', 'grdi-graphina-divi'),
            'type'             => 'select',
            'option_category'  => 'basic_option',
            'toggle_slug'     => 'xaxis',
            'options'          => array(
                'true'  => __('Show', 'grdi-graphina-divi'),
                'false' => __('Hide', 'grdi-graphina-divi'),
            ),
            'default'         => 'true',
        ),
        'xaxis_position' => array(
            'label'            => __('X-axis Position', 'grdi-graphina-divi'),
            'type'             => 'select',
            'option_category'  => 'basic_option',
            'show_if'         => array(
                'xaxis_label' => 'true',
            ),
            'options'          => array(
                'top'  => __('Top', 'grdi-graphina-divi'),
                'bottom' => __('Bottom', 'grdi-graphina-divi'),
            ),
            'default'         => 'bottom',
            'toggle_slug'     => 'xaxis',
        ),
        'xaxis_tooltip'          => array(
            'label'            => __('Tooltip', 'grdi-graphina-divi'),
            'type'             => 'select',
            'option_category'  => 'basic_option',
            'toggle_slug'     => 'xaxis',
            'options'          => array(
                'true'  => __('Show', 'grdi-graphina-divi'),
                'false' => __('Hide', 'grdi-graphina-divi'),
            ),
            'default'         => 'false',
        ),
        'xaxis_crosshair'          => array(
            'label'            => __('Crosshairs', 'grdi-graphina-divi'),
            'type'             => 'select',
            'option_category'  => 'basic_option',
            'toggle_slug'     => 'xaxis',
            'options'          => array(
                'true'  => __('Show', 'grdi-graphina-divi'),
                'false' => __('Hide', 'grdi-graphina-divi'),
            ),
            'default'         => 'false',
        ),
        'xaxis_label_rotate'          => array(
            'label'            => __('Label Rotate', 'grdi-graphina-divi'),
            'type'             => 'select',
            'option_category'  => 'basic_option',
            'toggle_slug'     => 'xaxis',
            'options'          => array(
                'true'  => __('Yes', 'grdi-graphina-divi'),
                'false' => __('No', 'grdi-graphina-divi'),
            ),
            'default'         => 'true',
            'show_if'         => array(
                'xaxis_label' => 'true',
            ),
        ),
        'xaxis_label_rotate_deg' => array(
            'label'             => __('Rotate Degree', 'grdi-graphina-divi'),
            'type'              => 'range',
            'toggle_slug'       => 'xaxis',
            'option_category'   => 'basic_option',
            'range_settings'    => array(
                'min'  => '-360',
                'max'  => '360',
                'step' => '1',
            ),
            'default'           => -45,
            'mobile_options'    => true,
            'important' => false,
            'show_if'         => array(
                'xaxis_label' => 'true',
                'xaxis_label_rotate' => 'true',
            ),
        ),
        'xaxis_offset_x' => array(
            'label'             => __('Offset X', 'grdi-graphina-divi'),
            'type'              => 'number',
            'option_category'   => 'basic_option',
            'value_type'        => 'int',
            'description'       => __("Offset X", 'grdi-graphina-divi'),
            'toggle_slug'       => 'xaxis',
            'default'           => 0,
            'show_if'         => array(
                'xaxis_label' => 'true',
            ),
        ),
        'xaxis_offset_y' => array(
            'label'             => __('Offset Y', 'grdi-graphina-divi'),
            'type'              => 'number',
            'option_category'   => 'basic_option',
            'value_type'        => 'int',
            'description'       => __("Offset Y", 'grdi-graphina-divi'),
            'toggle_slug'       => 'xaxis',
            'default'           => 0,
            'show_if'         => array(
                'xaxis_label' => 'true',
            ),
        ),
        'xaxis_label_fontsize' => array(
            'label'             => __('Font Size', 'grdi-graphina-divi'),
            'type'              => 'range',
            'toggle_slug'       => 'xaxis',
            'option_category'   => 'basic_option',
            'allowed_units'     => array('px'),
            'range_settings'    => array(
                'min'  => '0',
                'max'  => '100',
                'step' => '1',
            ),
            'default'           => 18,
            'mobile_options'    => true,
            'important' => false,
            'show_if'         => array(
                'xaxis_label' => 'true',
            ),
        ),
        'xaxis_label_color' => array(
            'label'          => __('Label Color', 'grdi-graphina-divi'),
            'type'           => 'color-alpha',
            'toggle_slug'    => 'xaxis',
            'description'    => __('Xaxis label color', 'grdi-graphina-divi'),
            'mobile_options' => true,
            'sticky'         => true,
            'default'  => '#000000',
            'show_if'         => array(
                'xaxis_label' => 'true',
            ),
        ),
        'xaxis_label_prefix' => array(
            'label'             => __('Label Prefix', 'grdi-graphina-divi'),
            'type'              => 'text',
            'dynamic_content' => 'text',
            'option_category'   => 'basic_option',
            'toggle_slug'       => 'xaxis',
            'default'           => '',
            'description'       => __("It will display after page refresh", 'grdi-graphina-divi'),
            'show_if'         => array(
                'xaxis_label' => 'true',
            ),
        ),
        'xaxis_label_postfix' => array(
            'label'             => __('Label Postfix', 'grdi-graphina-divi'),
            'type'              => 'text',
            'dynamic_content' => 'text',
            'option_category'   => 'basic_option',
            'toggle_slug'       => 'xaxis',
            'default'           => '',
            'description'       => __("It will display after page refresh", 'grdi-graphina-divi'),
            'show_if'         => array(
                'xaxis_label' => 'true',
            ),
        )
    ];

    if ($type == 'radar') {
        unset($field['xaxis_position']);
        unset($field['xaxis_offset_y']);
        unset($field['xaxis_offset_x']);
        unset($field['xaxis_label_rotate']);
        unset($field['xaxis_label_rotate_deg']);
    }
    if (in_array($type, ['bubble','bar'])) {
        unset($field['xaxis_tooltip']);
        unset($field['xaxis_crosshair']);
    }
    if ($type === 'bar') {
        $field['xaxis_thousand_seperator_enable'] = array(
            'label' => __('Format number', 'grdi-graphina-divi'),
            'type' => 'select',
            'option_category' => 'basic_option',
            'toggle_slug' => 'xaxis',
            'options' => array(
                'on' => __('Yes', 'grdi-graphina-divi'),
                'off' => __('No', 'grdi-graphina-divi'),
            ),
            'show_if'         => array(
                'xaxis_label' => 'true',
            ),
            'default' => 'off',
        );
        $field['xaxis_decimal_point'] = array(
            'label' => __('Decimal Point', 'grdi-graphina-divi'),
            'type' => 'number',
            'option_category' => 'basic_option',
            'value_type' => 'int',
            'show_if'         => array(
                'xaxis_label' => 'true',
            ),
            'toggle_slug' => 'xaxis',
            'default' => 0,
        );
    }
    return $field;
}


/**
 * @param $type
 * @return array[]
 */
function graphinaDiviYaxisSetting($type)
{
    $field = [
        // Y axis.
        'yaxis_label'          => array(
            'label'            => __('Y-axis Label', 'grdi-graphina-divi'),
            'type'             => 'select',
            'option_category'  => 'basic_option',
            'toggle_slug'     => 'yaxis',
            'options'          => array(
                'true'  => __('Show', 'grdi-graphina-divi'),
                'false' => __('Hide', 'grdi-graphina-divi'),
            ),
            'default'         => 'true',
        ),
        'yaxis_min_max_enable' => array(
            'label' => __('Enable Min/Max', 'grdi-graphina-divi'),
            'type' => 'select',
            'option_category' => 'basic_option',
            'description'       => 'description',
            'toggle_slug' => 'yaxis',
            'options' => array(
                'true' => __('Show', 'grdi-graphina-divi'),
                'false' => __('Hide', 'grdi-graphina-divi'),
            ),
            'default' => 'false',
        ),
        'yaxis_min' => array(
            'label' => __('Min', 'grdi-graphina-divi'),
            'type' => 'number',
            'option_category' => 'basic_option',
            'value_type' => 'int',
            'description' => __("Min value of Y", 'grdi-graphina-divi'),
            'toggle_slug' => 'yaxis',
            'default' => 0,
            'show_if' => array(
                'yaxis_min_max_enable' => 'true',
            ),
        ),
        'yaxis_max' => array(
            'label' => __('Max', 'grdi-graphina-divi'),
            'type' => 'number',
            'option_category' => 'basic_option',
            'value_type' => 'int',
            'description' => __("Max value of Y", 'grdi-graphina-divi'),
            'toggle_slug' => 'yaxis',
            'default' => 500,
            'show_if' => array(
                'yaxis_min_max_enable' => 'true',
            ),
        ),
        'yaxis_tooltip'          => array(
            'label'            => __('Tooltip', 'grdi-graphina-divi'),
            'type'             => 'select',
            'option_category'  => 'basic_option',
            'toggle_slug'     => 'yaxis',
            'options'          => array(
                'true'  => __('Show', 'grdi-graphina-divi'),
                'false' => __('Hide', 'grdi-graphina-divi'),
            ),
            'default' => 'false',
        ),
        'yaxis_datalabel'          => array(
            'label'            => __('Y axis Datalabel', 'grdi-graphina-divi'),
            'type'             => 'select',
            'option_category'  => 'basic_option',
            'toggle_slug'     => 'yaxis',
            'options'          => array(
                'true'  => __('Show', 'grdi-graphina-divi'),
                'false' => __('Hide', 'grdi-graphina-divi'),
            ),
            'default' => 'true',
        ),
        'yaxis_label_rotate'          => array(
            'label'            => __('Label Rotate', 'grdi-graphina-divi'),
            'type'             => 'select',
            'option_category'  => 'basic_option',
            'toggle_slug'     => 'yaxis',
            'options'          => array(
                'true'  => __('Yes', 'grdi-graphina-divi'),
                'false' => __('No', 'grdi-graphina-divi'),
            ),
            'default'         => 'false',
        ),
        'yaxis_label_rotate_deg' => array(
            'label'             => __('Rotate Degree', 'grdi-graphina-divi'),
            'type'              => 'range',
            'toggle_slug'       => 'yaxis',
            'option_category'   => 'basic_option',
            'range_settings'    => array(
                'min'  => '-360',
                'max'  => '360',
                'step' => '1',
            ),
            'default'           => 0,
            'mobile_options'    => true,
            'important' => false,
            'show_if'         => array(
                'yaxis_label_rotate' => 'true',
            ),
        ),
        'yaxis_offset_x' => array(
            'label'             => __('Offset X', 'grdi-graphina-divi'),
            'type'              => 'number',
            'option_category'   => 'basic_option',
            'value_type'        => 'int',
            'description'       => __("Offset X", 'grdi-graphina-divi'),
            'toggle_slug'       => 'yaxis',
            'default'           => 0,
        ),
        'yaxis_offset_y' => array(
            'label'             => __('Offset Y', 'grdi-graphina-divi'),
            'type'              => 'number',
            'option_category'   => 'basic_option',
            'value_type'        => 'int',
            'description'       => __("Offset Y", 'grdi-graphina-divi'),
            'toggle_slug'       => 'yaxis',
            'default'           => 0,
        ),
        // 'yaxis_enable_min_max_range'          => array(
        //     'label'            => __('Label Rotate', 'grdi-graphina-divi'),
        //     'type'             => 'select',
        //     'option_category'  => 'basic_option',
        //     'toggle_slug'     => 'yaxis',
        //     'options'          => array(
        //         'true'  => __('Yes', 'grdi-graphina-divi'),
        //         'false' => __('No', 'grdi-graphina-divi'),
        //     ),
        //     'default'         => 'false',
        // ),

        // 'yaxis_min' => array(
        //     'label'             => __('Min', 'grdi-graphina-divi'),
        //     'type'              => 'number',
        //     'option_category'   => 'basic_option',
        //     'value_type'        => 'int',
        //     'description'       => __("Min", 'grdi-graphina-divi'),
        //     'toggle_slug'       => 'yaxis',
        //     'default'           => 0,
        //     'show_if'         => array(
        //         'yaxis_enable_min_max_range' => 'true',
        //     ),
        // ),
        // 'yaxis_max' => array(
        //     'label'             => __('Max', 'grdi-graphina-divi'),
        //     'type'              => 'number',
        //     'option_category'   => 'basic_option',
        //     'value_type'        => 'int',
        //     'description'       => __("Max", 'grdi-graphina-divi'),
        //     'toggle_slug'       => 'yaxis',
        //     'default'           => 0,
        //     'show_if'         => array(
        //         'yaxis_enable_min_max_range' => 'true',
        //     ),
        // ),


        'yaxis_label_fontsize' => array(
            'label'             => __('Font Size', 'grdi-graphina-divi'),
            'type'              => 'range',
            'toggle_slug'       => 'yaxis',
            'option_category'   => 'basic_option',
            'allowed_units'     => array('px'),
            'range_settings'    => array(
                'min'  => '0',
                'max'  => '100',
                'step' => '1',
            ),
            'default'           => 18,
            'mobile_options'    => true,
            'important' => false
        ),
        'yaxis_label_color' => array(
            'label'          => __('Label Color', 'grdi-graphina-divi'),
            'type'           => 'color-alpha',
            'toggle_slug'    => 'yaxis',
            'description'    => __('yaxis label color', 'grdi-graphina-divi'),
            'mobile_options' => true,
            'default'          => '#000000',
            'sticky'         => true,
        ),
        'yaxis_label_prefix' => array(
            'label'             => __('Label Prefix', 'grdi-graphina-divi'),
            'type'              => 'text',
            'dynamic_content' => 'text',
            'option_category'   => 'basic_option',
            'show_if' => [
                'yaxis_datalabel' => 'true'
            ],
            'toggle_slug'       => 'yaxis',
            'default'           => '',
            'description'       => __("It will display after page refresh", 'grdi-graphina-divi'),
        ),
        'yaxis_label_postfix' => array(
            'label'             => __('Label Postfix', 'grdi-graphina-divi'),
            'type'              => 'text',
            'dynamic_content' => 'text',
            'option_category'   => 'basic_option',
            'show_if' => [
                'yaxis_datalabel' => 'true'
            ],
            'toggle_slug'       => 'yaxis',
            'default'           => '',
            'description'       => __("It will display after page refresh", 'grdi-graphina-divi'),
        ),
        'yaxis_thousand_seperator_enable'          => array(
            'label'            => __('Format number', 'grdi-graphina-divi'),
            'type'             => 'select',
            'option_category'  => 'basic_option',
            'toggle_slug'     => 'yaxis',
            'options'          => array(
                'on'  => __('Yes', 'grdi-graphina-divi'),
                'off' => __('No', 'grdi-graphina-divi'),
            ),
            'show_if' => [
                'yaxis_datalabel' => 'true'
            ],
            'default'         => 'off',
        ),
        'yaxis_decimal_point' => array(
            'label'             => __('Decimal Point', 'grdi-graphina-divi'),
            'type'              => 'number',
            'option_category'   => 'basic_option',
            'value_type'        => 'int',
            'show_if' => [
                'yaxis_datalabel' => 'true'
            ],
            'toggle_slug'       => 'yaxis',
            'default'           => 0,
        ),
    ];
    if ($type == 'heatmap') {
        unset($field['yaxis_decimal_point']);
        unset($field['yaxis_thousand_seperator_enable']);
    }
    if ($type == 'bar') {
        unset($field['yaxis_thousand_seperator_enable']);
        unset($field['yaxis_decimal_point']);
        unset($field['yaxis_tooltip']);
    }
    if ($type == 'radar') {
        unset($field['yaxis_label_rotate']);
        unset($field['yaxis_label_rotate_deg']);
        unset($field['yaxis_offset_y']);
        unset($field['yaxis_offset_x']);
    }
    if ($type == 'radar') {
        unset($field['yaxis_label_rotate']);
        unset($field['yaxis_label_rotate_deg']);
        unset($field['yaxis_offset_y']);
        unset($field['yaxis_offset_x']);
    }
    if($type != 'line'){
    // unset($field['yaxis_min_max_enable']);
    // unset($field['yaxis_max']);
    // unset($field['yaxis_min']);
    }
    
    return $field;
}


/**
 * @param $type
 * @return array[]
 */
function graphinaDiviChartDataSetting($type)
{
    $dynamicDataType = [
        'csv' => __('CSV', 'grdi-graphina-divi'),
        'remote-csv' => __('Remote CSV', 'grdi-graphina-divi'),
        'google-sheet' => __('Google Sheet', 'grdi-graphina-divi'),
        'api' => __('API', 'grdi-graphina-divi'),
        'sql_builder' => __('SQL Builder', 'grdi-graphina-divi'),
        'filter' => __('Data From Wordpress Filter', 'grdi-graphina-divi')
    ];
    if(!function_exists('et_builder_i18n')){
        function et_builder_i18n($str){
            return $str;
        }
    }
    
    $dynamic_data_options = graphina_divi_common_setting_get('dynamic_data_options');
    $dynamic_data_options = !empty($dynamic_data_options) && is_array($dynamic_data_options) ? $dynamic_data_options : [];
    if (!(in_array('csv', $dynamic_data_options))) {
        unset($dynamicDataType['csv']);
    }
    if (!(in_array('remote_csv', $dynamic_data_options))) {
        unset($dynamicDataType['remote-csv']);
    }
    if (!(in_array('googlesheet', $dynamic_data_options))) {
        unset($dynamicDataType['google-sheet']);
    }
    if (!(in_array('api', $dynamic_data_options))) {
        unset($dynamicDataType['api']);
    }
    if (!(in_array('sql_builder', $dynamic_data_options))) {
        unset($dynamicDataType['sql_builder']);
    }
    $externalDatabase = graphina_divi_check_external_database('data');
    $externalDatabase = !empty($externalDatabase) && is_array($externalDatabase) && count($externalDatabase) > 0 ? $externalDatabase : [];
    if (in_array('external_database', $dynamic_data_options) && !empty($externalDatabase)) {
        $dynamicDataType['external_database'] = __('External Database', 'grdi-graphina-divi');
    }

    $dataTypeOption = [
        'manual' => __('Manual', 'grdi-graphina-divi'),
        'dynamic' => __('Dynamic', 'grdi-graphina-divi'),
        'firebase' => __('Firebase', 'grdi-graphina-divi'),
    ];

    if (in_array($type, ['bubble', 'heatmap'])) {
        unset($dynamicDataType['sql_builder']);
        unset($dynamicDataType['external_database']);
    }

    unset($dataTypeOption['firebase']);

    $elementCount = 1;
    $category = 'Jan,Feb,Mar,Apr,May,Jun';
    $seriesData = '40,82,74,11,35,25';

    switch ($type) {
        case 'line':
        case 'area':
        case 'scatter':
        case 'bar':
        case 'column':
        case 'radar':
            $elementCount = 1;
            $category = 'Jan,Feb,Mar,Apr,May,Jun';
            $seriesData = '40,82,74,11,35,25';
            break;
        case 'heatmap':
            $elementCount = 10;
            break;
        case 'pie':
        case 'polar':
        case 'donut':
        case 'radial':
            $elementCount = 6;
            $category = 'Jan,Feb,Mar,Apr,May,Jun';
            $seriesData = '40,82,74,11,35,25';
            break;
        case 'gauge_google':
            $elementCount = 2;
            $category = 'Jan,Feb';
            $seriesData = '40,82';
            break;
        case 'geo_google':
            $category = 'India,Japan,Germany,Canada';
            $seriesData = '40,82,74,11';
            break;
        case 'mixed':
            $elementCount = 3;
            break;
        case 'distributed_column':
            $elementCount = 6;
            break;
        case 'datatable' :
            
    }
    if (!in_array($type, ['counter', 'geo_google', 'table_google'])) {
        $field['element_count'] = array(
            'label' => __('Element Count', 'grdi-graphina-divi'),
            'toggle_slug' => 'chart_data',
            'type' => 'select',
            'mobile_options' => true,
            'default' => $elementCount,
            'options' => graphinaDiviElementCountList(),
            'sticky' => true,
        );

        $field['ajax_reload']  = array(
            'label'            => __('Ajax Reload', 'grdi-graphina-divi'),
            'type'             => 'select',
            'option_category'  => 'basic_option',
            'toggle_slug'     => 'chart_data',
            'description'       => __("It will work not in Editor mode", 'grdi-graphina-divi'),
            'options'          => array(
                'true'  => __('Enable', 'grdi-graphina-divi'),
                'false' => __('Disable', 'grdi-graphina-divi'),
            ),
            'default' => 'false',
            'show_if'         => [
                'data_type' => ['dynamic']
            ]
        );

        $field['ajax_reload_time'] =  array(
            'label'             => __('Set Interval(sec)', 'grdi-graphina-divi'),
            'type'              => 'number',
            'option_category'   => 'basic_option',
            'value_type'        => 'int',
            'description'       => __("On every Set time  data will fetch and chart will get update automatically without page refresh", 'grdi-graphina-divi'),
            'toggle_slug'       => 'chart_data',
            'default'  => 5,
            'custom_attributes' => array(
                'min'  => 5,
                'step' => 5,
            ),
            'show_if'         => [
                'data_type' => ['dynamic'],
                'ajax_reload' => ['true']
            ]
        );
    }
    $field['data_type'] = array(
        'label' => __('DataType', 'grdi-graphina-divi'),
        'type' => 'select',
        'option_category' => 'basic_option',
        'toggle_slug' => 'chart_data',
        'options' => $dataTypeOption,
        'default' => 'manual',
    );
    $field['dynamic_data_type'] = array(
        'label' => __('Dynamic DataType', 'grdi-graphina-divi'),
        'type' => 'select',
        'option_category' => 'basic_option',
        'toggle_slug' => 'chart_data',
        'options' => $dynamicDataType,
        'default' => 'csv',
        'show_if' => [
            'data_type' => ['dynamic']
        ]
    );
    $field['csv_url'] = array(
        'label' => __('Select or Upload CSV', 'grdi-graphina-divi'),
        'type' => 'upload',
        'option_category' => 'basic_option',
        'upload_button_text' => __('Upload an csv'),
        'choose_text' => __('Choose an CSV', 'grdi-graphina-divi'),
        'update_text' => __('Set As CSV', 'grdi-graphina-divi'),
        'data_type' => 'text/csv',
        'description' => sprintf("%s <a style='color:red' href='%s' target='_blank' download>%s</a>",esc_html__("Upload your desired CSV, or type in the URL to the CSV you would like to use. download sample csv from ","grdi-graphina-divi"), GRAPHINA_DIVI_URL . '/sample-file/csv-file/' . $type . '-chart-sample.csv',__("here",'grdi-graphina-divi')),
        'toggle_slug' => 'chart_data',
        'mobile_options' => true,
        'hover' => 'tabs',
        'show_if' => [
            'data_type' => ['dynamic'],
            'dynamic_data_type' => ['csv']
        ]
    );

    $field['googlesheet_url'] = array(
        'label' => __('Enter GoogleSheet Url', 'grdi-graphina-divi'),
        'type' => 'text',
        'option_category' => 'basic_option',
        'dynamic_content' => 'text',
        'show_if' => [
            'data_type' => ['dynamic'],
            'dynamic_data_type' => ['google-sheet']
        ],
        'description' => sprintf("%s <a style='color:red' href='%s' target='_blank' download>%s</a>",esc_html__("Publish googlesheet as csv and enter googlesheet url to use. get sample googlesheet from ","grdi-graphina-divi"), graphinaDiviGetSpreadsheet($type) ,__("here",'grdi-graphina-divi')),
        'toggle_slug' => 'chart_data',
    );

    $field['remote_csv_url'] = array(
        'label' => __('Enter Remote CSV Url', 'grdi-graphina-divi'),
        'type' => 'text',
        'dynamic_content' => 'text',
        'option_category' => 'basic_option',
        'description' => sprintf("%s <a style='color:red' href='%s' target='_blank'>%s</a>",esc_html__("Enter CSV Url you would like to use. download sample csv from  ","grdi-graphina-divi"),  GRAPHINA_DIVI_URL . '/sample-file/csv-file/' . $type . '-chart-sample.csv' ,__("here",'grdi-graphina-divi')),
        'show_if' => [
            'data_type' => ['dynamic'],
            'dynamic_data_type' => ['remote-csv']
        ],
        'toggle_slug' => 'chart_data',
    );
    $field['sql_records_no'] = array(
        'label' => __('Records', 'grdi-graphina-divi'),
        'type' => 'number',
        'option_category' => 'basic_option',
        'default' => '7',
        'show_if' => [
            'data_type' => ['dynamic'],
            'dynamic_data_type' => ['sql_builder']
        ],
        'toggle_slug' => 'chart_data',
    );
    $field['api_url'] = array(
        'label' => __('Enter API Url', 'grdi-graphina-divi'),
        'type' => 'text',
        'option_category' => 'basic_option',
        'dynamic_content' => 'text',
        'description' => sprintf("%s <a style='color:red' href='%s' target='_blank'>%s</a><hr>%s <strong>(example : &user_id={{CURRENT_USER_ID}} <a href='https://apps.iqonic.design/docs/product/graphina-elementor-charts-and-graphs/use-dynamic-data-in-widgets/dynamic_key/' target='_blank'> <span style='color:#93003c'> List of Dynamic key </span> </a> </strong>",esc_html__("Enter Api Url or json file url you would like to use. download sample json file from","grdi-graphina-divi"),  GRAPHINA_DIVI_URL . '/sample-file/json-file/' . $type . '-chart-sample.json' ,__("here",'grdi-graphina-divi'),__("Use Dynamic key in Api url , it will replace key will dynamic value ","grdi-graphina-divi")),
        'show_if' => [
            'data_type' => ['dynamic'],
            'dynamic_data_type' => ['api']
        ],
        'toggle_slug' => 'chart_data',
    );

    $field['authrization_token_enable'] = array(
        'label' => __('Enable API Header Options', 'et_builder'),
        'type' => 'select',
        'option_category' => 'basic_option',
        'options' => array(
            'true' => __('Yes', 'grdi-graphina-divi'),
            'false' => __('No', 'grdi-graphina-divi'),
        ),
        'toggle_slug' => 'chart_data',
        'default' => 'false',
        'show_if' => [
            'data_type' => ['dynamic'],
            'dynamic_data_type' => ['api']
        ],
    );

    $field['api_header_key'] = array(
        'label' => __('Header Key', 'grdi-graphina-divi'),
        'type' => 'text',
        'dynamic_content' => 'text',
        'option_category' => 'basic_option',
        'show_if' => [
            'data_type' => ['dynamic'],
            'dynamic_data_type' => ['api'],
            'authrization_token_enable' => ['true']
        ],
        'toggle_slug' => 'chart_data',
    );

    $field['api_header_token'] = array(
        'label' => __('Header Token', 'grdi-graphina-divi'),
        'type' => 'text',
        'option_category' => 'basic_option',
        'dynamic_content' => 'text',
        'show_if' => [
            'data_type' => ['dynamic'],
            'dynamic_data_type' => ['api'],
            'authrization_token_enable' => 'true'
        ],
        'toggle_slug' => 'chart_data',
    );

    if (!empty($externalDatabase)) {
        $externalDatabaseName = array_keys($externalDatabase);
        $field['external_database_name'] = array(
            'label' => __('Select External Connection', 'grdi-graphina-divi'),
            'type' => 'select',
            'option_category' => 'basic_option',
            'options' => array_combine($externalDatabaseName, $externalDatabaseName),
            'default' => $externalDatabaseName[0],
            'show_if' => [
                'data_type' => ['dynamic'],
                'dynamic_data_type' => ['external_database'],
            ],
            'toggle_slug' => 'chart_data',
        );
        $field['external_database_mode'] = array(
            'label' => __('Select Mode', 'grdi-graphina-divi'),
            'type' => 'select',
            'option_category' => 'basic_option',
            'options' => array(
                'table' => __('Table', 'grdi-graphina-divi'),
            ),
            'default' => 'table',
            'show_if' => [
                'data_type' => ['dynamic'],
                'dynamic_data_type' => ['external_database']
            ],
            'toggle_slug' => 'chart_data',
        );
    }
    foreach ($externalDatabase as $ex) {

        $field['external_database_' . $ex['con_name'] . 'table'] = array(
            'label' => __('Select Table', 'grdi-graphina-divi'),
            'type' => 'select',
            'option_category' => 'basic_option',
            'options' => array_merge(['no_data' => 'Select Table'], graphinaDiviExternalDatabaseTables($ex['con_name'])),
            'default' => 'no_data',
            'show_if' => [
                'data_type' => ['dynamic'],
                'dynamic_data_type' => ['external_database'],
                'external_database_mode' => ['table'],
                'external_database_name' => $ex['con_name']
            ],
            'toggle_slug' => 'chart_data',
        );
    }

    $field['sql_builder_mode'] = array(
        'label' => __('Select Mode', 'grdi-graphina-divi'),
        'type' => 'select',
        'option_category' => 'basic_option',
        'options' => array(
        'mysql_query'  => __( 'SQL-Query', 'grdi-graphina-divi' ),
         'table' => __('Table', 'grdi-graphina-divi'),
        ),
        'default' => 'table',
        'show_if' => [
            'data_type' => ['dynamic'],
            'dynamic_data_type' => ['sql_builder']
        ],
        'toggle_slug' => 'chart_data',
    );
        $field['sql_builder_mysql_query'] = array(
            'label'=> __('please write custom query', 'grdi-graphina-divi'),
            'type' => 'text',
            'default' => 'Enter Query',
            'show_if' => [
                'data_type' => ['dynamic'],
                'dynamic_data_type' => ['sql_builder'],
                'sql_builder_mode' => ['mysql_query']
            ],
            'toggle_slug' => 'chart_data',

        );

    
      



    $field['sql_builder_table'] = array(
        'label' => __('Select Table', 'grdi-graphina-divi'),
        'type' => 'select',
        'option_category' => 'basic_option',
        'options' => array_merge(['no_data' => 'Select Table'], graphinaDiviListDBTables()),
        'default' => 'no_data',
        'show_if' => [
            'data_type' => ['dynamic'],
            'dynamic_data_type' => ['sql_builder'],
            'sql_builder_mode' => ['table','mysql_query']
        ],
        'toggle_slug' => 'chart_data',
    );

    if ($type == 'counter') {
        $field['iq_counter_column'] = array(
            'label' => __('Column', 'grdi-graphina-divi'),
            'type' => 'select',
            'toggle_slug' => 'chart_data',
            'option_category' => 'basic_option',
            'default' => 1,
            'min' => 1,
            'options' => graphinaDiviGetAlphabet(),
            'show_if' => [
                'data_type' => ['dynamic']
            ]
        );

        $field['iq_counter_object_no'] = array(
            'label' => __('Object Number', 'grdi-graphina-divi'),
            'type' => 'number',
            'toggle_slug' => 'chart_data',
            'option_category' => 'basic_option',
            'default' => 1,
            'min' => 1,
            'show_if' => [
                'data_type' => ['dynamic'],
                'counter_operation' => ['none']
            ]
        );

        $field['counter_operation'] = array(
            'label' => __('Select Operation', 'grdi-graphina-divi'),
            'type' => 'select',
            'option_category' => 'basic_option',
            'options' => [
                'none' => __('None', 'grdi-graphina-divi'),
                'sum' => __('Sum', 'grdi-graphina-divi'),
                'avg' => __('Average', 'grdi-graphina-divi'),
                //                'percentage' => 'Percentage','grdi-graphina-divi'),
            ],
            'default' => 'none',
            'show_if' => [
                'data_type' => ['dynamic']
            ],
            'toggle_slug' => 'chart_data',
        );
    } else {
        $field['sql_builder_table_where_condition'] = array(
            'label' => __('Condition Query', 'grdi-graphina-divi'),
            'type' => 'textarea',
            'placeholder' => __('Where column_name = column_value', 'grdi-graphina-divi'),
            'description' => __('Where condition for selected table, Use Double quote( " " ) in condition value To use <strong> < or > this sign Will not work </strong> <hr> Use dynamic key in Query, it will replace key with dynamic value  <strong> (example : user_id={{CURRENT_USER_ID}} <a href="https://apps.iqonic.design/docs/product/graphina-elementor-charts-and-graphs/use-dynamic-data-in-widgets/dynamic_key/" target="_blank"> <span style="color:#93003c"> List of Dynamic key </span> </a>  </strong>', 'grdi-graphina-divi'),
            'label_block' => true,
            'dynamic_content' => 'text',
            'default' => '',
            'show_if' => [
                'data_type' => ['dynamic'],
                'dynamic_data_type' => ['sql_builder', 'external_database'],
            ],
            'toggle_slug' => 'chart_data',
        );
    }

    if ($type != 'counter') {
        $field['sql_builder_table_offset'] = array(
            'label' => __('Offset', 'grdi-graphina-divi'),
            'type' => 'number',
            'default' => 0,
            'value_type' => 'int',
            'custom_attributes' => array(
                'min' => 0,
                'step' => 5,
            ),
            'show_if' => [
                'data_type' => ['dynamic'],
                'dynamic_data_type' => ['sql_builder', 'external_database'],
            ],
            'toggle_slug' => 'chart_data',
        );

        $field['sql_builder_table_limit'] = array(
            'label' => __('Limit', 'grdi-graphina-divi'),
            'type' => 'number',
            'default' => 15,
            'value_type' => 'int',
            'custom_attributes' => array(
                'min' => 0,
                'step' => 5,
            ),
            'show_if' => [
                'data_type' => ['dynamic'],
                'dynamic_data_type' => ['sql_builder', 'external_database'],
            ],
            'toggle_slug' => 'chart_data',
        );


        foreach (graphinaDiviListDBTables() as $key => $value) {

            $columnList = graphinaDiviListDBTablesColumn($key);
            $field['sql_builder_x_axis_column' . $key] = array(
                'label' => __('X-Axis Columns', 'grdi-graphina-divi'),
                'type' => 'select',
                'option_category' => 'basic_option',
                'options' => array_merge(['no_data' => 'Select Column'], $columnList),
                'default' => 'no_data',
                'show_if' => [
                    'data_type' => ['dynamic'],
                    'dynamic_data_type' => ['sql_builder'],
                    'sql_builder_table' => [$value]
                ],
                'toggle_slug' => 'chart_data',
            );
            if (in_array($type, ['pie', 'donut', 'radial', 'polar', 'gauge_google', 'distributed_column'])) {
                $field['sql_builder_y_axis_column' . $key] = array(
                    'label' => __('Y-Axis Columns', 'grdi-graphina-divi'),
                    'type' => 'select',
                    'option_category' => 'basic_option',
                    'options' => array_merge(['no_data' => 'Select Column'], $columnList),
                    'default' => 'no_data',
                    'show_if' => [
                        'data_type' => ['dynamic'],
                        'dynamic_data_type' => ['sql_builder'],
                        'sql_builder_table' => [$key]
                    ],
                    'toggle_slug' => 'chart_data',
                );
            } else {
                $field['sql_builder_y_axis_column' . $key] = array(
                    'label' => __('Y-Axis Columns', 'grdi-graphina-divi'),
                    'type' => 'multiple_checkboxes',
                    'options' => $columnList,
                    'default' => '',
                    'show_if' => [
                        'data_type' => ['dynamic'],
                        'dynamic_data_type' => ['sql_builder'],
                        'sql_builder_table' => [$key]
                    ],
                    'toggle_slug' => 'chart_data',
                );
            }
        }

        foreach ($externalDatabase as $ex) {
            foreach (graphinaDiviExternalDatabaseTables($ex['con_name']) as $key => $value) {
                $columnList = graphinaDiviExternalDatabaseTableColumn($ex['con_name'], $key);
                $field['external_database_' . $ex['con_name'] . '_x_axis_column' . $key] = array(
                    'label' => __('X-Axis Columns', 'grdi-graphina-divi'),
                    'type' => 'select',
                    'option_category' => 'basic_option',
                    'options' => array_merge(['no_data' => 'Select Column'], $columnList),
                    'default' => 'no_data',
                    'show_if' => [
                        'data_type' => ['dynamic'],
                        'dynamic_data_type' => ['external_database'],
                        'external_database_' . $ex['con_name'] . 'table' => [$value]
                    ],
                    'toggle_slug' => 'chart_data',
                );
                if (in_array($type, ['pie', 'donut', 'radial', 'polar', 'gauge_google', 'distributed_column'])) {
                    $field['external_database_' . $ex['con_name'] . '_y_axis_column' . $key] = array(
                        'label' => __('Y-Axis Columns', 'grdi-graphina-divi'),
                        'type' => 'select',
                        'option_category' => 'basic_option',
                        'options' => array_merge(['no_data' => 'Select Column'], $columnList),
                        'default' => 'no_data',
                        'show_if' => [
                            'data_type' => ['dynamic'],
                            'dynamic_data_type' => ['external_database'],
                            'external_database_' . $ex['con_name'] . 'table' => [$value]
                        ],
                        'toggle_slug' => 'chart_data',
                    );
                } else {
                    $field['external_database_' . $ex['con_name'] . '_y_axis_column' . $key] = array(
                        'label' => __('Y-Axis Columns', 'grdi-graphina-divi'),
                        'type' => 'multiple_checkboxes',
                        'options' => $columnList,
                        'default' => '',
                        'show_if' => [
                            'data_type' => ['dynamic'],
                            'dynamic_data_type' => ['external_database'],
                            'external_database_' . $ex['con_name'] . 'table' => [$value]
                        ],
                        'toggle_slug' => 'chart_data',
                    );
                }
            }
        }
        if (!in_array($type, ['bubble'])) {
            $field['category'] = array(
                'label' => et_builder_i18n('Add Category'),
                'type' => 'textarea',
                'option_category' => 'basic_option',
                'toggle_slug' => 'chart_data',
                'default' => $category,
                'dynamic_content' => 'text',
                'mobile_options' => true,
                'show_if' => [
                    'data_type' => ['manual']
                ]
            );
        }
        if (in_array($type, ['pie', 'donut', 'radial', 'polar', 'gauge_google', 'geo_google', 'table_google', 'distributed_column'])) {
            $field['data_element_name'] = array(
                'label' => et_builder_i18n('Add Series'),
                'type' => 'textarea',
                'option_category' => 'basic_option',
                'toggle_slug' => 'chart_data',
                'default' => $seriesData,
                'dynamic_content' => 'text',
                'mobile_options' => true,
                'show_if' => [
                    'data_type' => ['manual']
                ]
            );
        }
        $color = graphinaDiviColors('color');
        $count = graphinaDiviGetElementCount();
        for ($i = 1; $i <= $count; $i++) {
            if (in_array($type, ['line', 'area', 'scatter', 'heatmap', 'bubble', 'bar', 'column', 'radar', 'mixed'])) {
                $field['data_element_name' . $i] = array(
                    // translators: 1: Element Count
                    'label' => sprintf(__('Element %s Name',"grdi-graphina-divi"), $i),
                    'type' => 'text',
                    'toggle_slug' => 'chart_data',
                    'mobile_options' => true,
                    'default' => "Series " . $i,
                    'dynamic_content' => 'text',
                    'sticky' => true,
                    'show_if' => [
                        'element_count' => graphinaDiviRange($i, 'element'),
                        'data_type' => ['manual']
                    ]
                );
                if ($type == 'mixed') {
                    $field['mixed_chart_type_' . $i] = array(
                        'label' => __('Chart Type', 'grdi-graphina-divi'),
                        'type' => 'select',
                        'toggle_slug' => 'chart_data',
                        'default' => graphinaDiviRandomChartType($i),
                        'options' => graphinaDiviMixedChartType(),
                        'show_if' => [
                            'element_count' => graphinaDiviRange($i, 'element'),
                        ]
                    );
                }
                if ($type === 'bubble') {
                    $manual_data = graphinaDiviElementValue($i, $type);
                    $field['data_element_value_x' . $i] = array(
                        'label' => et_builder_i18n('X Data'),
                        'type' => 'textarea',
                        'option_category' => 'basic_option',
                        'toggle_slug' => 'chart_data',
                        'dynamic_content' => 'text',
                        'default' => $manual_data['x'],
                        'mobile_options' => true,
                        'show_if' => [
                            'element_count' => graphinaDiviRange($i, 'element'),
                            'data_type' => ['manual']
                        ]
                    );

                    $field['data_element_value_y' . $i] = array(
                        'label' => et_builder_i18n('Y Data'),
                        'type' => 'textarea',
                        'option_category' => 'basic_option',
                        'toggle_slug' => 'chart_data',
                        'dynamic_content' => 'text',
                        'default' => $manual_data['y'],
                        'mobile_options' => true,
                        'show_if' => [
                            'element_count' => graphinaDiviRange($i, 'element'),
                            'data_type' => ['manual']
                        ]
                    );

                    $field['data_element_value_z' . $i] = array(
                        'label' => et_builder_i18n('Z Data'),
                        'type' => 'textarea',
                        'option_category' => 'basic_option',
                        'toggle_slug' => 'chart_data',
                        'dynamic_content' => 'text',
                        'default' => $manual_data['z'],
                        'mobile_options' => true,
                        'show_if' => [
                            'element_count' => graphinaDiviRange($i, 'element'),
                            'data_type' => ['manual']
                        ]
                    );
                } else {
                    $manual_data = graphinaDiviElementValue($i, $type);
                    $field['data_element_value' . $i] = array(
                        'label' => et_builder_i18n('Data'),
                        'type' => 'textarea',
                        'option_category' => 'basic_option',
                        'toggle_slug' => 'chart_data',
                        'dynamic_content' => 'text',
                        'default' => $manual_data,
                        'mobile_options' => true,
                        'show_if' => [
                            'element_count' => graphinaDiviRange($i, 'element'),
                            'data_type' => ['manual']
                        ]
                    );
                }
            }

            if (!in_array($type, ['gauge_google'])) {
                $field['fill_color' . $i] = array(
                     // translators: 1: Element Count
                    'label' => sprintf(__('Element %s Color',"grdi-graphina-divi"), $i),
                    'type' => 'color-alpha',
                    'toggle_slug' => 'chart_data',
                    'mobile_options' => true,
                    'default' => !empty($color[$i]) ? $color[$i] : '#000000',
                    'sticky' => true,
                    'show_if' => [
                        'element_count' => graphinaDiviRange($i, 'element')
                    ]
                );
            }
        }
    }

    return $field;
}

function graphinaDiviParseCsv($csvUrl, $areaType,$settings = [])
{
    $dataCount = !empty($settings['element_count']) && !in_array($areaType, ['counter', 'geo_google']) ? $settings['element_count'] : 0;
    $data = [];
    $category = [];
    $total = 0;

  

    $response = wp_remote_get(
        $csvUrl,
        [
            'sslverify' => false,
        ]
    );

    if ('' == $csvUrl || is_wp_error($response) || 200 != $response['response']['code'] || '.csv' !== substr($csvUrl, -4)) {
        return ['series' => $data, 'category' => $category, 'total' => $total, 'error' => $response];
    }

    $file = $csvUrl;
    try {

        $opts = array(
            "ssl" => array(
                "verify_peer" => false,
                "verify_peer_name" => false,
            ),
        );
        // phpcs:ignore 
        $_file = fopen($file, 'r', false, stream_context_create($opts));

        if (!$_file) {
            return ['series' => $data, 'category' => $category, 'total' => $total];
        }
        $lineNumber = 1;

        $csv_seperator = graphina_divi_common_setting_get('csv_seperator');
        switch ($areaType) {
            case "mixed":
            case "area":
            case "scatter":
            case "heatmap":
                while (($raw_string = fgets($_file)) !== false) {
                    $row = str_getcsv($raw_string, $csv_seperator);
                    if ($lineNumber === 1) {
                        $category = filter_var_array($row, FILTER_SANITIZE_STRING);
                        unset($category[0]);
                    } else {
                        $file_data = [
                            'name' => $row[0],
                            'data' => []
                        ];
                        unset($row[0]);
                        $file_data['data'] = array_values(array_map(function ($d) {
                            return (float)$d;
                        }, $row));
                        $data[] = $file_data;
                    }
                    $lineNumber++;
                }
                break;
            case "bubble":
                while (($raw_string = fgets($_file)) !== false) {
                    $row = str_getcsv($raw_string, $csv_seperator);
                    if ($lineNumber === 1) {
                        $category = filter_var_array($row, FILTER_SANITIZE_STRING);;
                        unset($category[0]);
                    } else {
                        $file_data = [
                            'name' => $row[0],
                            'data' => []
                        ];
                        unset($row[0]);
                        $row = array_chunk($row, 3);
                        $file_data['data'] = array_values(array_map(function ($d) {
                            return [
                                'x' => isset($d[0]) ? (float)$d[0] : 0,
                                'y' => isset($d[1]) ? (float)$d[1] : 0,
                                'z' => isset($d[2]) ? (float)$d[2] : 0
                            ];
                        }, $row));
                        $data[] = $file_data;
                    }
                    $lineNumber++;
                }
                break;
            case "nested_column":
                while (($raw_string = fgets($_file)) !== false) {
                    $row = str_getcsv($raw_string, $csv_seperator);
                    if ($lineNumber !== 1) {
                        $file_data = [
                            'x' => $row[0],
                            'quarters' => []
                        ];
                        unset($row[0]);
                        $row = array_chunk($row, 2);
                        $file_data['quarters'] = array_values(array_map(function ($d) {
                            return [
                                'x' => isset($d[0]) ? $d[0] : '',
                                'y' => isset($d[1]) ? (float)$d[1] : 0
                            ];
                        }, $row));
                        $data[] = $file_data;
                    }
                    $lineNumber++;
                }
                break;
            case "counter":
                $header = [];
                $header = filter_var_array(fgetcsv($_file), FILTER_SANITIZE_STRING);
                foreach ($header as $index => $title) {
                    $data[] = ['end' => []];
                }
                while ($row = fgetcsv($_file)) {
                    if (count($row) > 0) {
                        foreach ($data as $index => $info) {
                            if (isset($row[$index]) && $row[$index] !== '') {
                                $data[$index]['end'][] = (float)$row[$index];
                            }
                        }
                    }
                }
                return $data;
                break;

            case "datatable":
                $data = [];
                $header = [];
                $body = [];
                $data = ['body' => $body, 'header' => $header];
                break;
                // phpcs:ignore 
                $_file = fopen($file, 'r', false, stream_context_create($opts));

                if (!$_file) {
                    return ['body' => $body, 'header' => $header];
                }

                $csv_seperator = graphina_common_setting_get('csv_seperator');
                // Get first row in CSV, which is of course the headers.
                $header = fgetcsv($_file,null, $csv_seperator);
                $header = filter_var_array($header, FILTER_SANITIZE_STRING);
                $tempCounter = 0;
                break;

            case "candle" :
                while (($raw_string = fgets($_file)) !== false) {
                    $row = str_getcsv($raw_string, $csv_seperator);
                    if ($lineNumber !== 1) {
                        $file_data = [
                            'name' => $row[0],
                            'data' => []
                        ];
                        unset($row[0]);
                        $row = array_chunk($row, 5);
                        $file_data['data'] = array_values(array_map(function ($d) {
                            return [
                                'x' => isset($d[0]) ? strtotime(strval($d[0])) * 1000 : 0,
                                'y' => [
                                    isset($d[1]) ? (float)$d[1] : 0,
                                    isset($d[2]) ? (float)$d[2] : 0,
                                    isset($d[3]) ? (float)$d[3] : 0,
                                    isset($d[4]) ? (float)$d[4] : 0
                                ]
                            ];
                        }, $row));
                        $data[] = $file_data;
                    }
                    $lineNumber++;
                }
                break;
            case "timeline":
                while (($raw_string = fgets($_file)) !== false) {
                    $row = str_getcsv($raw_string, $csv_seperator);
                    if ($lineNumber === 1) {
                        $category = filter_var_array($row, FILTER_SANITIZE_STRING);
                        unset($category[0]);
                        $category = array_filter($category, function ($v) {
                            return isset($v) && $v !== '';
                        });
                    } else if ($lineNumber > 2) {
                        $file_data = [
                            'name' => $row[0],
                            'data' => []
                        ];
                        unset($row[0]);
                        $row = array_chunk($row, 2);
                        $file_data['data'] = array_values(array_map(function ($d, $c) {
                            return [
                                'x' => isset($c) ? $c : 0,
                                'y' => [
                                    isset($d[0]) ? strtotime($d[0]) * 1000 : 0,
                                    isset($d[1]) ? strtotime($d[1]) * 1000 : 0
                                ]
                            ];
                        }, $row, $category));
                        $data[] = $file_data;
                    }
                    $lineNumber++;
                }
                break;
            case "geo_google":
                while (($raw_string = fgets($_file)) !== false) {
                    $row = str_getcsv($raw_string, $csv_seperator);
                    foreach ($row as $key => $val) {
                        if ($lineNumber == 1) {
                            array_push($category, $val);
                        } else {
                            $data = array_values(array_map(function ($d) {
                                return (int)$d;
                            }, $row));
                        }
                    }
                    $total = array_sum($data);
                    $lineNumber++;
                }
                array_shift($data);
                array_shift($category);
                return ['series' => (array)$data, 'category' => $category, 'total' => $total];
                break;
            case "circle":
                while (($raw_string = fgets($_file)) !== false) {
                    $row = str_getcsv($raw_string, $csv_seperator);
                    if ($lineNumber === 1) {
                        $category = filter_var_array($row, FILTER_SANITIZE_STRING);
                    } else {
                        $data = array_values(array_map(function ($d) {
                            return (float)$d;
                        }, $row));
                        $total = array_sum($data);
                    }
                    $lineNumber++;
                }
                $category = array_slice($category, 0, $dataCount);
                break;
        }
        // phpcs:ignore 
        fclose($_file);
        return ['series' => array_slice($data, 0, $dataCount), 'category' => array_values($category), 'total' => $total];
    } catch (Exception $e) {
        return ['series' => [], 'category' => [], 'total' => 0];
    }
}
/**
 * @param $type
 * @return array[]
 */
function graphinaDiviChartResponsiveSetting($type){
    $field = [
        /* responsive */
        'responsive_brackpoint' => array(
            'label'             => __('Breakpoint', 'grdi-graphina-divi'),
            'type'              => 'range',
            'toggle_slug'       => 'responsive',
            'option_category'   => 'basic_option',
            'allowed_units'     => array('px'),
            'range_settings'    => array(
                'min'  => '0',
                'max'  => '2240',
                'step' => '1',
            ),
            'default'        => 678,
            'mobile_options' => true,
            'important'      => false,
        ),
        'responsive_chart_height' => array(
            'label'             => __('Chart Height', 'grdi-graphina-divi'),
            'type'              => 'range',
            'toggle_slug'       => 'responsive',
            'option_category'   => 'basic_option',
            'allowed_units'     => array('px'),
            'range_settings'    => array(
                'min'  => '0',
                'max'  => '1000',
                'step' => '1',
            ),
            'default'        => 400,
            'mobile_options' => true,
            'important'      => false,
        ),
    ];

    if(in_array($type,['bar','column','distributed_column'])){
        $field['responsive_chart_direction'] = array(
            'label'            => __( 'Chart Direction', 'grdi-graphina-divi' ),
            'type'             => 'select',
            'option_category'  => 'basic_option',
            'toggle_slug'     => 'responsive',
            'options'          => array(
                'true'  => __( 'Horizontal', 'grdi-graphina-divi' ),
                'false' => __( 'Vertical', 'grdi-graphina-divi' ),
            ),
            'default' => "false",
        );
    }
    return $field;
}


/**
 * @param $csvUrl
 * @param $areaType
 * @return array
 */

    // ============= DATATABLE CSV FILE =============== //

    function graphinaDiviCsv($csvUrl, $msp)
    {
        if ($csvUrl) {
            $data = [];
            $header = [];
            $rows = $msp['rows'];
            $cols = $msp['cols'];
            // phpcs:ignore 
            if (($handle = fopen($csvUrl, "r")) !== FALSE) {
                // Extract header row as columns and trim to specified columns
                $header = fgetcsv($handle);
                $header = array_slice($header, 0, $cols);
    
                // Extract remaining rows as data and trim to specified rows and columns
                $rowCounter = 0;
                while (($row = fgetcsv($handle)) !== FALSE && $rowCounter < $rows) {
                    $row = array_slice($row, 0, $cols);
                    $data[] = $row;
                    $rowCounter++;
                }
                // phpcs:ignore 
                fclose($handle);
            }
            return [
                'header' => $header,
                'body' => $data,
            ];
        }
    }
    
    function grploadGoogleSheetData($sheeturl, $msp)
    {
        if ($sheeturl) {
            $data = [];
            $header = [];
            $rows = $msp['rows'];
            $cols = $msp['cols'];

            
            $response_file = wp_remote_get(html_entity_decode($sheeturl));

            if (is_wp_error($response_file)) {
                // Handle the error, e.g., log it or return an error message
                $error_message = $response_file->get_error_message();
                return $error_message;
            } else {
                // Retrieve the body of the response
                $file = wp_remote_retrieve_body($response_file);
            }
            $file = str_replace("\r", '', $file);
            $arr = explode("\n", $file);
            $csv_seperator = ',';
    
            foreach ($arr as $i => $a) {
                if (!empty($a) && $i < $rows) {
                    $val = str_getcsv($a, $csv_seperator);
                    // Trim the data row to the specified number of columns
                    $val = array_slice($val, 0, $cols);
                    $data[] = filter_var_array($val, FILTER_SANITIZE_STRING);
                }
                if ($i === 0) {
                    // Trim the header row to the specified number of columns
                    $header = array_slice($val, 0, $cols);
                }
            }
            return [
                'header' => $header,
                'body' => $data,
            ];
        }
        die();
    }
    
    function graphinsfetchDataFromApi($api_url, $authrization_token_enable, $api_header_key, $api_header_token, $msp)
    {
        $rows = $msp['rows'];
        $cols = $msp['cols'];
    
        $response = wp_remote_get($api_url);
    
        if (is_array($response) && !is_wp_error($response)) {
            $res_body = $response['body']; // use the content
            $res_body = json_decode($res_body, true);
    
            if (isset($res_body['data']) && is_array($res_body['data'])) {
                $data = [];
    
                if (isset($res_body['data']['thead'])) {
                    // Trim the header array to the specified number of columns
                    $data['header'] = array_slice($res_body['data']['thead'], 0, $cols);
                }
    
                if (isset($res_body['data']['tbody'])) {
                    $data['body'] = [];
                    $rowCounter = 0;
                    foreach ($res_body['data']['tbody'] as $row) {
                        if ($rowCounter < $rows) {
                            // Trim each data row to the specified number of columns
                            $data['body'][] = array_slice($row, 0, $cols);
                        }
                        $rowCounter++;
                    }
                }
                return $data;
            }
        }
        return [];
    }
    
    function graphretrieveTableData($tableName, $msp)
    {
        global $wpdb;
    
        $data = [];
        $header = [];
        $rows = $msp['rows'];
        $cols = $msp['cols'];
    
        if ($tableName) {
            $columnNamesQuery = $wpdb->prepare("SHOW COLUMNS FROM %s", $tableName);
            // phpcs:ignore 
            $columnNamesResult = $wpdb->get_results($columnNamesQuery); 
            foreach ($columnNamesResult as $column) {
                $header[] = $column->Field;
            }
            $dataQuery = $wpdb->prepare("SELECT * FROM %s", $tableName);
            // phpcs:ignore 
            $dataResult = $wpdb->get_results($dataQuery); 
    
            $rowCounter = 0;
            foreach ($dataResult as $row) {
                if ($rowCounter < $rows) {
                    $rowData = [];
                    foreach ($header as $columnName) {
                        // Trim each data row to the specified number of columns
                        $rowData[] = $row->$columnName;
                    }
                    $rowData = array_slice($rowData, 0, $cols);
                    $data[] = $rowData;
                }
                $rowCounter++;
            }
        }
    
        return [
            'header' => $header,
            'body' => $data,
        ];
    }
    function graphinadivi_manual_preview($table_id,$page_id) {
        if ($table_id && $page_id) {
            // phpcs:ignore
            $table_data = unserialize(get_post_meta($page_id,'graphinatablesave_data_'.$table_id,true));
            if ($table_data) {
                $table_data = json_decode($table_data, true);
                // Check if 'header' key exists in $table_data
                if (array_key_exists('headers', $table_data)) {
                    $header = $table_data['headers'];
                    $data = $table_data['body'];
                    
                    return [
                        'header' => $header,
                        'body' => $data,
                    ];
                } else {
                    $data = $table_data['body'];
                    return [
                        'header' =>[],
                        'body' => $data,
                    ];
                }
            }
        }
        // Handle other cases or return something else if needed
    }
    
    function graphinaDiviCsv_preview($csvUrl, $settings_con)
    {
        if ($csvUrl) {
            $cols = $settings_con['no_of_columns'];
            $rows = $settings_con['no_of_rows']; // Adding rows setting
            
            $data = [];
            $header = [];
            // phpcs:ignore 
            if (($handle = fopen($csvUrl, "r")) !== FALSE) {
                // Extract header row as columns and trim to specified columns
                $header = fgetcsv($handle);
                $header = array_slice($header, 0, $cols);
    
                // Extract remaining rows as data and trim to specified rows and columns
                $rowCounter = 0;
                while (($row = fgetcsv($handle)) !== FALSE && $rowCounter < $rows) {
                    $row = array_slice($row, 0, $cols);
                    $data[] = $row;
                    $rowCounter++;
                }
                // phpcs:ignore 
                fclose($handle);
            }
    
            return [
                'header' => $header,
                'body' => $data,
            ];
        }
    }
    
    function grploadGoogleSheetData_prview($gurl, $settings_con)
    {
        if ($gurl) {
            $cols = $settings_con['no_of_columns']; // Assuming $settings_con contains your settings
            $rows = $settings_con['no_of_rows']; // Adding rows setting
    
            $data = [];
            $header = [];
    
            
            $response_file = wp_remote_get(html_entity_decode($gurl));

            if (is_wp_error($response_file)) {
                // Handle the error, e.g., log it or return an error message
                $error_message = $response_file->get_error_message();
                return $error_message;
            } else {
                // Retrieve the body of the response
                $file = wp_remote_retrieve_body($response_file);
            }

            $file = str_replace("\r", '', $file);
            $arr = explode("\n", $file);
            $csv_seperator = ',';
    
            foreach ($arr as $i => $a) {
                if (!empty($a) && $i < $rows) {
                    $val = str_getcsv($a, $csv_seperator);
                    // Trim the data row to the specified number of columns
                    $val = array_slice($val, 0, $cols);
                    $data[] = filter_var_array($val, FILTER_SANITIZE_STRING);
                }
                if ($i === 0) {
                    // Trim the header row to the specified number of columns
                    $header = array_slice($val, 0, $cols);
                }
            }
            return [
                'header' => $header,
                'body' => $data,
            ];
        }
        die();
    }
    
    function graphinsfetchDataFromApi_preview($apiUrl, $settings_con)
    {
        $cols = $settings_con['no_of_columns']; // Adding columns setting
        $rows = $settings_con['no_of_rows']; // Adding rows setting
    
        $response = wp_remote_get($apiUrl);
    
        if (is_array($response) && !is_wp_error($response)) {
            $res_body = $response['body']; // use the content
            $res_body = json_decode($res_body, true);
    
            if (isset($res_body['data']) && is_array($res_body['data'])) {
                $data = [];
    
                if (isset($res_body['data']['thead'])) {
                    // Trim the header array to the specified number of columns
                    $data['header'] = array_slice($res_body['data']['thead'], 0, $cols);
                }
    
                if (isset($res_body['data']['tbody'])) {
                    $data['body'] = [];
                    $rowCounter = 0;
                    foreach ($res_body['data']['tbody'] as $row) {
                        if ($rowCounter < $rows) {
                            // Trim each data row to the specified number of columns
                            $data['body'][] = array_slice($row, 0, $cols);
                        }
                        $rowCounter++;
                    }
                }
                return $data;
            }
        }
        return [];
    }
    
    function graphretrieveTableData_frontnd($tableName, $settings_con)
    {
        global $wpdb;
    
        $cols = $settings_con['no_of_columns']; // Adding columns setting
        $rows = $settings_con['no_of_rows']; // Adding rows setting
    
        $data = [];
        $header = [];
    
        if ($tableName) {
            $columnNamesQuery = $wpdb->prepare("SHOW COLUMNS FROM %s", $tableName);
            // phpcs:ignore
            $columnNamesResult = $wpdb->get_results($columnNamesQuery); 
            foreach ($columnNamesResult as $column) {
                $header[] = $column->Field;
            }
            $dataQuery = $wpdb->prepare("SELECT * FROM %s", $tableName);
            // phpcs:ignore
            $dataResult = $wpdb->get_results($dataQuery); 
    
            $rowCounter = 0;
            foreach ($dataResult as $row) {
                if ($rowCounter < $rows) {
                    $rowData = [];
                    foreach ($header as $columnName) {
                        // Trim each data row to the specified number of columns
                        $rowData[] = $row->$columnName;
                    }
                    $rowData = array_slice($rowData, 0, $cols);
                    $data[] = $rowData;
                }
                $rowCounter++;
            }
        }
    
        // Trim the header array to the specified number of columns
        $header = array_slice($header, 0, $cols);
    
        return [
            'header' => $header,
            'body' => $data,
        ];
    }
    
// Output the result
 // ======> ELEMENTOR WALA FUNCTION   <========

// function getjquerydatatabledata($settings,$type,$id,$dataOption,$dynamicType,$data){

//     $id = $_POST['chart_id'];

//     if (isset($_POST['action']) && 'get_jquery_datatable_data' === $_POST['action']) {
//         try {
//             $dynamicType = $settings['data_type'] == 'dynamic' ? $settings['dynamic_data_type'] : $settings['data_type'];
//             $settings = $_POST['fields'];
//             $type = $_POST['chart_type'];
//             $dataOption = $settings['data_type'];
//             $data = [];
//             switch ($dataOption) {
//                 case "dynamic":
//                     if($type == 'datatable'){
//                         $settings['csv_url'];
//                     }
//                     $file = $setings['csv_url'];
//                     $_file = fopen($file, 'r', false, stream_context_create($opts));
                    
//                     if (!$_file) {
//                         return ['series' => $data, 'category' => $category, 'total' => $total];
//                     }

//             }

//             if ( empty($data['header']) || !is_array($data['header'])) {
//                 wp_send_json(['status' => false, 'table_id' => $id, 'data' => ['head' => [], 'body' => []]]);
//                 die;
//             }

//             $data['body'] = array_map(function ($value) use ($data) {
//                 if (count($value) != count($data['header'])) {
//                     $diff = count($data['header']) - count($value);
//                     if ($diff < 0) {
//                         $value = array_slice($value, 0, count($data['header']));
//                     } else {
//                         $empty_value = array_fill(0, $diff, "-");
//                         $value = array_merge($value, $empty_value);
//                     }
//                 }
//                 return $value;
//             }, $data['body']);
//             wp_send_json(['status' => true,
//                     'table_id' => $id,
//                     'data' => $data]
//             );
//             die;
//         } catch (Exception $exception) {
//             wp_send_json([
//                 'status' => false,
//                 'table_id' => $id,
//                 'data' => ['head' => [], 'body' => []]]
//             );
//             die;
//         }
//     }

//     wp_send_json(['status' => false, 'chart_id' => $id, 'data' => ['head' => [],'body' => []]]);
//     die;
// }

/**
 * @param $url
 * @param $areaType
 * @return array
 */
#
function graphinaDiviParseGooglesheetAndRemotecsv($url, $areaType, $settings = [])
{

    $dataCount = !in_array($areaType, ['geo_google']) ? $settings['element_count'] : '';
    $result = [];
    $category = [];
    $total = 0;
    if ($url === '') {
        return ["series" => $result, "category" => $category, 'total' => $total];
    }

    
    $response = wp_remote_get($url);

    if (is_wp_error($response)) {
        // Handle the error, e.g., log it or return an error message
        $error_message = $response->get_error_message();
        return $error_message;
    } else {
        // Retrieve the body of the response
        $file = wp_remote_retrieve_body($response);
    }
    

    if (strpos($file, '<!DOCTYPE html>') !== false || strpos($file, '<html>') !== false || strpos($file, '</html>') !== false) {

        return ["series" => $result, "category" => $category, 'total' => $total, 'fail' => 'permission'];
    }
    $file = str_replace("\r\n", "\n", $file);

    $arr = explode("\n", $file);


    $csv_seperator = graphina_divi_common_setting_get('csv_seperator');
    switch ($areaType) {
        case "area":
        case "scatter":
        case "heatmap":
            foreach ($arr as $i => $a) {

                if (!empty($a)) {
                    if ($i !== 0) {
                        $v = str_getcsv($a, $csv_seperator);
                        $name = $v[0];
                        unset($v[0]);
                        $v = array_map(function ($d) {
                            return (float)$d;
                        }, $v);
                        $result[] = [
                            "name" => filter_var($name, FILTER_SANITIZE_STRING),
                            "data" => array_values($v)
                        ];
                    } else {
                        $category = filter_var_array(str_getcsv($a, $csv_seperator), FILTER_SANITIZE_STRING);
                        unset($category[0]);
                    }
                }
            }
            break;
        case "bubble":
            foreach ($arr as $i => $a) {
                if (!empty($a)) {
                    $v =  str_getcsv($a, $csv_seperator);;
                    if ($i === 0) {
                        $category = filter_var_array($v, FILTER_SANITIZE_STRING);
                        unset($category[0]);
                    } else {
                        $file_data = [
                            'name' => filter_var($v[0], FILTER_SANITIZE_STRING),
                            'data' => []
                        ];
                        unset($v[0]);
                        $v = array_chunk($v, 3);
                        $file_data['data'] = array_values(array_map(function ($d) {
                            return [
                                'x' => isset($d[0]) ? (float)$d[0] : 0,
                                'y' => isset($d[1]) ? (float)$d[1] : 0,
                                'z' => isset($d[2]) ? (float)$d[2] : 0
                            ];
                        }, $v));
                        $result[] = $file_data;
                    }
                }
            }
            break;
        case "nested_column":
            foreach ($arr as $i => $a) {
                if (!empty($a)) {
                    $v =  str_getcsv($a, $csv_seperator);;
                    if ($i !== 0) {
                        $file_data = [
                            'x' => filter_var($v[0], FILTER_SANITIZE_STRING),
                            'quarters' => []
                        ];
                        unset($v[0]);
                        $v = array_chunk($v, 2);
                        $file_data['quarters'] = array_values(array_map(function ($d) {
                            return [
                                'x' => isset($d[0]) ? filter_var($d[0], FILTER_SANITIZE_STRING) : '',
                                'y' => isset($d[1]) ? (float)$d[1] : 0
                            ];
                        }, $v));
                        $result[] = $file_data;
                    }
                }
            }
            break;
        case "candle":
            foreach ($arr as $i => $a) {
                if (!empty($a)) {
                    $v =  str_getcsv($a, $csv_seperator);;
                    if ($i !== 0) {
                        $file_data = [
                            'name' => filter_var($v[0], FILTER_SANITIZE_STRING),
                            'data' => []
                        ];
                        unset($v[0]);
                        $v = array_chunk($v, 5);
                        $file_data['data'] = array_values(array_map(function ($d) {
                            return [
                                'x' => isset($d[0]) ? strtotime(strval($d[0])) * 1000 : 0,
                                'y' => [
                                    isset($d[1]) ? (float)$d[1] : 0,
                                    isset($d[2]) ? (float)$d[2] : 0,
                                    isset($d[3]) ? (float)$d[3] : 0,
                                    isset($d[4]) ? (float)$d[4] : 0
                                ]
                            ];
                        }, $v));
                        $result[] = $file_data;
                    }
                }
            }
            break;
        case "counter":
            foreach ($arr as $i => $a) {
                if (!empty($a)) {
                    $val = explode(',', $a);
                    if ($i === 0) {
                        foreach ($val as $index => $v) {
                            $data[] = ['end' => []];
                        }
                    } else {
                        foreach ($data as $index => $v) {
                            if (isset($val[$index]) && $val[$index] !== '') {
                                $data[$index]['end'][] = (float)$val[$index];
                            }
                        }
                    }
                }
            }
            return $data;
            break;
        case "timeline":
            foreach ($arr as $i => $a) {
                if (!empty($a)) {
                    $v = str_getcsv($a, $csv_seperator);;
                    if ($i === 0) {
                        $category = filter_var_array($v, FILTER_SANITIZE_STRING);;
                        unset($category[0]);
                        $category = array_filter($category, function ($v) {
                            return isset($v) && $v !== '';
                        });
                    } else if ($i > 1) {
                        $file_data = [
                            'name' => filter_var($v[0], FILTER_SANITIZE_STRING),
                            'data' => []
                        ];
                        unset($v[0]);
                        $v = array_chunk($v, 2);
                        $file_data['data'] = array_values(array_map(function ($d, $c) {
                            return [
                                'x' => isset($c) ? $c : 0,
                                'y' => [
                                    isset($d[0]) ? strtotime($d[0]) * 1000 : 0,
                                    isset($d[1]) ? strtotime($d[1]) * 1000 : 0
                                ]
                            ];
                        }, $v, $category));
                        $result[] = $file_data;
                    }
                }
            }
            break;
        case "geo_google":
            foreach ($arr as $i => $a) {
                if (!empty($a)) {
                    $v =  str_getcsv($a, $csv_seperator);
                    foreach ($v as $key => $val) {
                        if ($i === 0) {
                            array_push($category, $val);
                        } else {
                            $result = array_values(array_map(function ($d) {
                                return (int)$d;
                            }, $v));
                        }
                    }
                    $total = array_sum($result);
                }
            }
            unset($result[0]);
            unset($category[0]);
            return ["series" => $result, "category" => $category, 'total' => $total];
            break;
        case "circle":
            foreach ($arr as $i => $a) {
                if (!empty($a)) {
                    $v =  str_getcsv($a, $csv_seperator);;
                    if ($i === 0) {
                        $category = filter_var_array($v, FILTER_SANITIZE_STRING);;
                    } else {
                        $result = array_values(array_map(function ($d) {
                            $d = str_replace(',', '', $d);
                            return (float)$d;
                        }, $v));
                        $total = array_sum($result);
                    }
                }
            }
            $category = array_slice($category, 0, $dataCount);
            break;
    }
    return ["series" => array_slice($result, 0, $dataCount), "category" => array_values($category), 'total' => $total];
}


/**
 * @param $settings
 * @param $areaType
 * @return array
 */
function graphinaDiviChartGetDataFromApi($settings, $areaType)
{
    $dataCount = !in_array($areaType, ['counter', 'geo_google']) ? $settings['element_count'] : '';
    $api_url = !empty($settings['api_url']) ? esc_url_raw($settings['api_url']) : '';
    $result = ['series' => [], 'category' => [], 'total' => 0];
    if ($api_url === '') {
        return $result;
    }

    $args = [];
    if (
        isset($settings['authrization_token_enable'])
        && $settings['authrization_token_enable'] === 'true'
    ) {
        $args['headers'] = [];
        $args['headers'][$settings['api_header_key']] = $settings['api_header_token'];
    }
    $api_url = graphina_divi_replace_dynamic_key($api_url);
    $response = wp_remote_get($api_url, $args);

    if (is_array($response) && !is_wp_error($response)) {
        $res_body = $response['body']; // use the content
        $res_body = json_decode($res_body, true);
        if (!empty($res_body['data']) && gettype($res_body['data']) === 'array') {
            switch ($areaType) {
                case 'area':
                case 'scatter':
                case 'heatmap':
                case 'circle':
                    $result['series'] = $res_body['data'];
                    $result['category'] = $res_body['category'];
                    $result['total'] = array_sum($res_body['data']);
                    break;
                case 'bubble':
                case 'nested_column':
                case 'candle':
                    $result['series'] = $res_body['data'];
                    break;
                case 'timeline':
                    $result['series'] = array_map(function ($v) {
                        $v['data'] = array_map(function ($v1) {
                            $v1['y'] = array_map(function ($v2) {
                                if (gettype($v2) === 'string') {
                                    $v2 = strtotime($v2) * 1000;
                                }
                                return $v2;
                            }, $v1['y']);
                            return $v1;
                        }, $v['data']);
                        return $v;
                    }, $res_body['data']);
                    break;
                case 'counter':
                    $result = $res_body['data'];
                    return $result;
                    break;
                case 'geo_google':
                    $result['series'] = $res_body['data'];
                    $result['category'] = $res_body['category'];
                    $result['total'] = array_sum($res_body['data']);
                    return $result;
                    break;
            }
        }
    }
    $result['series'] = array_slice($result['series'], 0, $dataCount);
    $result['category'] = $areaType === 'circle' ? array_slice($result['category'], 0, $dataCount) : $result['category'];
    return $result;
}

function graphinaDiviListDBTables()
{
    if (!empty(GRAPHINA_DIVI_DATABASE_TABLES)) {
        $tables = array_keys(GRAPHINA_DIVI_DATABASE_TABLES);
        return array_combine($tables, $tables);
    }
    return  [];
}

function graphinaDiviExternalDatabaseTables($connection_name)
{
    if (
        !empty(GRAPHINA_DIVI_EXTERNAL_DATABASE_TABLES)
        && !empty(GRAPHINA_DIVI_EXTERNAL_DATABASE_TABLES[$connection_name])
        && is_array(GRAPHINA_DIVI_EXTERNAL_DATABASE_TABLES[$connection_name])
        && count(GRAPHINA_DIVI_EXTERNAL_DATABASE_TABLES[$connection_name]) > 0
    ) {
        $tables = array_keys(GRAPHINA_DIVI_EXTERNAL_DATABASE_TABLES[$connection_name]);
        return array_combine($tables, $tables);
    }
    return  [];
}

function graphinaDiviExternalDatabaseTableColumn($connection_name, $table)
{
    if (
        !empty(GRAPHINA_DIVI_EXTERNAL_DATABASE_TABLES)
        && !empty(GRAPHINA_DIVI_EXTERNAL_DATABASE_TABLES[$connection_name][$table])
        && is_array(GRAPHINA_DIVI_EXTERNAL_DATABASE_TABLES[$connection_name][$table])
        && count(GRAPHINA_DIVI_EXTERNAL_DATABASE_TABLES[$connection_name][$table]) > 0
    ) {
        return GRAPHINA_DIVI_EXTERNAL_DATABASE_TABLES[$connection_name][$table];
    } else {
        return ['no_data' => 'No Columns Found'];
    }
}
function graphinaDiviChartGetDataFromSQLBuilder($settings, $type)
{

    try {
 
        if( $settings['dynamic_data_type'] === 'sql_builder'){
  
            global $wpdb;
            if($settings['sql_builder_mode'] == 'table' || $settings['sql_builder_mode'] == 'mysql_query'){
                $tableName = $settings['sql_builder_table'];
   
                if (!in_array($type,['counter']) && (empty($tableName) || $tableName == 'no_data'
                        || empty($settings['sql_builder_y_axis_column' . $tableName]) || $settings['sql_builder_y_axis_column' . $tableName] == 'no_data'
                        || empty($settings['sql_builder_x_axis_column' . $tableName]) || $settings['sql_builder_x_axis_column' . $tableName] == 'no_data')) {
                    return ['series' => [], 'category' => ['col 1', 'col 2', 'col 3', 'col 4', 'col 5'], 'total' => 0, 'sql_fail' => 'No data found, Please check your sql statement gerght.'];
                }

                $result_data =  graphina_get_sql_builder_and_external_database_result($tableName,$type,$wpdb);
                $no_of_records = $settings['sql_records_no'];
                if(!empty($no_of_records)){
                    if ($no_of_records >= 0 && $no_of_records <= count($result_data)) {
                        $result_data = array_slice($result_data, 0, $no_of_records);
                    } 
                }
            }
        } else {
            if (empty($settings['external_database_name'])) {
                return ['series' => [], 'category' => ['col 1', 'col 2', 'col 3', 'col 4', 'col 5'], 'total' => 0, 'sql_fail' => 'No data found, Please Select your external connection name.'];
            }
            $external_connection_name = $settings['external_database_name'];
            $tableName = !empty($settings['external_database_'.$external_connection_name.'table']) ?  $settings['external_database_'.$external_connection_name.'table'] : '';
            if (!in_array($type,['counter']) && (empty($tableName) || $tableName == 'no_data'
                    || empty($settings['external_database_'.$external_connection_name.'_y_axis_column' . $tableName]) || $settings['external_database_'.$external_connection_name.'_y_axis_column' . $tableName] == 'no_data'
                    || empty($settings['external_database_'.$external_connection_name.'_x_axis_column' . $tableName]) || $settings['external_database_'.$external_connection_name.'_x_axis_column' . $tableName] == 'no_data')) {
                return ['series' => [], 'category' => ['col 1', 'col 2', 'col 3', 'col 4', 'col 5'], 'total' => 0, 'sql_fail' => 'No data found, esdfg.'];
            }
            $external_database_list = graphina_divi_check_external_database('data');
            if (!empty($external_database_list) && is_array($external_database_list) && array_key_exists($external_connection_name, $external_database_list)) {
                $seleted_database_value = $external_database_list[$external_connection_name];
                $mydb = new wpdb( $seleted_database_value['user_name'],$seleted_database_value['pass'],$seleted_database_value['db_name'],$seleted_database_value['host']);
                $result_data =  graphina_get_sql_builder_and_external_database_result($tableName,$type,$mydb,$settings);
                $mydb->close();
            }
        }

        if ($type === 'counter') {
            $counter_data = [];
            if (!empty($result_data) && count($result_data) > 0) {
                $header = count($result_data[0]) > 0 ? array_keys($result_data[0]) : [];
                foreach ($header as $index => $tr) {
                    $vals = array_values(array_map(function ($val) use ($tr) {
                        return (float)$val[$tr];
                    }, (array)$result_data));
                    $counter_data[] = [
                        'end' => $vals,
                    ];
                }
            }
            return $counter_data;
        }

        if (!empty($result_data) && count($result_data)) {
            $column_name = $settings['dynamic_data_type'] === 'sql_builder' ? 'sql_builder' : 'external_database_' . $settings['external_database_name'];
            $values = [];
            $tableName = $settings['dynamic_data_type'] === 'sql_builder' ? $settings['sql_builder_table'] : $settings['external_database_' . $settings['external_database_name'] . 'table'];
            $table_column = $settings['dynamic_data_type'] === 'sql_builder' ? array_values(graphinaDiviListDBTablesColumn($tableName)) : array_values(graphinaDiviExternalDatabaseTableColumn($settings['external_database_name'], $tableName));

            if (in_array($type, ['pie', 'donut', 'radial', 'polar', 'gauge_google', 'distributed_column'])) {
                $y_columns = $settings[$column_name . '_y_axis_column' . $tableName];
            } else {
                $y_columns_array = [];
                $selectedOptions = explode("|", $settings[$column_name . '_y_axis_column' . $tableName]);
                foreach ($selectedOptions as $key => $value) {
                    if ($value == 'on') {
                        $y_columns_array[] = $table_column[$key];
                    }
                }
                $y_columns = $y_columns_array;
            }

            // dynamic column name
            $x_columns = $settings[$column_name . '_x_axis_column' . $tableName];

            if (!is_array($y_columns)) {
                $y_columns = [$y_columns];
            }

            $series = ['series' => [], 'category' => ['col 1', 'col 2', 'col 3', 'col 4', 'col 5'], 'total' => 0];

            if (is_array($y_columns) && !empty($x_columns) && $x_columns !== 'no_data') {
                $y_columns[] = $x_columns;
            }

            if (count($y_columns) > 0) {

                foreach ($y_columns as $key => $column) {

                    foreach ($result_data as $key => $value) {
                        if (in_array($type, ['pie', 'donut', 'radial', 'polar', 'pie_google', 'donut_google', 'gauge_google', 'geo_google'])) {
                            $values[$column][] = $column == $x_columns ? $value->{$column} : (int)$value->{$column};
                        } else {
                            $values[$column][] = $value->{$column};
                        }
                    }

                    if ($column != $x_columns) {
                        $temp_element = [
                            'name' => $column,
                            'data' => $values[$column]
                        ];

                        if (in_array($type, ['pie', 'donut', 'radial', 'polar', 'pie_google', 'donut_google', 'gauge_google', 'geo_google'])) {
                            $series['series'] = $values[$column];
                        } else {
                            $series['series'][] = $temp_element;
                        }
                    }
                }
            }

            if (
                !empty($x_columns) && $x_columns !== 'no_data' && !empty($values)
                && !empty($values[$x_columns]) && count($values[$x_columns]) > 0
            ) {
                $series['category'] = $values[$x_columns];
                unset($values[$x_columns]);
            }

            $series['x_axis_value'] = $x_columns;

            return $series;
        } else {
            return ['status' => false, 'data' => ['series' => [], 'category' => [], 'total' => 0], 'sql_fail' => esc_attr__('No data found, Please check your sql statement fgfg.',  'grdi-graphina-divi')];
        }
    } catch (Exception $exception) {
        return ['status' => false, 'data' => ['series' => [], 'category' => [], 'total' => 0],'sql_fail' => esc_attr__('No data found, Please check your sql statement greg.',  'grdi-graphina-divi')];
    }
}
/*function graphinaDiviReplaceDynamicFilterKeyChange($settings,$type,$selected_item,$sql_custom_query){
    if (!empty($settings['iq_'.$type.'_chart_filter_enable']) && $settings['iq_'.$type.'_chart_filter_enable'] == 'yes' && !empty($selected_item) && is_array($selected_item) ) {
        foreach ($settings['iq_'.$type.'_chart_filter_list'] as $key => $value) {
            if (!empty($value['iq_'.$type.'_chart_filter_value_key']) && !empty($selected_item[$key])) {
                if (!empty($settings['iq_' . $type . '_chart_dynamic_data_option']) && $settings['iq_' . $type . '_chart_dynamic_data_option'] === 'sql-builder' && strstr($sql_custom_query, trim($selected_item[$key])) && count($selected_item) === count(array_unique($selected_item))) {
                    $sql_custom_query = str_replace(array("'".$value['iq_'.$type.'_chart_filter_value_key']."'",'"'.$value['iq_'.$type.'_chart_filter_value_key'].'"'),$selected_item[$key], $sql_custom_query);
                }else{
                    $sql_custom_query = str_replace($value['iq_'.$type.'_chart_filter_value_key'],trim($selected_item[$key]), $sql_custom_query);
                }
            }
        }
    }
    return $sql_custom_query;
}


*/
function graphinaDiviMixedChartType()
{
    return [
        'line' => __('Line', 'grdi-graphina-divi'),
        'area' => __('Area', 'grdi-graphina-divi'),
        'column' => __('Column', 'grdi-graphina-divi'),
    ];
}

function graphinaDiviRandomChartType($i)
{
    switch ($i) {
        case 2:
            return 'area';
            break;
        case 3:
            return 'scatter';
            break;
        default:
            return 'line';
            break;
    }
}

/**
 * @param $settings
 * @param $type
 * @return array
 */
function graphinaDiviGetChartDynamicData($settings, $type, $id = '')
{
    $dynamicType = $settings['data_type'] == 'dynamic' ? $settings['dynamic_data_type'] : $settings['data_type'];
    $data = in_array($type,['counter']) ? [] : ['series' => [],'category' => [],'total'=>0];
    $mainType = ! in_array($type,['line','area', 'datatable', 'scatter','datatable','heatmap', 'radar','column','bar','mixed','distributed_column']) ? (in_array($type ,['pie','donut','radial','polar','gauge_google']) ? 'circle' : $type) : 'area';
    switch($dynamicType){
        case 'csv':
            $data = graphinaDiviParseCsv(esc_url_raw($settings['csv_url']), $mainType, $settings);
            break;
        case 'remote-csv':
        case 'google-sheet':
            $data = graphinaDiviParseGooglesheetAndRemotecsv($dynamicType == 'remote-csv' ? esc_url_raw($settings['remote_csv_url']) : esc_url_raw($settings['googlesheet_url']), $mainType, $settings);
            break;
        case 'api':
            $data = graphinaDiviChartGetDataFromApi($settings, $mainType);
            break;
        case 'sql_builder':
        case 'external_database':
            $data = graphinaDiviChartGetDataFromSQLBuilder($settings, $type);
            break;
        case 'filter':
            $data = apply_filters('graphina_divi_extra_data_option', $data, $type, $settings, $id);
            break;
    }

    if ($type == 'mixed') {
        if (!empty($data['series']) && count($data['series']) > 0) {
            foreach ($data['series'] as $key => $value) {
                $i = (int)$key + 1;
                $data['series'][$key]['type'] = !empty($settings['mixed_chart_type_' . $i]) ? $settings['mixed_chart_type_' . $i] : 'area';
            }
        }
    }

    if ((!empty($data['fail']) && $data['fail'] === 'permission') || (!empty($data['sql_fail']))) {
        if (!in_array($type, ['counter'])) {
            switch ($dynamicType) {
                case "google-sheet":
                    $data['fail_message'] = "<pre><b>" . esc_html__('Please check file sharing permission and "Publish As" type is CSV or not. ',  'grdi-graphina-divi') . "</b><small><a target='_blank' href='https://youtu.be/Dv8s4QxZlDk'>" . esc_html__('Click for reference.',  'grdi-graphina-divi') . "</a></small></pre>";
                    break;
                case 'sql_builder':
                case 'external_database':
                    $data['fail_message'] = "<pre><b>" . (isset($data['sql_fail']) ? $data['sql_fail'] :  esc_html__('No data found, Please check your sql statement    .',  'grdi-graphina-divi')). "</b></pre>";
                    break;
                case "remote-csv":
                default:
                    $data['fail_message'] = "<pre><b>" . (isset($data['errorMessage']) ? $data['errorMessage'] :  esc_html__('Please check file sharing permission.',  'grdi-graphina-divi')) . "</b></pre>";
                    break;
            }
        } else {
            $data = [];
        }
    }

    return $data;
}

function graphinaDiviIsRequiredPluginActive()
{
    if (!function_exists('get_plugins')) {
        include_once ABSPATH . 'wp-admin/includes/plugin.php';
    }
    $plugins = get_plugins();
    foreach ($plugins as $key => $value) {
        if ($value['TextDomain'] === 'divi-builder') {
            if (is_plugin_active($key)) {
                return    true;
            }
        }
    }
    return false;
}

function graphinaDiviIsRequiredPluginInstall()
{
    $file_path = 'divi-builder/divi-builder.php';
    $installed_plugins = get_plugins();

    return isset($installed_plugins[$file_path]);
}

function graphinaDiviCheckRequiredPlugin()
{
    $current_template = esc_attr( get_option( 'template' ) );
	// Check whether the active (or parent) theme is Divi or Extra
	if (in_array( $current_template, array( 'Divi', 'Extra' ) ) ) {
		return;
	}

    $theme= wp_get_theme();
    if ($theme->name === 'Divi' || $theme->parent_theme === 'Divi') {
        return;
    }
    if (graphinaDiviIsRequiredPluginInstall()) {
        if (!graphinaDiviIsRequiredPluginActive()) {
            if (!current_user_can('activate_plugins')) {
                return;
            }

            $plugin = 'divi-builder/divi-builder.php';

            $activation_url = wp_nonce_url('plugins.php?action=activate&amp;plugin=' . $plugin . '&amp;plugin_status=all&amp;paged=1&amp;s', 'activate-plugin_' . $plugin);

            $message = __('<strong>Graphina - Divi Charts and Graphs</strong> requires <strong>Divi Builder</strong> plugin to be active. Please activate Divi Builder for Graphina - Divi Charts and Graphs to continue.', 'grdi-graphina-divi');
            $button_text = __('Activate Divi Builder ', 'grdi-graphina-divi');

            $button = '<p><a  href="' . $activation_url . '" class="button-primary">' . $button_text . '</a></p>';

            printf('<div class="error"><p>%1$s</p>%2$s</div>', wp_kses($message, 'post'), wp_kses($button,'post'));
            if (isset($_GET['activate']) && check_admin_referer('activate_nonce', 'activate')) unset($_GET['activate']);
            deactivate_plugins(GRAPHINA_DIVI_BASE_PATH);
        }
        return;
    } else {
        if (!current_user_can('install_plugins')) {
            return;
        }
        $install_url = 'https://www.elegantthemes.com/gallery/divi/';
        $message = __('<strong>Graphina - Divi Charts and Graphs</strong> Not working because you need to install the <strong>Divi Builder</strong> plugin.', 'grdi-graphina-divi');
        $button_text = __('Install Divi Builder ', 'grdi-graphina-divi');

        $button = '<p><a target="_blank" href="' . $install_url . '" class="button-primary">' . $button_text . '</a></p>';

        printf('<div class="error"><p>%1$s</p>%2$s</div>', wp_kses($message,'post'), wp_kses($button,'post'));
        if (isset($_GET['activate']) && check_admin_referer('activate_nonce', 'activate')) unset($_GET['activate']);
        deactivate_plugins(GRAPHINA_DIVI_BASE_PATH);
    }
}

function graphinaDiviLoadModuleScript($type)
{
    if (in_array($type, ['gauge_google', 'geo_google', 'table_google'])) {
        wp_enqueue_script('graphina_divi_google_chart_script');
    } else if ($type === 'counter') {
        wp_enqueue_script('graphina_divi_counter');
    } else {
        wp_enqueue_script('graphina_apex_chart_script');
    }
    wp_enqueue_script('graphina-divi-common-public');
    wp_enqueue_style('graphina_divi_style');
}
function graphinadividatatablescripts($type){
    wp_enqueue_script('graphina_divi_datatable_save');
}
function graphinaDiviGetSpreadsheet($type = 'area')
{

    $sheet = 'https://docs.google.com/spreadsheets/d/1zCIRmobXye0BSgUnY4vMG4Sn6LEp6We_4RjJdPS4CYg/edit?usp=sharing';

    switch ($type) {

        case 'donut':
        case 'pie':
        case 'polar':
        case 'radial':
        case 'gauge_google':
        case 'pie_google':
        case 'donut_google':
            $sheet = 'https://docs.google.com/spreadsheets/d/1v2v1W61vZahN2qhbCL2Z79CEnzPOwJLyQqswIOzjxmU/edit?usp=sharing';
            break;
        case 'bubble':
            $sheet = 'https://docs.google.com/spreadsheets/d/1Wqv3095LVzkKG_1uwNWWiSovyWwnC0EdqVgIkm746Yo/edit?usp=sharing';
            break;
        case 'timeline':
            $sheet = 'https://docs.google.com/spreadsheets/d/1trOwuavFpWMXEG-53pjRLAA_fhgNqOvBWfuQ6S6JNDM/edit?usp=sharing';
            break;
        case 'nested_column':
            $sheet = 'https://docs.google.com/spreadsheets/d/1drqaZ3CbRseRXJekNHBSnW6v-S91opSfh0QhBRZbjJ8/edit?usp=sharing';
            break;
        case 'counter':
            $sheet = 'https://docs.google.com/spreadsheets/d/1ZEtWaHVocV3O2G2CO1iHK38vKcAe1sJjEDj_WUdINIg/edit?usp=sharing';
            break;
        case 'advance-datatable':
        case 'data_table_lite':
            $sheet = 'https://docs.google.com/spreadsheets/d/1NPZwZXIoG0Cgl8mtnvV8U6MqjuJ8_VFplNm3qnj_Wyo/edit?usp=sharing';
            break;
        case 'brush':
            $sheet = 'https://docs.google.com/spreadsheets/d/1fBY8WPnx8PssjQ-NFX8DsBdfoFatVrJ8aE3hKlE9Aa4/edit?usp=sharing';
            break;
        case 'candle':
            $sheet = 'https://docs.google.com/spreadsheets/d/13JrMfu51H26FDi9AUtb6LLD-Vi5qDdD9uq5yXtIA3gg/edit?usp=sharing';
            break;
        case 'heatmap':
            $sheet = 'https://docs.google.com/spreadsheets/d/1tcW_dpmfOgCFizuyMQnVIkVuD9eTZFs9pr2Z3PJGo7I/edit?usp=sharing';
            break;
        case 'mixed':
            $sheet = 'https://docs.google.com/spreadsheets/d/15cqsdg5yxl3n-U7IBYFSVESQJCQXayJ4Y_oZxqTxfK0/edit?usp=sharing';
            break;
        case 'distributed_column':
            $sheet = 'https://docs.google.com/spreadsheets/d/1WNxX0_Gudmbtmud-7gdp7HZA1VHYKdfpeZJXhsyiwhY/edit?usp=sharing';
            break;
        case 'geo_google':
            $sheet = 'https://docs.google.com/spreadsheets/d/1No5I7PTQBid4mbilUwSlteVFo1v5TMKPIqGkPEzvELA/edit?usp=sharing';
            break;
        case 'org_google':
            $sheet = 'https://docs.google.com/spreadsheets/d/1V5A8LkJ42loZLCvsK4NVBOcw5wbaHgM_eXgZoF78U80/edit?usp=sharing';
            break;
    }

    return $sheet;
}

function graphinaDiviListDBTablesColumn($table)
{
    $table_column = GRAPHINA_DIVI_DATABASE_TABLES;
    if (!empty($table_column[$table])) {
        return $table_column[$table];
    } else {
        return ['no_data' => 'No Columns Found'];
    }
}

function graphinaDiviGetAlphabet()
{
    return [
        '1' => 'A',
        '2' => 'B',
        '3' => 'C',
        '4' => 'D',
        '5' => 'E',
        '6' => 'F',
        '7' => 'G',
        '8' => 'H',
        '9' => 'I',
        '10' => 'J',
        '11' => 'K',
        '12' => 'L',
        '13' => 'M',
        '14' => 'N',
        '15' => 'O',
        '16' => 'P',
        '17' => 'Q',
        '18' => 'R',
        '19' => 'S',
        '20' => 'T',
        '21' => 'U',
        '22' => 'V',
        '23' => 'W',
        '24' => 'X',
        '25' => 'Y',
        '26' => 'Z'
    ];
}

function graphina_divi_check_external_database($type)
{
    $data = get_option('graphina_divi_mysql_database_setting', true);
    return $type === 'status' ? gettype($data) != 'boolean' && is_array($data) && count($data) > 0 : $data;
}

function graphina_divi_common_setting_get($type)
{
    $data = get_option('graphina_divi_common_setting', true);
    $value = '';
    switch ($type) {
        case 'thousand_seperator':
            $value = !empty($data['thousand_seperator']) ? $data['thousand_seperator'] : ",";
            break;
        case 'view_port':
            $value = !empty($data['view_port']) ? $data['view_port'] : 'on';
            break;
        case 'csv_seperator':
            $value = !empty($data['csv_seperator']) ? ($data['csv_seperator'] == 'semicolon' ? ';' : ',') : ',';
            break;
        case 'dynamic_data_options':
            $value = !empty($data['dynamic_data_options']) && is_array($data['dynamic_data_options']) ? $data['dynamic_data_options'] : [];
            break;
    }

    return $value;
}

function graphina_get_sql_builder_and_external_database_result($tableName,$type,$wpdb){

    $table_limit = !empty($settings['sql_builder_table_limit']) && $settings['sql_builder_table_limit'] > 0 ? ' limit '.$settings['sql_builder_table_limit'] : ' ';
    $table_offset = !empty($settings['sql_builder_table_offset']) && $settings['sql_builder_table_offset'] >= 0 ? ' OFFSET ' . $settings['sql_builder_table_offset'] : ' ';
    $where_condition = !empty($settings['sql_builder_table_where_condition']) ? stripslashes(wp_strip_all_tags(trim($settings['sql_builder_table_where_condition']))) : '';
    $where_condition = stripslashes(wp_strip_all_tags(trim($where_condition)));
    $query = $wpdb->prepare("SELECT * FROM {$wpdb->prefix}%s %s %s %s", $tableName, $where_condition, $table_limit, $table_offset);
    $query = graphina_divi_replace_dynamic_key($query);

    if (in_array($type, ['counter'])) {
        // phpcs:ignore
        $result_data = $wpdb->get_results($query, ARRAY_A); 
    } else {
        // phpcs:ignore
        $result_data = $wpdb->get_results($query); 
    }

    return $result_data;
}

function graphina_divi_replace_dynamic_key($text)
{

    $dynamic_key = [
        "{{CURRENT_USER_EMAIL}}",
        "{{CURRENT_USER_ID}}",
        "{{CURRENT_USER_ROLE}}",
        "{{CURRENT_DATE}}",
        "{{CURRENT_DATE_TIME}}",
        "{{CURRENT_TIME}}",
        "{{CURRENT_POST_ID}}",
    ];

    $current_user_id = get_current_user_id();
    $email = $role = '';
    if (!empty($current_user_id)) {
        $userObj = new WP_User($current_user_id);
        $email = !empty($userObj->user_email) ? $userObj->user_email : '';
        $role = !empty($userObj->roles) && !empty($userObj->roles[0]) ? $userObj->roles[0] : '';
    }

    $replace_value = [
        $current_user_id,
        $email,
        $role,
        current_time('Y-m-d'),
        current_time('Y-m-d H:i:s'),
        current_time('H:i:s'),
        get_the_id()
    ];
    return  str_replace($dynamic_key, $replace_value, $text);
}

function graphinaDiviRecursiveSanitizeTextField($array)
{
    $filterParameters = [];
    foreach ($array as $key => $value) {

        if ($value === '') {
            $filterParameters[$key] = null;
        } else {
            if (is_array($value)) {
                $filterParameters[$key] = graphinaDiviRecursiveSanitizeTextField($value);
            } else {
                if (is_object($value)) {
                    $filterParameters[$key] = $value;
                } else if (preg_match("/<[^<]+>/", $value, $m) !== 0) {
                    $filterParameters[$key] = $value;
                } elseif ($key === 'graphina_loader') {
                    $filterParameters[$key] = esc_url_raw($value);
                } elseif ($key  === 'nonce') {
                    $filterParameters[$key] = sanitize_key($value);
                } else {
                    $filterParameters[$key] = sanitize_text_field($value);
                }
            }
        }
    }

    return $filterParameters;
}

function graphinaDiviElementCountList()
{
    $count = graphinaDiviGetElementCount();
    $element = [];
    for ($i = 1; $i <= $count; $i++) {
        $element[$i] = (string)$i;
    }
    return $element;
}

function graphinaDiviGetElementCount()
{
    $count = apply_filters('graphina_divi_element_count', 15);
    return !empty($count) && $count > 0 ? $count : 15;
}

function graphinaDiviElementValue($count_number, $type)
{
    switch ($type) {
        case 'line':
        case 'area':
        case 'scatter':
        case 'bar':
        case 'column':
        case 'radar':
        case 'mixed':
        case 'heatmap':
            return implode(',', !empty(GRAPHINA_DIVI_MANUAL_ELEMENT_DATA['area'][$count_number]) ?  GRAPHINA_DIVI_MANUAL_ELEMENT_DATA['area'][$count_number] : [250, 162, 593, 728, 335, 300]);
            break;
        case 'bubble':
            if (!empty(GRAPHINA_DIVI_MANUAL_ELEMENT_DATA['bubble'][$count_number])) {
                $data = GRAPHINA_DIVI_MANUAL_ELEMENT_DATA['bubble'][$count_number];
                $data = [
                    'x' => implode(',', (!empty($data['x']) ? $data['x'] : [])),
                    'y' => implode(',', (!empty($data['y']) ? $data['y'] : [])),
                    'z' => implode(',', (!empty($data['z']) ? $data['z'] : [])),
                ];
            } else {
                $data = [
                    'x' => '250,162,593,728,335,300,235,253,738,86,969,923,113,383,704,476,907,601,68,549',
                    'y' => '173,152,69,150,76,74,38,67,43,167,36,101,199,109,55,189,196,120,69,74',
                    'z' => '45,77,140,103,54,73,64,104,69,43,60,70,144,127,30,90,164,101,14,127',
                ];
            }
            return $data;
            break;
    }
}

