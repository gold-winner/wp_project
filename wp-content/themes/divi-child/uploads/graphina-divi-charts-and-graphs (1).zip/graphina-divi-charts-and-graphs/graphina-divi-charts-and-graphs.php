<?php
/*
Plugin Name: Graphina - Divi Charts and Graphs
Plugin URI:  https://iqonicthemes.com
Description: Your ultimate charts and graphs solution to enhance visual effects. Create versatile, advanced and interactive charts on your website.
Version:     1.1.2
Author:      Iqonic Design
Author URI:  https://iqonic.design/
Text Domain: grdi-graphina-divi
Domain Path: /languages
*/


if (file_exists(dirname(__FILE__) . '/vendor/autoload.php')) {
    require_once dirname(__FILE__) . '/vendor/autoload.php';
} else {
    die('Something went wrong');
}

use GRDIGraphina\GRDIAssetsManager;

if(!get_option('graphina_divi_dynamic_data_options_update')){
    $dynamic_data_options = [
        "csv","googlesheet","remote_csv",
        "api","sql_builder","external_database"
    ];
    $data = get_option('graphina_divi_common_setting',true);
    if(empty($data) || !is_array($data)) {
        $data = [];
    }
    $data['dynamic_data_options'] = $dynamic_data_options;
    update_option('graphina_divi_common_setting',$data);
    update_option('graphina_divi_dynamic_data_options_update','yes');
}
if(!defined('GRAPHINA_DIVI_BASE_PATH')){
    define( 'GRAPHINA_DIVI_BASE_PATH', plugin_basename(__FILE__) );
}

if(!defined('GRAPHINA_DIVI_BASE_URL')){
    define('GRAPHINA_DIVI_BASE_URL',plugin_dir_url(__FILE__));
}

if(!defined('GRAPHINA_DIVI_VERSION')){
    define( 'GRAPHINA_DIVI_VERSION', '1.1.2' );
}

if(!defined('GRAPHINA_DIVI_FILE')){
    define( 'GRAPHINA_DIVI_FILE', __FILE__ );
}

if(!defined('GRAPHINA_DIVI_DIR')){
    define( 'GRAPHINA_DIVI_DIR', plugin_dir_path( __FILE__ ) );
}

if (!defined('GRAPHINA_DIVI_URL')){
    define('GRAPHINA_DIVI_URL', plugins_url('', __FILE__));
}

if (!defined('GRAPHINA_DIVI_DATABASE_TABLES')){
    global $wpdb;

    $result = [];
    $dynamic_data_options = graphina_divi_common_setting_get('dynamic_data_options');
    if(is_array($dynamic_data_options) && in_array('sql_builder',$dynamic_data_options)){
       // phpcs:disable
        $tables = $wpdb->get_results('show tables', ARRAY_N);

        if ($tables) {
            $tables = wp_list_pluck($tables, 0);

            foreach ($tables as $table) {
                $tableList = [];
                $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) ;
                if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) ) === $table ) {
                    $column_names_query = $wpdb->prepare("DESC %i ", $table);
                    $column_names = $wpdb->get_col($column_names_query, 0);
                
                    // Loop through the column names and populate the $tableList array
                    foreach ($column_names as $column_name) {
                        $tableList[$column_name] = $column_name;
                    }
                   
                } else {
                    $tableList = ['no_data' => 'No Columns Found'];
                }
                $result[$table] = $tableList;
            }
        }
        // phpcs:enable
    }
    define('GRAPHINA_DIVI_DATABASE_TABLES', $result);
}

if (!defined('GRAPHINA_DIVI_MANUAL_ELEMENT_DATA')){
    define('GRAPHINA_DIVI_MANUAL_ELEMENT_DATA', require_once GRAPHINA_DIVI_DIR . 'sample-file/manual-data/chart-data.php');
}

if (!defined('GRAPHINA_DIVI_EXTERNAL_DATABASE_TABLES')){
    $table_column = [];
    $dynamic_data_options = graphina_divi_common_setting_get('dynamic_data_options');
    if(is_array($dynamic_data_options) && in_array('external_database',$dynamic_data_options)){
        $externalDatabase = graphina_divi_check_external_database('data');
        $externalDatabase = !empty($externalDatabase) && is_array($externalDatabase) && count($externalDatabase) > 0 ? $externalDatabase : [];
        foreach ($externalDatabase as $ex){
            $new_wpdb = new wpdb( $ex['user_name'],$ex['pass'],$ex['db_name'],$ex['host']);
            $columns = $new_wpdb->get_results( "SELECT COLUMN_NAME, TABLE_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '{$new_wpdb->dbname}'" );
            // Loop through the columns
            foreach ( $columns as $column ) {
                // Output the column name and table name
                $table_column[$ex['con_name']][$column->TABLE_NAME][$column->COLUMN_NAME] =  $column->COLUMN_NAME ;
            }
            $new_wpdb->close();
        }
    }
    define('GRAPHINA_DIVI_EXTERNAL_DATABASE_TABLES', $table_column);
}

add_action('plugins_loaded', function (){
    load_plugin_textdomain( 'grdi-graphina-divi', false, dirname( GRAPHINA_DIVI_BASE_PATH ) . '/languages/');
});

add_action('admin_notices', 'graphinaDiviCheckRequiredPlugin');

/**
 * Creates the extension's main class instance.
 *
 * @since 1.0.0
 */
add_action( 'divi_extensions_init', function() {
    require_once plugin_dir_path( __FILE__ ) . 'includes/GRDIGraphinaDivi.php';
    (new GRDIAssetsManager());
} );

require_once plugin_dir_path(__FILE__) . 'admin/class-graphina-divi-charts-and-graphs.php';

(new Graphina_Charts_For_Divi_Admin('1.1.2'));
