const googleDiviChartList = ['gauge_google','geo_google'];
if (typeof graphinaDiviIsInit === "undefined") {
    var graphinaDiviIsInit = {};
}

function graphinaBuilderGoogleChartInit(ele,options,type,id){
    graphinaDiviResetVars();
    if (id in graphina_divi_localize.graphinaAllGraphs) {
        graphina_divi_localize.graphinaAllGraphs[id].clearChart();
        delete graphina_divi_localize.graphinaAllGraphs[id];
        delete graphina_divi_localize.graphinaBlockCharts[id];
    }
    graphinaDiviIsInit[id] = false;
    graphina_divi_localize.graphinaAllGraphsOptions[id] = options;
    if( ele !== null){
        if(graphina_divi_localize.is_view_port_disable !== undefined && graphina_divi_localize.is_view_port_disable === 'on'){
            graphinaBuilderGoogleChartRender(id,type);
        }else{
            const observer = new IntersectionObserver(enteries => {
                enteries.forEach(entry =>{
                    if(entry.isIntersecting){
                        if (graphinaDiviIsInit[id] === false) {
                            graphinaBuilderGoogleChartRender(id,type);
                        }
                    }
                })
            })
            observer.observe(ele);
        }
    }
}

function graphinaBuilderGoogleChartRender(id,type){
    if(graphinaDiviIsInit[id] !== true){
        graphina_divi_localize.graphinaAllGraphs[id] = new window.google.visualization[graphina_divi_localize.graphinaAllGraphsOptions[id].renderType](graphina_divi_localize.graphinaAllGraphsOptions[id].ele);
        graphina_divi_localize.graphinaAllGraphs[id].draw(graphina_divi_localize.graphinaAllGraphsOptions[id].series, graphina_divi_localize.graphinaAllGraphsOptions[id].options);
        graphinaDiviIsInit[id] = true;
    }
}

function graphinaDiviRenderChart(ele,data,type,id){
    graphinaDiviResetVars();
    if (id in graphina_divi_localize.graphinaAllGraphs) {
        graphina_divi_localize.graphinaAllGraphs[id].destroy();
        delete graphina_divi_localize.graphinaAllGraphs[id];
        delete graphina_divi_localize.graphinaAllGraphsOptions[id];
        delete graphina_divi_localize.graphinaBlockCharts[id];
    }
    graphinaDiviIsInit[id] = false;
    graphina_divi_localize.graphinaAllGraphsOptions[id] = data;
    graphinaDiviGetChart(id);
}

function graphinaDiviGetChart(id){
    if (typeof ApexCharts === 'function' && graphina_divi_localize.graphinaAllGraphsOptions[id].ele !== null
        && (id in graphinaDiviIsInit) && graphinaDiviIsInit[id] === false) {
        if(graphina_divi_localize.is_view_port_disable !== undefined && graphina_divi_localize.is_view_port_disable === 'on'){
            graphinaDiviInitORUpdateGraphinaCharts(id);
        }else{
            const observer = new IntersectionObserver(enteries => {
                enteries.forEach(entry =>{
                    if(entry.isIntersecting && graphinaDiviIsInit[id] === false){
                        graphinaDiviInitORUpdateGraphinaCharts(id);
                    }
                })
            })
            observer.observe(graphina_divi_localize.graphinaAllGraphsOptions[id].ele);
        }
    }
}

function graphinaDiviInitORUpdateGraphinaCharts(id,type='area'){
    if(Object.keys(graphina_divi_localize.graphinaBlockCharts).includes(id)){
        if (graphinaDiviIsInit[id] === true){
            graphina_divi_localize.graphinaAllGraphs[id].destroy();
        }
        if(googleDiviChartList.includes(type)){
            if (graphinaDiviIsInit[id] === true){
                graphina_divi_localize.graphinaAllGraphs[id].clearChart();
            }
        }
        graphina_divi_localize.graphinaAllGraphsOptions[id].ele.innerHTML='';
        graphina_divi_localize.graphinaAllGraphsOptions[id].ele.innerHTML = graphina_divi_localize.graphinaBlockCharts[id];
    }else {
        if (graphinaDiviIsInit[id] === true || graphina_divi_localize.graphinaAllGraphs[id]) {
            if(googleDiviChartList.includes(type)){
                if (graphinaDiviIsInit[id] === true){
                    graphina_divi_localize.graphinaAllGraphs[id].draw(graphina_divi_localize.graphinaAllGraphsOptions[id].series,graphina_divi_localize.graphinaAllGraphsOptions[id].options);
                }
            }else{
                graphina_divi_localize.graphinaAllGraphsOptions[id].options.series = graphina_divi_localize.graphinaAllGraphsOptions[id].series;
                if(['line','bar','column','area','scatter','bubble','heatmap','radar','mixed','distributed_column'].includes(type)){
                    graphina_divi_localize.graphinaAllGraphsOptions[id].options.xaxis.categories = graphina_divi_localize.graphinaAllGraphsOptions[id].category
                }else {
                    graphina_divi_localize.graphinaAllGraphsOptions[id].options.labels = graphina_divi_localize.graphinaAllGraphsOptions[id].category;
                }
                graphina_divi_localize.graphinaAllGraphs[id].updateOptions(graphina_divi_localize.graphinaAllGraphsOptions[id].options);
            }

        } else {
            if(googleDiviChartList.includes(type)){
                graphinaBuilderGoogleChartRender(id,type)
            }else{
                graphinaDiviChartsFirstTimeInit(id)
            }
        }
    }
}

function graphinaDiviChartsFirstTimeInit(id){
    graphina_divi_localize.graphinaAllGraphsOptions[id].options.chart.animations.enabled = graphina_divi_localize.graphinaAllGraphsOptions[id].animation
    graphina_divi_localize.graphinaAllGraphs[id] = new ApexCharts(graphina_divi_localize.graphinaAllGraphsOptions[id].ele, graphina_divi_localize.graphinaAllGraphsOptions[id].options);
    graphina_divi_localize.graphinaAllGraphs[id].render();
    graphinaDiviIsInit[id] = true;
}
function graphinaDiviResetVars(){
    if(typeof graphina_divi_localize.graphinaAllGraphs === "undefined"){
        graphina_divi_localize.graphinaAllGraphs = {};
    }
    if(typeof graphina_divi_localize.graphinaAllGraphsOptions === "undefined"){
        graphina_divi_localize.graphinaAllGraphsOptions = {};
    }
}

function graphinaDiviGetDataForChartAjax(setting,type,id){
    jQuery.ajax({
        url: graphina_divi_localize.ajaxurl,
        type: "post",
        data: {
            type:type,
            id:id,
            action:'graphina_divi_get_dynamic_data',
            security: window.graphina_divi_localize.nonce ,  // Add nonce here
            dataType:'simple',
            setting:setting,
        },
        success: function (response) {
            if(document.getElementById(id).length === 0) {
                return 0;
            }
            if (response.status === true) {
                if(googleDiviChartList.includes(type)){
                    jQuery('#loader-chart-icon'+id).css('display','none')
                    jQuery('#'+id).removeClass('d-none')
                    let row = graphina_divi_localize.graphinaAllGraphsOptions[id].series.getNumberOfRows();
                    if(row > 0){
                        graphina_divi_localize.graphinaAllGraphsOptions[id].series.removeRows(0,row)
                    }
                    graphina_divi_localize.graphinaAllGraphsOptions[id].series.addRows(response.googlechart_data)
                    if(type === 'geo_google'){

                        let existingOptions = graphina_divi_localize.graphinaAllGraphsOptions[id].options;
                        let colorAxisOptions = existingOptions.colorAxis || {}; // In case colorAxis is not defined

                        graphina_divi_localize.graphinaAllGraphsOptions[id].options = Object.assign(
                        {},
                        existingOptions,
                        {
                            colorAxis: Object.assign({}, colorAxisOptions, {
                            colors: response.color
                            })
                        }
                        );

                    }
                }else{
                    graphina_divi_localize.graphinaAllGraphsOptions[id].series = response.data.series;
                    graphina_divi_localize.graphinaAllGraphsOptions[id].category = response.data.category;
                }
                if(type === 'radar'){
                    graphina_divi_localize.graphinaAllGraphsOptions[id].options.xaxis.labels.style.colors = new Array(response.data.category.length).fill(setting.xaxis_label_color !== undefined ? setting.xaxis_label_color : '#000000' )
                }
                if (response.instant_init === true) {
                    graphinaDiviChartsFirstTimeInit(id);
                    graphina_divi_localize.graphinaAllGraphsOptions[id].animation = false;
                }

                graphinaDiviInitORUpdateGraphinaCharts(id,type);

            }else{
                if(googleDiviChartList.includes(type)){
                    jQuery('#loader-chart-icon'+id).css('display','none')
                    jQuery('#'+id).removeClass('d-none')
                    let row = graphina_divi_localize.graphinaAllGraphsOptions[id].series.getNumberOfRows();
                    if(row > 0){
                        graphina_divi_localize.graphinaAllGraphsOptions[id].series.removeRows(0,row)
                    }
                    graphina_divi_localize.graphinaAllGraphsOptions[id].series.addRows(response.googlechart_data)
                    if(type === 'geo_google'){
                        let existingOptions = graphina_divi_localize.graphinaAllGraphsOptions[id].options;
                        let colorAxisOptions = existingOptions.colorAxis || {}; // In case colorAxis is not defined

                        graphina_divi_localize.graphinaAllGraphsOptions[id].options = Object.assign(
                        {},
                        existingOptions,
                        {
                            colorAxis: Object.assign({}, colorAxisOptions, {
                            colors: response.colors
                            })
                        }
                        );

                    }
                }
                if(typeof response.fail_message !== 'undefined' ){
                    graphina_divi_localize.graphinaBlockCharts[id] = response.fail_message;
                }else{
                    graphina_divi_localize.graphinaAllGraphsOptions[id].options.noData.text = 'No data Found'
                }
                graphinaDiviInitORUpdateGraphinaCharts(id);
            }
        },
        error: function () {
            console.log('fail');
        }
    });
}

function graphinaDiviDynamicData(setting,type,id,ajaxReload,ajaxReloadTime){
    
    if (window['ajaxIntervalGraphina_' + id] !== undefined) {
        clearInterval(window['ajaxIntervalGraphina_' + id]);
    }

    if(setting.data_type !== undefined && setting.data_type !== 'manual'
        && typeof graphinaDiviGetDataForChartAjax !== "undefined"){
        if(googleDiviChartList.includes(type)){
            jQuery('#loader-chart-icon'+id).css('display','flex')
            jQuery('#'+id).addClass('d-none')
        }
        graphinaDiviGetDataForChartAjax(setting, type, id);
        if (ajaxReload === 'true') {
            window['ajaxIntervalGraphina_' + id] = setInterval(function () {
                graphinaDiviGetDataForChartAjax(setting, type, id);
            }, parseInt(ajaxReloadTime) * 1000);
        }
    }
    if(setting.data_type !== undefined && setting.data_type !== 'manual'
        && typeof elementordataAjax !== "undefined"){
        if(googleDiviChartList.includes(type)){
            jQuery('#loader-chart-icon'+id).css('display','flex')
            jQuery('#'+id).addClass('d-none')
        }
        elementordataAjax(setting, type, id);
        if (ajaxReload === 'true') {
            window['ajaxIntervalGraphina_' + id] = setInterval(function () {
                elementordataAjax(setting, type, id);
            }, parseInt(ajaxReloadTime) * 1000);
        }
    }
}

window.graphinaDiviNumberThousandSeperate = function(x, decimal = -1) {
    let separator = graphina_divi_localize.thousand_seperator;
    if(separator.trim === ''){
        return x
    }
    if ( isNaN(x)) {
        return x;
    }
    var parts = x.toString().split(".");
    let val = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, separator);

    if (parts[1]) {
        if (decimal === -1) {
            val = val + '.' + parts[1]
        }else if (decimal !== 0) {
            val = val + '.' + parts[1].substring(0, decimal)
        }
    }

    return val;
}