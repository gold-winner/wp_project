jQuery(document).ready(function($) {
   
    jQuery(document).on('keyup', '#et-fb-sql_builder_mysql_query', function() {

         var inputValue = jQuery(this).val();

         jQuery.ajax({ 
             type: 'POST', 
             url: window.graphina_divi_localize.ajaxurl,
             dataType: 'json', 
         data: { 
             action: 'extractTableName', 
             security: window.graphina_divi_localize.nonce, // Pass the nonce for verification

             input_value: inputValue },
         success: function(response) {
             if(response.table_name){
                 jQuery('#et-fb-sql_builder_table').attr('style','display:none !important');
                 jQuery('#et-fb-sql_builder_table').trigger('click');

                 console.log('.select-option-item-'+response.table_name);
                 jQuery('.select-option-item-'+response.table_name).trigger('click');
                 jQuery('#et-fb-sql_builder_table').attr('style','display:block !important');
             }
               

             },
     
         });
     });

});
