function queryStringToObject(queryString) {
    const pairs = queryString.substring(0).split('&');

    var array = pairs.map((el) => {
        const parts = el.split('=');
        return parts;
    });

    return Object.fromEntries(array);
}

        jQuery(document).ajaxComplete(function(event, xhr, settings) {

            let payload = queryStringToObject(settings.data);
            if (payload.action === "et_fb_ajax_save") {
            // Get the page ID from the body class
            const pageId = document.querySelector('body').classList.value.match(/page-id-(\d+)/);
            // Extract the page ID from the match
            const pageIdValue = pageId ? pageId[1] : null;
		    //   if (jQuery('#graphina_divibasetable').length > 0) {
            jQuery('table[id^="graphina_divibasetable"]').each(function() {
                var columnHeaders = [];
                var showIndexValue = jQuery(this).attr('show_index');
                if (jQuery(this).find('thead').length > 0) {
                    jQuery(this).find('thead th').each(function(index) {
                        if(showIndexValue === "on" && index === 0 ){
                            console.log("wrong Header");
                        }else{
                            columnHeaders.push(jQuery(this).text());
                        }
                    });
                }
                var tableRows = [];
                jQuery(this).find('tbody tr').each(function() {
                    var rowData = [];
                    jQuery(this).find('td').each(function(index) {
                        if(showIndexValue === "on" && index === 0){
                            console.log("wrong index");
                        }else{
                            rowData.push(jQuery(this).text());
                        }
                    });
                    tableRows.push(rowData);
                });
                var table_id = jQuery(this).attr('grpid');
                var currentData = {
                    body: tableRows
                };
                // Check if columnHeaders array is not empty and add it to currentData if it's not
                if (columnHeaders.length > 0) {
                    currentData.headers = columnHeaders;
                }
                jQuery.ajax({
                    url: window.et_fb_options.ajaxurl,
                    type: 'post',
                    data: {
                        type: 'datatable',
                        id: table_id,
                        page_id: pageIdValue,
                        action: 'savetabledata_divigraph',
                        security: graphina_divi_localize.nonce,
                        current_data: currentData
                    },
                    success: function(response) {
                        console.log('Data saved for table ID: ' + table_id);
                    },
                    error: function(xhr, status, error) {
                        console.error('Error saving data for table ID: ' + table_id);
                    }
                });
            });
            }

	// }
});