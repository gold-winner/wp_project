<?php
class Graphina_Charts_For_Divi_Admin{


    public function __construct(){

        $this->plugin_menu_page();

        //add menu page
        add_action('admin_menu',  array($this,'admin_menu'));

        //setting page ajax
        add_action('wp_ajax_graphina_divi_admin_setting',array($this,'admin_setting_save'));

        //open documentation and product request page in new tab
        add_action( 'admin_head',array($this,'admin_head'));
    }

    public function admin_head(){
        ?>
        <script type="text/javascript">
            jQuery(document).ready( function($) {
                jQuery(document).find('ul.wp-submenu a[href="https://apps.iqonic.design/docs/product/graphina-divi-charts-and-graphs"]').attr( 'target', '_blank' );
                jQuery(document).find('ul.wp-submenu a[href="https://iqonic.design/feature-request/?for_product=graphina"]').attr( 'target', '_blank' );
            });
        </script>
        <?php
    }

    public function plugin_menu_page(){
        if(isset($_REQUEST['page']) && $_REQUEST['page'] === "graphina-divi-chart"){ // phpcs:ignore WordPress.Security.NonceVerification.Recommended

            add_action('admin_head', function (){
                remove_all_actions('admin_notices');
                remove_all_actions('all_admin_notices');
            });

            add_action('admin_enqueue_scripts', function (){
                wp_enqueue_style( 'bootstrap', GRAPHINA_DIVI_BASE_URL . 'admin/assets/css/bootstrap.min.css', array(), GRAPHINA_DIVI_VERSION );
                wp_enqueue_style( 'select2-bootstrap',  GRAPHINA_DIVI_BASE_URL . 'admin/assets/css/select2-bootstrap-5-theme.min.css', array(), GRAPHINA_DIVI_VERSION );
                wp_enqueue_style( 'select2',  GRAPHINA_DIVI_BASE_URL . 'admin/assets/css/select2.min.css', array(), GRAPHINA_DIVI_VERSION );
                wp_enqueue_style('sweetalert2', GRAPHINA_DIVI_BASE_URL . 'admin/assets/css/sweetalert2.min.css', array(), GRAPHINA_DIVI_VERSION);
                wp_enqueue_script('sweetalert2', GRAPHINA_DIVI_BASE_URL . 'admin/assets/js/sweetalert2.min.js', array('jquery'), GRAPHINA_DIVI_VERSION, true);
                wp_enqueue_script('select2', GRAPHINA_DIVI_BASE_URL . 'admin/assets/js/select2.min.js', array('jquery'), GRAPHINA_DIVI_VERSION, false);
                wp_enqueue_script('graphina-divi-admin-custom', GRAPHINA_DIVI_BASE_URL . 'admin/assets/js/graphina-divi-custom-admin.js', array('jquery'), GRAPHINA_DIVI_VERSION,false );
                wp_localize_script('graphina-divi-admin-custom', 'localize_admin', array(
                    'ajaxurl' => admin_url('admin-ajax.php'),
                    'adminurl' => admin_url(),
                    'swal_are_you_sure_text' => esc_html__('Are you sure?' ,'grdi-graphina-divi'),
                    'swal_revert_this_text' => esc_html__('You won\'t be able to revert this!' ,'grdi-graphina-divi'),
                    'swal_delete_text' => esc_html__('Yes, delete it!' ,'grdi-graphina-divi'),
                    'loading' => esc_html__('Loading...' ,'grdi-graphina-divi'),
                    'nonce' => wp_create_nonce('ajax-nonce'),
                ));
            });

            add_action( 'admin_enqueue_scripts', function (){
                global $wp_scripts, $wp_styles;
                // Loop through the registered scripts
                foreach ( $wp_scripts->registered as $handle => $script ) {
                    // Check if the script was registered by another plugin
                    if ( strpos( $script->src, '/plugins/' ) !== false && strpos( $script->src, GRAPHINA_DIVI_BASE_URL ) === false) {
                        // Unregister the script
                        wp_deregister_script( $handle );
                    }
                }

                // Loop through the registered styles
                foreach ( $wp_styles->registered as $handle => $style ) {
                    // Check if the style was registered by another plugin
                    if(strpos( $style->src, '/plugins/' ) !== false && strpos( $style->src, GRAPHINA_DIVI_BASE_URL ) === false){
                        wp_deregister_style( $handle );
                    }
                }
            },PHP_INT_MAX);
        }
    }

    public function admin_menu(){
        if (current_user_can('manage_options')) {
            add_menu_page(
                __('Graphina Divi Charts', 'grdi-graphina-divi'),
                __('Graphina Divi Charts', 'grdi-graphina-divi'),
                "manage_options",
                "graphina-divi-chart",
                function (){
                    require_once  GRAPHINA_DIVI_DIR.'admin/assets/pages/menu_page.php' ;
                },
                GRAPHINA_DIVI_BASE_URL . 'admin/assets/images/graphina.svg',
                100
            );
            add_submenu_page(
                "graphina-divi-chart",
                __('Graphina Divi Charts Setting', 'grdi-graphina-divi'),
                __('Settings', 'grdi-graphina-divi'),
                'manage_options',
                'graphina-divi-chart'
            );
            add_submenu_page(
                "graphina-divi-chart",
                __('Graphina Divi Charts Documentation', 'grdi-graphina-divi'),
                __('Documentation', 'grdi-graphina-divi'),
                'manage_options',
                'https://apps.iqonic.design/docs/product/graphina-divi-charts-and-graphs'
            );
            add_submenu_page(
                "graphina-divi-chart",
                __('Graphina Divi Charts Request Feature', 'grdi-graphina-divi'),
                __('Request a Feature', 'grdi-graphina-divi'),
                'manage_options',
                'https://iqonic.design/feature-request/?for_product=graphina'
            );
        }
    }

    public function admin_setting_save(){

        $postData = graphinaDiviRecursiveSanitizeTextField($_POST); //phpcs:ignore WordPress.Security.NonceVerification.Missing

        $response = [
            'status' => false,
            'message' => esc_html__("Setting not saved", 'grdi-graphina-divi'),
            'subMessage' => ''
        ];

        if ( ! wp_verify_nonce( $postData['nonce'], 'ajax-nonce' ) ) {
            $response['message'] = esc_html__("Invalid nonce", 'grdi-graphina-divi');
            wp_send_json($response);
            die;
        }
        unset($postData['nonce']);

        if(!in_array($postData['route'],['external_database_connection_save','external_database_connection_delete','external_database_connection_list','general_setting'])){
            $response['message'] = esc_html__("Invalid route", 'grdi-graphina-divi');
            wp_send_json($response);
            die;
        }
        $route = $postData['route'];
        unset($postData['route']);

        $postData['view_port'] = isset($postData['view_port']) ? $postData['view_port'] : "off";
        switch ($route){
            //general setting page
            case 'general_setting':
                if (!empty($postData)) {
                    update_option('graphina_divi_common_setting', $postData);
                    $response['status'] = true;
                    $response['message'] = esc_html__("Setting saved", 'grdi-graphina-divi');
                    $response['subMessage'] = esc_html__('Your setting has been saved!','grdi-graphina-divi');
                }
                break;
            //external database connection list
            case 'external_database_connection_list':
                $response['data'] =  $this->configurationTable();
                $response['status'] =  true;
                break;
            //external database save and update
            case 'external_database_connection_save':
                $data = get_option('graphina_divi_mysql_database_setting',true);
                $data = !empty($data) && is_array($data) ? $data : [];
                //check configuration before saving
                $connectionDetail = $this->checkDataBaseConnection($postData);
                if(!$connectionDetail['status']){
                    $response['status'] = $connectionDetail['status'];
                    $response['message'] = $connectionDetail['message'];
                }else{
                    $data[$postData['con_name']] = $postData;
                    update_option('graphina_divi_mysql_database_setting',$data);
                    $response['status'] = true;
                    $response['message'] = esc_html__('Connection Details Saved','grdi-graphina-divi');
                }
                break;
            //external database delete
            case 'external_database_connection_delete':
                $data = get_option('graphina_divi_mysql_database_setting',true);
                $data = !empty($data) && is_array($data) ? $data : [];
                $response['message'] = esc_html__('Connection Name not found','grdi-graphina-divi');
                //check if connection value is exists
                if(array_key_exists($postData['value'],$data)){
                    unset($data[$postData['value']]);
                    update_option('graphina_divi_mysql_database_setting',$data);
                    $response['status'] = true;
                    $response['message'] = esc_html__('Connection name delete','grdi-graphina-divi');
                }
                break;
        }
        wp_send_json($response);
        die;
    }

    public function checkDataBaseConnection($data){

        $status = false;
        $message = esc_html__('Connection Detail Not Found', 'grdi-graphina-divi');
        if (!empty($data['host']) && !empty($data['user_name']) && isset($data['pass']) && !empty($data['db_name']) && !empty($data['con_name'])) {
            try {
                global $wpdb;
                $wpdb->dbhost = $data['host'];
                $wpdb->dbname = $data['db_name'];
                $wpdb->dbuser = $data['user_name'];
                $wpdb->dbpassword = $data['pass'];
                $result = $wpdb->db_connect();
    
                if (is_wpdb_error($result)) {
                    $message = esc_html($result->get_error_message());
                } else {
                    $status = true;
                    $message = esc_html__('Successfully connected', 'grdi-graphina-divi');
                }
            } catch (Exception $e) {
                return ['data' => '', 'status' => false, 'message' => $e->getMessage()];
            }
        }
        return ['data' => '', 'status' => $status, 'message' => $message];
    }

    public function configurationTable(){
        ob_start();
        if(graphina_divi_check_external_database('status')){
            $connection_list = graphina_divi_check_external_database('data');
            $connection_list = !empty($connection_list) && is_array($connection_list) && count($connection_list) > 0 ? $connection_list : [];
            if(!empty($connection_list)){
                ?>
                <div class="row m-2 mt-4">
                    <div class="col-12">
                        <table class="table border">
                            <thead class="thead-dark">
                            <tr>
                                <th scope="col"><?php echo esc_html__("Connection Name", 'grdi-graphina-divi') ?></th>
                                <th scope="col"><?php echo esc_html__("Action", 'grdi-graphina-divi') ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php
                            foreach ($connection_list as $key => $value) {
                                ?>
                                <tr>
                                    <th><?php echo esc_html($value['con_name']); ?></th>
                                    <td>
                                        <div class="d-flex justify-content-start align-items-center">
                                            <button class="btn btn-primary edit"  data-selected='<?php echo wp_json_encode($value); ?>'>
                                                <?php echo esc_html__("Edit", 'grdi-graphina-divi'); ?>
                                            </button>
                                            <button class="btn btn-danger mx-2 delete" data-selected="<?php echo esc_html($value['con_name']); ?>">
                                                <?php echo esc_html__("Delete", 'grdi-graphina-divi'); ?>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <?php
                            } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php
            }
        }
        return ob_get_clean();
    }
}