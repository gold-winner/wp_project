(function ($) {
	$(document).on('ready', () => {
		$("#graphina_divi_settings_tab").on('submit', function (event) {
			event.preventDefault();
			graphinaDiviAjax(jQuery(this).serialize(),'setting_save',jQuery(this).find('button[type="submit"]'))
		});
		$("#graphina-div-external-database-tab").on("submit", function (event) {
			event.preventDefault()
			graphinaDiviAjax(jQuery(this).serialize(),'external_database_save_edit',jQuery(this).find('button[type="submit"]'))
		});
		$("#graphina-div-external-database-tab #reset_button").on("click", function (event) {
			event.preventDefault()
			graphinaDiviResetForm('graphina-div-external-database-tab')
		});
		$("#dynamic_data_options").select2({
			tags: true,
			theme: "bootstrap-5",
			width: $( this ).data( 'width' ) ? $( this ).data( 'width' ) : $( this ).hasClass( 'w-100' ) ? '100%' : 'style',
		});
	});
})(jQuery);

function graphinaDiviTable(){
	graphinaDiviAjax({
		action: 'graphina_divi_admin_setting',
		nonce:localize_admin.nonce,
		route:'external_database_connection_list'
	},'external_database_table',)
}

function graphinaDiviResetForm(form){
	jQuery('#'+form+' input[type="text"]').val('');
	jQuery('#'+form+' input[type="password"]').val('');
}

function graphinaDiviAjax(data,type,button = ''){
	let oldText = ''
	let buttonLoader = !['external_database_delete' ,'external_database_table'].includes(type);
	if(buttonLoader){
		oldText = button.html();
		button.html(localize_admin.loading)
	}
	jQuery.ajax({
		url: localize_admin.ajaxurl,
		type: "POST",
		data: data,
		success: function (response) {
			if(buttonLoader){
				button.html(oldText)
			}
			if (response.status !== undefined && [true,'true'].includes(response.status)) {
				switch (type){
					case 'external_database_delete':
						graphinaDiviTable();
						break;
					case 'external_database_save_edit':
						graphinaDiviResetForm('graphina-div-external-database-tab')
						graphinaDiviTable();
						Swal.fire({
							title: response.message,
							text: response.subMessage
						})
						break;
					case 'external_database_table':
						graphinaDiviLoadFuntion(response.data)
						break;
					case 'setting_save':
						Swal.fire({
							title: response.message,
							text: response.subMessage
						})
						break;
				}
			}else{
				console.log(response)
				Swal.fire({
					title: 'Error',
					text: response.message,
					icon: 'error',
					confirmButtonColor: '#dc3545',
				})
			}
		},
		error:function (error){
			console.log(error)
			if(buttonLoader){
				button.html(oldText)
			}
		}
	});
}

function graphinaDiviLoadFuntion(data){
	jQuery('#graphina-divi-configuration-table').html(data)
	jQuery("#graphina-divi-configuration-table .edit").on("click", function (event) {
		event.preventDefault()
		let selected_value = this.getAttribute("data-selected")
		if(!selected_value){
			console.log(selected_value,"name not found")
			return
		}
		selected_value = selected_value.replace('/','')
		selected_value = JSON.parse(selected_value);
		Object.keys(selected_value).map((value,key) => {
			document.querySelector("#graphina-div-external-database-tab [name='"+value +"']").value = selected_value[value];
		})
	});
	jQuery("#graphina-divi-configuration-table .delete").click(function () {
		event.preventDefault()
		let selected_value = this.getAttribute("data-selected")
		if(!selected_value){
			console.log(selected_value,"name not found")
			return
		}
		Swal.fire({
			title: localize_admin.swal_are_you_sure_text,
			text: localize_admin.swal_revert_this_text,
			icon: 'warning',
			showCancelButton: true,
			confirmButtonColor: '#3085d6',
			cancelButtonColor: '#d33',
			confirmButtonText: localize_admin.swal_delete_text
		}).then((result) => {
			if (result.isConfirmed) {
				graphinaDiviAjax({
					action: 'graphina_divi_admin_setting',
					route:'external_database_connection_delete',
					value: selected_value,
					nonce:localize_admin.nonce
				},'external_database_delete')
			}
		})
	});
}