<style>
    .nav-link.active:hover,
    .nav-link.active {
        border-color: #0d6efd #0d6efd #fff !important;
        color: #0d6efd !important;
    }
    .nav-link {
        color: #495057 !important;
    }
    .nav-link:hover{
        border-color: #fff !important;
    }
</style>
<?php
if(current_user_can( 'manage_options' )){
    $activeTab='setting';
    if(isset($_GET['activetab']) && !empty($_GET['activetab'])){ // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $activeTab = sanitize_text_field(wp_unslash($_GET['activetab'])); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    }
    $grdi_tabs = [
        [
            'label' => __("Settings", "grdi-graphina-divi"),
            'url' => admin_url() . 'admin.php?page=graphina-divi-chart&activetab=setting',
            'active' => $activeTab =='setting' ? 'active' : ''
        ],
        [
            'label' => __("External Database", "grdi-graphina-divi"),
            'url' => admin_url() . 'admin.php?page=graphina-divi-chart&activetab=database',
            'active' => $activeTab =='database' ? 'active' : ''
        ]
    ]
    ?>
    <div class="container-fluid mt-3">
        <ul class="nav nav-tabs">
            <?php
            foreach ($grdi_tabs as $grdi_tab){
                ?>
                <li class="nav-item">
                    <a class="nav-link <?php echo esc_html($grdi_tab['active']);?>" aria-current="page" href="<?php echo esc_html($grdi_tab['url']);?>"><?php echo esc_html($grdi_tab['label']);?></a>
                </li>
                <?php
            }
            ?>
        </ul>
        <div class="tab-content">
            <?php
            switch ($activeTab){
                case "setting":
                    $data = !empty( $value = get_option('graphina_divi_common_setting',true)) ? $value : [];
                    $dynamic_data_options = !empty($data['dynamic_data_options']) && is_array($data['dynamic_data_options']) ? $data['dynamic_data_options'] : [];
                    ?>
                    <style>
                        #graphina_divi_settings_tab .select2-search__field{
                            width:unset !important;
                        }
                        #graphina_divi_settings_tab .select2-container--bootstrap-5 .select2-selection--multiple .select2-selection__rendered{
                            display: flex !important;
                        }
                        #graphina_divi_settings_tab .select2-selection__choice{
                            background-color: var(--bs-gray-200);
                            border: none !important;
                            font-size: 0.85rem !important;
                        }
                    </style>
                    <form id="graphina_divi_settings_tab">
                        <div class="row g-3 align-items-center m-2">
                            <div class="col-auto">
                                <label for="dynamic_data_options" class="col-form-label"><?php echo esc_html__("Dynamic data options",'grdi-graphina-divi');?></label>
                            </div>
                            <div class="col-auto">
                                <select multiple id="dynamic_data_options" name="dynamic_data_options[]" class="form-select form-control">
                                    <option value="csv" <?php echo in_array('csv',$dynamic_data_options) ? 'selected' : ''?> ><?php echo esc_html__("CSV",'grdi-graphina-divi');?></option>
                                    <option value="googlesheet" <?php echo in_array('googlesheet',$dynamic_data_options) ? 'selected' : ''?>><?php echo esc_html__("Google-sheet",'grdi-graphina-divi');?></option>
                                    <option value="remote_csv" <?php echo in_array('remote_csv',$dynamic_data_options) ? 'selected' : ''?>><?php echo esc_html__("Remote CSV",'grdi-graphina-divi');?></option>
                                    <option value="api" <?php echo in_array('api',$dynamic_data_options) ? 'selected' : ''?>><?php echo esc_html__("API",'grdi-graphina-divi');?></option>
                                    <option value="sql_builder" <?php echo in_array('sql_builder',$dynamic_data_options) ? 'selected' : ''?>><?php echo esc_html__("Sql-builder",'grdi-graphina-divi');?></option>
                                    <option value="external_database" <?php echo in_array('external_database',$dynamic_data_options) ? 'selected' : ''?>><?php echo esc_html__("External database",'grdi-graphina-divi');?></option>
                                </select>
                            </div>
                        </div>
                        <div class="row g-3 align-items-center m-2">
                            <div class="col-auto">
                                <label for="thousand_seperator" class="col-form-label"><?php echo esc_html__("Thousand Separator: ",'grdi-graphina-divi');?></label>
                            </div>
                            <div class="col-auto">
                                <input id="thousand_seperator" class="form-control" type="text" name="thousand_seperator" value="<?php echo esc_html(!empty($data['thousand_seperator']) ? $data['thousand_seperator']: ",") ?>">
                            </div>
                        </div>
                        <div class="row g-3 align-items-center m-2">
                            <div class="col-auto">
                                <label for="csv_seperator" class="col-form-label"><?php echo esc_html__("CSV Separator :",'grdi-graphina-divi');?></label>
                            </div>
                            <div class="col-auto">
                                <select id="csv_seperator"  class="form-control"  name="csv_seperator">
                                    <option name="comma" value="comma" <?php echo esc_html( !empty($data['csv_seperator']) && $data['csv_seperator']=='comma' ? "selected": '');?> ><?php echo esc_html__("Comma",'grdi-graphina-divi');?></option>
                                    <option name="semicolon" value="semicolon" <?php echo esc_html(!empty($data['csv_seperator']) && $data['csv_seperator']=='semicolon' ? "selected": '');?> ><?php echo esc_html__("Semicolon",'grdi-graphina-divi');?></option>
                                </select>
                            </div>
                        </div>
                        <div class="row g-3 align-items-center m-2">
                            <div class="col-auto">
                                <label for="view_port" class="col-form-label"><?php echo esc_html__("View Port",'grdi-graphina-divi');?></label>
                            </div>
                            <div class="col-auto">
                                <input  type="checkbox"  class="form-control" id="view_port" name="view_port" <?php echo esc_html( !empty($data['view_port']) && $data['view_port'] =='on' ? "checked": '');?> >
                            </div>
                            <div class="col-auto">
                                <span id="view_portInline" class="form-text">
                                     <?php echo esc_html__('Note : Disable  chart and counter render when it come in viewport ,render chart and counter when page load (default chart and counter are render when it in viewport)','grdi-graphina-divi')?>
                                </span>
                            </div>
                        </div>
                        <div>
                            <input type="hidden" name="route" value="general_setting">
                            <input type="hidden" name="action" value="graphina_divi_admin_setting">
                            <input type="hidden" name="nonce" value="<?php echo  esc_html(wp_create_nonce('ajax-nonce'));?>">
                        </div>
                        <div class="row m-2">
                            <div class="col-12 d-flex justify-content-start align-items-center ml-0">
                                <button class="btn btn-primary" type="submit" data-url='<?php echo esc_url(admin_url()); ?>' id="graphina_setting_save_button" class="graphina_test_btn btn btn-primary"><?php echo esc_html__("Save Setting",'grdi-graphina-divi');?></button>
                            </div>
                        </div>
                    </form>
                    <?php
                    break;
                case "database":
                    ?>
                    <form id="graphina-div-external-database-tab" autocomplete="off">
                        <div class="row m-2">
                            <div class="col-12">
                                <h5 class="font-weight-bold">
                                    <?php echo esc_html__("Connection Detail",'grdi-graphina-divi');?>
                                </h5>
                            </div>
                        </div>
                        <div class="row m-2">
                            <div class="col-12 col-md-4">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="form-group">
                                            <label for="con_name" class="col-form-label">
                                                <?php echo esc_html__("Connection Name : ",'grdi-graphina-divi');?>
                                            </label>
                                            <input type="text" id="con_name" name="con_name" class="form-control" value=""  autofocus required>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        <div class="form-group">
                                            <label for="host" class="col-form-label">
                                                <?php echo esc_html__("Host : ",'grdi-graphina-divi');?>
                                            </label>
                                            <input type="text" name="host" id="host" class="form-control" value=""  autofocus required />
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        <div class="form-group">
                                            <label for="user_name" class="col-form-label">
                                                <?php echo esc_html__("Username : ",'grdi-graphina-divi');?>
                                            </label>
                                            <input type="text" id="user_name" name="user_name" class="form-control" value="" autofocus required >
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-md-4">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="form-group">
                                            <label for="vendor" class="col-form-label">
                                                <?php echo esc_html__("Vendor : ",'grdi-graphina-divi');?>
                                            </label>
                                            <select id="vendor" name="vendor" class="form-control"  autofocus required>
                                                <option value="mysql"><?php echo esc_html__("MySQL",'grdi-graphina-divi');?></option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        <div class="form-group">
                                            <label for="db_name" class="col-form-label">
                                                <?php echo esc_html__("Database Name : ",'grdi-graphina-divi');?>
                                            </label>
                                            <input type="text" class="form-control" id="db_name" name="db_name" value="" autocomplete="off" autofocus required />
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        <div class="form-group">
                                            <label for="pass" class="col-form-label">
                                                <?php echo esc_html__("Password : ",'grdi-graphina-divi');?>
                                            </label>
                                            <input type="password" id="pass" name="pass" class="form-control" value="" autocomplete="new-password" autofocus required />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <input type="hidden" name="route" value="external_database_connection_save">
                        <input type="hidden" name="action" value="graphina_divi_admin_setting">
                        <input type="hidden" name="nonce" value="<?php echo esc_html(wp_create_nonce('ajax-nonce'));?>">
                        <div class="row  m-2">
                            <div class="col-12 d-flex justify-content-start align-items-center">
                                <button type="submit" name="save_connection" class="btn btn-primary" >
                                    <?php echo esc_html__("Test and Save Configuration",'grdi-graphina-divi');?>
                                </button>
                                <button type="button" id="reset_button" class="btn btn-outline-primary  mx-2">
                                    <?php echo esc_html__("Reset",'grdi-graphina-divi');?>
                                </button>
                            </div>
                        </div>
                    </form>
                    <div id="graphina-divi-configuration-table">
                    </div>
                    <script>
                        graphinaDiviTable();
                    </script>
                    <?php
                    break;
            }
            ?>
        </div>
    </div>
    <?php
}