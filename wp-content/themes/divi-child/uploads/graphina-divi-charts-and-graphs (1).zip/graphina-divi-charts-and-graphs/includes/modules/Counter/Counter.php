<?php

class GRDI_Counter extends ET_Builder_Module{

	protected $module_credits = array(
		'module_uri' => '',
		'author'     => '',
		'author_uri' => '',
	);
	public $slug       = 'grdi_counter';
	public $vb_support = 'on';
    public $type = 'counter';
    public $icon_path ;
    public $Unique ;

    public function init(){

        $this->name = __('Counter', 'grdi-graphina-divi');
        $this->icon_path = plugin_dir_path( __FILE__ ) . 'icon.svg';
        $this->Unique = true;

        $this->settings_modal_toggles = array(
            'general' => array(
                'toggles' => array(
                    'card_setting' => __('Card Settings', 'grdi-graphina-divi'),
                    'chart_data' => __('Counter Data Settings', 'grdi-graphina-divi'),
                    'main_content' => __('Basic Counter Settings', 'grdi-graphina-divi'),
                ),
            ),
        );

        $this->help_videos = array(
            array(
                'id'   => 'wuged8w093g',
                'name' => esc_html__( 'An introduction to the Graphina Counter module', 'grdi-graphina-divi' ),
            ),
        );
    }

    public function get_fields() {

        $field = array();

        $field = array_merge($field,graphinaDiviChartDataSetting($this->type));

        $field = array_merge($field,graphinadiviCardSetting($this->type));

        $field['iq_counter_icon'] = array(
            'label' => __( 'Icon','grdi-graphina-divi'),
            'type' => 'select_icon',
            'option_category' => 'basic_option',
            'default' => '&#xe031;||divi||400',
            'toggle_slug' => 'main_content'
        );

        $field['counter_align'] = array(
            'label'    => __( 'Counter Align', 'grdi-graphina-divi' ),
            'type'            => 'text_align',
            'options'         => et_builder_get_text_orientation_options(array('justified')),
            'toggle_slug'     => 'main_content',
            'default'  => 'center',
            'mobile_options'  => true,
        );

        $field['iq_counter_start'] = array(
            'label' => __( 'Start','grdi-graphina-divi'),
            'type'              => 'number',
            'option_category'   => 'basic_option',
            'value_type'        => 'float',
            'toggle_slug' => 'main_content',
            'default'  => 0,
            'show_if' => [
                'data_type' => ['manual']
            ]
        );

        $field['iq_counter_end'] = array(
            'label' => __( 'End','grdi-graphina-divi'),
            'type'              => 'number',
            'option_category'   => 'basic_option',
            'value_type'        => 'float',
            'toggle_slug' => 'main_content',
            'default'  => 100,
            'show_if' => [
                'data_type' => ['manual']
            ]
        );

        $field['iq_counter_speed'] = array(
            'label' => __( 'Speed','grdi-graphina-divi'),
            'type'              => 'number',
            'option_category'   => 'basic_option',
            'value_type'        => 'int',
            'toggle_slug' => 'main_content',
            'default'  => 100,
            'custom_attributes' => array(
                'min'  => 1,
            ),
        );

        $field['iq_counter_prefix'] = array(
            'label' => __( 'Prefix', 'grdi-graphina-divi'),
            'type' => 'text',
            'option_category'   => 'basic_option',
            'toggle_slug' => 'main_content',
            'default' => ''
        );

        $field['iq_counter_postfix'] = array(
            'label' => __( 'Postfix', 'grdi-graphina-divi'),
            'type' => 'text',
            'option_category'   => 'basic_option',
            'toggle_slug' => 'main_content',
            'default' => ''
        );

        $field['iq_counter_separator'] =array(
            'label'            => __( 'Separator', 'grdi-graphina-divi' ),
            'type'             => 'select',
            'option_category'  => 'basic_option',
            'toggle_slug'     => 'main_content',
            'default'         => ',',
            'options'          => array(
                ','  => __( 'Comma', 'grdi-graphina-divi' ),
                '.' => __( 'Dot', 'grdi-graphina-divi' ),
            )
        );

        $field['iq_icon_color'] = array(
            'label' => __( 'Icon Color', 'grdi-graphina-divi' ),
            'type' => 'color-alpha',
            'option_category'  => 'basic_option',
            'toggle_slug'     => 'main_content',
            'default' => '#000000'
        );

        $field['iq_counter_color'] = array(
            'label' => __( 'Counter Color', 'grdi-graphina-divi' ),
            'type' => 'color-alpha',
            'option_category'  => 'basic_option',
            'toggle_slug'     => 'main_content',
            'default' => '#000000'
        );

        $field['iq_counter_fontsize'] = array(
            'label'             => __( 'Font Size', 'grdi-graphina-divi'),
            'type'              => 'range',
            'toggle_slug'       => 'main_content',
            'option_category'   => 'basic_option',
            'allowed_units'     => array('px'),
            'range_settings'    => array(
                'min'  => '0',
                'max'  => '100',
                'step' => '1',
            ),
            'default'           => 32,
            'mobile_options'    => true,
            'important' => false
        );

        return $field;
    }

    public function render( $attrs, $content, $render_slug ) {
        graphinaDiviLoadModuleScript($this->type);
        $widgetId = uniqid();
        $chartID = !empty($this->props['chart_id']) ? esc_html($this->props['chart_id']) : esc_html(graphinaDiviGenerateRandomString($this->type, $this->render_count()));
        $prefix = !empty($this->props['iq_counter_prefix']) ? esc_html($this->props['iq_counter_prefix']) : '';
        $postfix = !empty($this->props['iq_counter_postfix']) ? esc_html($this->props['iq_counter_postfix']) : '';
        $counters = [];
        if($this->props['data_type'] === 'manual'){
            $counter = [
                'end' => esc_html($this->props['iq_counter_end'])
            ];
        } else {
            $counters = graphinaDiviGetChartDynamicData($this->props, $this->type);
        }
    
        if ($this->props['data_type'] !== 'manual') {
            if(!empty($counters) && count($counters) > 0){
                $counter = !empty($counters[$this->props['iq_counter_column'] - 1]) ? $counters[$this->props['iq_counter_column'] - 1]
                    : ['end' => 0];
                switch ($this->props['counter_operation']){
                    case 'sum':
                        $counter['end'] = !empty($counter['end']) && is_array($counter['end']) ? array_sum($counter['end']) : 0;
                        break;
                    case 'avg':
                        $counter['end'] = array_filter($counter['end']);
                        if(count($counter['end'])) {
                            $counter['end'] = array_sum($counter['end'])/count($counter['end']);
                        } else {
                            $counter['end'] = 0;
                        }
                        break;
                    case 'none':
                        $counter['end'] = !empty($counter['end'][$this->props['iq_counter_object_no'] - 1 ]) ? $counter['end'][$this->props['iq_counter_object_no'] - 1 ] : 0;
                        break;
                }
            }
        }
    
        if(isset($counter['end'])){
            $counterTitleContent = "<h4>" . esc_html($this->props['title']) . "</h4>";
            $counterDescriptionContent = "<p>" . esc_html($this->props['description']) . "</p>";
            $icon= explode("||",$this->props['iq_counter_icon']);
            if(!empty($this->props['iq_counter_icon'])){

                $counterIconContent = sprintf(
                    '<span class="et-pb-icon" style="font-family: %1$s ;font-weight:%2$s; color:%3$s;">%4$s</span>',
                    $icon[1] === "divi"? "ETmodules !important":"FontAwesome !important",
                    $icon[2],
                    $this->props['iq_icon_color'],
                    esc_attr( et_pb_process_font_icon($this->props['iq_counter_icon']) )
                );

            }
            ob_start();
            ?>
            <div class="grahina-divi" style="text-align: <?php echo esc_html($this->props['counter_align']);?>;" >
                <div style="display: flex;justify-content: center;align-items: center;">
                    <h2 style="font-size: <?php echo esc_html($this->props['iq_counter_fontsize']).'px'; ?>;
                            color: <?php echo esc_html($this->props['iq_counter_color']); ?>;"><?php echo esc_html($prefix) ?></h2>
                    <h2 style="font-size: <?php echo esc_html($this->props['iq_counter_fontsize']).'px'; ?>;
                            color: <?php echo esc_html($this->props['iq_counter_color']); ?>;"
                        class="graphina_divi_counter counter-<?php echo esc_attr($chartID); ?>">
                        0
                    </h2>
                    <h2 style="font-size: <?php echo esc_html($this->props['iq_counter_fontsize']).'px'; ?>;
                            color: <?php echo esc_html($this->props['iq_counter_color']); ?>;"><?php echo esc_html($postfix) ?></h2>
                </div>
                <?php echo wp_kses($counterIconContent,"post");?>
            </div>
            <?php
            $counterNumberFieldContent = ob_get_clean();
            ob_start();
            ?>
            <div class="grahina-divi <?php echo esc_html($this->props['show_card']) == 'on' ? 'graphina-divi-chart-card' : ''; ?>" style="background: <?php echo esc_html($this->props['card_color']); ?>">
                <?php if( esc_html($this->props['show_card']) === 'on' ){ ?>
                    <div class="graphina-divi-title" style="text-align: <?php echo esc_html($this->props['card_title_align']);?>">
                        <?php echo wp_kses($counterTitleContent,'post'); ?>
                        <?php echo wp_kses($counterDescriptionContent,'post'); ?>
                    </div>
                <?php }
                echo wp_kses($counterNumberFieldContent,'post');
                ?>
            </div>
    
            <script>
                document.addEventListener('readystatechange', event => {
                    if (event.target.readyState === "complete") {
                        if (typeof counterInit === "undefined") {
                            var counterInit = {};
                        }
    
                        if (typeof myCounter === "undefined") {
                            var myCounter = {};
                        }
                        var counterId = '<?php echo esc_attr($widgetId); ?>';
                        var element = document.querySelector(".graphina_divi_counter.counter-<?php echo esc_attr($chartID); ?>");
    
                        if (element) {
                            myCounter[counterId] = {
                                id: counterId,
                                ele: element,
                                end: <?php echo (int)$counter['end']; ?>,
                                separator: '<?php  echo  esc_html(!empty($this->props['iq_counter_separator']) ? $this->props['iq_counter_separator'] : ''); ?>',
                                speed: <?php echo isset($this->props['iq_counter_speed']) ? (int)$this->props['iq_counter_speed'] : 0; ?>,
                            }
    
                            counterInit[counterId] = false;
    
                            if(('<?php echo esc_attr($widgetId); ?>' in counterInit) && counterInit['<?php echo esc_attr($widgetId); ?>'] === false){
                                let counterOptions = {
                                    easing: 'linear',
                                    duration: myCounter['<?php echo esc_attr($widgetId); ?>'].speed,
                                    delimiter: myCounter['<?php echo esc_attr($widgetId); ?>'].separator,
                                    toValue: myCounter['<?php echo esc_attr($widgetId); ?>'].end,
                                    rounding: parseInt('<?php echo esc_attr(!empty($this->props['iq_counter_round_decimal']) ? $this->props['iq_counter_round_decimal'] : 0 ); ?>') || 0
                                }
                                if('<?php echo esc_js(graphina_divi_common_setting_get('view_port') === 'on'); ?>'){
                                    counterInit['<?php echo esc_attr($widgetId); ?>'] = true;
                                    jQuery(myCounter['<?php echo esc_attr($widgetId); ?>'].ele).numerator(counterOptions);
                                } else {
                                    const observer = new IntersectionObserver(enteries => {
                                        enteries.forEach(entry =>{
                                            if(entry.isIntersecting){
                                                counterInit['<?php echo esc_attr($widgetId); ?>'] = true;
                                                jQuery(myCounter['<?php echo esc_attr($widgetId); ?>'].ele).numerator(counterOptions);
                                            }
                                        })
                                    })
                                    observer.observe(myCounter['<?php echo esc_attr($widgetId); ?>'].ele);
                                }
                            }
                        }
                    }
                });
            </script>
            <?php
        } else { ?>
            <div class="grahina-divi graphina-divi-chart-card" style='text-align:center; margin: 75px auto;'><span>
                <?php echo esc_html__('No Data Available', 'grdi-graphina-divi'); ?></span>
            </div>
        <?php }
        return ob_get_clean();
    }
    

}

new GRDI_Counter;