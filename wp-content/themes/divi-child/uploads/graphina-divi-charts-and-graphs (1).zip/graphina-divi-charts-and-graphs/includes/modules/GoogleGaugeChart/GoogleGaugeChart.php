<?php

class GRDI_GoogleGaugeChart extends ET_Builder_Module{
    

    protected $module_credits = array(
		'module_uri' => '',
		'author'     => '',
		'author_uri' => '',
	);
	public $slug       = 'grdi_google_gauge_chart';
	public $vb_support = 'on';
    public $type = 'gauge_google';
    public $icon_path ;

    public function init() {
        
        $this->icon_path = plugin_dir_path( __FILE__ ) . 'icon.svg';
        $this->name = __( 'Google Gauge Chart', 'grdi-graphina-divi' );
        $this->_use_unique_id  = true;

        $this->settings_modal_toggles = array(
			'general'  => array(
				'toggles' => array(
                    'card_setting' => __( 'Card Settings', 'grdi-graphina-divi' ),
                    'chart_data'   => __( 'Chart Data Settings', 'grdi-graphina-divi' ),
                    'google_main_content' => __( 'Basic Chart Settings', 'grdi-graphina-divi' ),
                    'ticks_settings' => __( 'Ticks Settings', 'grdi-graphina-divi' ),
				),
			),
		);
    }

    public function get_fields() {

        $field = array();
        // card setting
        $field = array_merge($field,graphinadiviCardSetting($this->type));
        // chart height and color
        $field = array_merge($field,graphinaGoogleHeightWidthSetting($this->type));
        //chart data setting
        $field = array_merge($field,graphinaDiviChartDataSetting($this->type));
        //ticks setting
        $field = array_merge($field,graphinaDiviGaugeTickSetting());

        return $field;
	}

    public function get_advanced_fields_config() {
		return array();
	}

    public function render( $attrs, $content, $render_slug ) { 
        
        graphinaDiviLoadModuleScript($this->type);

        $series = [];
        $categoryData = [];
        $new_list = [];
        $columnData = [];
        $majorticks = [];
        $data = [];
        $majorticks = $this->props['major_ticks'];
        $majorticks = wp_json_encode($majorticks);
        $Count = $this->props['element_count'];
        $chartID = !empty($this->props['google_chart_id']) ? $this->props['google_chart_id'] : graphinaDiviGoogleGenerateRandomString($this->type,$this->render_count());
        if($this->props['data_type'] === 'manual'){
            if(isset($this->props['data_element_name'])){
                $series =
                    explode(',',str_replace('\n','',wp_strip_all_tags($this->props['data_element_name'])));
            }else{
                $series = [20, 50];
            }

            /* category data */

            if (!empty($this->props['category'])) {
                $categoryData = explode(',', str_replace('\n','',wp_strip_all_tags($this->props['category'])));
            } else {
                $categoryData = ['Jan', 'Feb'];
            }

            for ($i = 0; $i < $Count; $i++) {
                $new_list = [
                    $categoryData[$i],
                    (int)$series[$i]
                ];
                $columnData[] = $new_list;
            }
        }
        $encodedData = wp_json_encode(array_map(function($item) {
            return array_map('esc_html', $item);
        }, $columnData));
        
        // Convert the string values to numbers
        $decodedData = json_decode($encodedData, true);
        foreach ($decodedData as &$row) {
            $row[1] = (int)$row[1];
        }
        $encodedData = wp_json_encode($decodedData);
        ob_start();
        graphinaDiviCommonChartHtml($this, esc_html($chartID));
        ?>
        <script type='text/javascript'>
            document.addEventListener('readystatechange', event => {
                if (event.target.readyState === "complete") {
                    window.google.charts.load('current', {'packages': ["gauge"]});
                    window.google.charts.setOnLoadCallback(drawChart);
        
                    function drawChart() {
                        var data = new google.visualization.DataTable();
                        data.addColumn('string', 'Name');
                        data.addColumn('number', 'Value');
                        data.addRows(<?php echo et_core_esc_previously($encodedData); ?>);
        
                        var options = {
                            width: parseInt(<?php echo esc_html($this->props['google_chart_width']); ?>),
                            height: <?php echo esc_html($this->props['google_chart_height']); ?>,
                            greenFrom: parseInt(<?php echo esc_html($this->props['green_from']); ?>),
                            greenTo: parseInt(<?php echo esc_html($this->props['green_to']); ?>),
                            greenColor: '<?php echo esc_html($this->props['green_color']); ?>',
                            yellowFrom: parseInt(<?php echo esc_html($this->props['yellow_from']); ?>),
                            yellowTo: parseInt(<?php echo esc_html($this->props['yellow_to']); ?>),
                            yellowColor: '<?php echo esc_html($this->props['yellow_color']); ?>',
                            redFrom: parseInt(<?php echo esc_html($this->props['red_from']); ?>),
                            redTo: parseInt(<?php echo esc_html($this->props['red_to']); ?>),
                            redColor: '<?php echo esc_html($this->props['red_color']); ?>',
                            minorTicks: <?php echo esc_html($this->props['minor_ticks']); ?>,
                            majorTicks: <?php echo wp_json_encode($majorticks); ?>.split(','),
                            min: <?php echo esc_html($this->props['min_ticks']); ?>,
                            max: <?php echo esc_html($this->props['max_ticks']); ?>
                        };
                        var element = document.querySelector('<?php echo '#' . esc_html($chartID); ?>');
        
                        if (data.getNumberOfRows() === 0 && '<?php echo esc_html($this->props['data_type']) === 'manual'; ?>') {
                            <?php if (!empty(($data['fail_message']))) : ?>
                                element.innerHTML = `<?php echo esc_html($data['fail_message']);  ?>`;
                            <?php else : ?>
                                element.innerHTML = `<pre><p style='text-align:center;'><?php echo esc_html__('No data Found', 'grdi-graphina-divi'); ?></p></pre>`;
                            <?php endif; ?>
                        } else {
                            if (typeof graphinaBuilderGoogleChartInit !== "undefined") {
                                graphinaBuilderGoogleChartInit(
                                    element,
                                    {
                                        ele: element,
                                        options: options,
                                        series: data,
                                        animation: true,
                                        renderType: 'Gauge',
                                    },
                                    '<?php echo esc_html($this->type); ?>',
                                    '<?php echo esc_html($chartID); ?>'
                                );
                            }
                            if (typeof graphinaDiviDynamicData !== "undefined") {
                                graphinaDiviDynamicData(
                                          <?php echo wp_json_encode($this->props); ?>,
                                    '<?php echo esc_html($this->type); ?>',
                                    '<?php echo esc_html($chartID); ?>',
                                    '<?php echo !empty(esc_html($this->props['ajax_reload'])) && esc_html($this->props['ajax_reload']) === 'true' ? 'true' : 'false'; ?>',
                                    '<?php echo !empty(esc_html($this->props['ajax_reload_time'])) && esc_html($this->props['ajax_reload_time']) != 0 ? esc_html($this->props['ajax_reload_time']) : 5; ?>'
                                );
                            }
                        }
                    }
                }
            });
        </script>
        <?php
        return ob_get_clean();
        
    }

}

new GRDI_GoogleGaugeChart;