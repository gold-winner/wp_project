<?php

class GRDI_GoogleGeoChart extends ET_Builder_Module{

    public $slug = 'grdi_google_geo_chart';
    public $vb_support = 'on';
    public $type = 'geo_google';
    public $icon_path ;


    public function init(){

        $this->icon_path = plugin_dir_path( __FILE__ ) . 'icon.svg';
        $this->name = __( 'Google Geo Chart', 'grdi-graphina-divi' );
        $this->_use_unique_id  = true;

        $this->settings_modal_toggles = array(
            'general' => array(
                'toggles' => array(
                    'card_setting' => __( 'Card Settings', 'grdi-graphina-divi' ),
                    'chart_data'   => __( 'Chart Data Settingsssss', 'grdi-graphina-divi' ),
                    'google_main_content' => __( 'Basic Chart Settings', 'grdi-graphina-divi' ),
                    'google_tooltip_setting' => __( 'Tooltip Settings', 'grdi-graphina-divi'),
                    'google_legend_setting' => __( 'Legend Settings', 'grdi-graphina-divi')
                ),
            ),
        );
    }

    public function get_fields() {
        $field = array();

        $field = array_merge($field,graphinadiviCardSetting($this->type));

        $field = array_merge($field,graphinaGoogleHeightWidthSetting($this->type));

        $field = array_merge($field,graphinaDiviChartDataSetting($this->type));

        $field['geo_label_text'] = array(
            'label' => __('Label', 'grdi-graphina-divi'),
            'type' => 'text',
            'toggle_slug' => 'google_main_content',
            'default' => 'Population'
        );

        $field['geo_region_show'] = array(
            'label' => __('Region Show','et_builder'),
            'type' => 'yes_no_button',
            'option_category'  => 'configuration',
            'toggle_slug' => 'google_main_content',
            'options' => array(
                'on' => __('Yes', 'grdi-graphina-divi' ),
                'off' => __('No', 'grdi-graphina-divi' ),
            ),
            'default' => 'off',
            'mobile_options'   => true,
            'hover'            => 'tabs',
        );

        $field['geo_regions'] = array(
            'label' => __('Region', 'grdi-graphina-divi'),
            'type' => 'text',
            'toggle_slug' => 'google_main_content',
            'show_if' => array(
                'geo_region_show' => 'on'
            )
        );

        $field['geo_background_color'] = array(
            'label' => __('Background Color','grdi-graphina-divi'),
            'type' => 'color-alpha',
            'toggle_slug' => 'google_main_content',
            'default' => '#81d4fa',
        );

        $field['geo_background_stroke_color'] = array(
            'label' => __('Stroke Color','grdi-graphina-divi'),
            'type' => 'color-alpha',
            'toggle_slug' => 'google_main_content',
        );

        $field['geo_stroke_width'] = array(
            'label' => __('Stroke Width', 'grdi-graphina-divi'),
            'type' => 'number',
            'toggle_slug' => 'google_main_content',
            'default' => 0,
            'min' => 0
        );

        $field['geo_default_color'] = array(
            'label' => __('Data Region Color','grdi-graphina-divi'),
            'type' => 'color-alpha',
            'toggle_slug' => 'google_main_content',
            'default' => '#008000'
        );

        $field['geo_chart_data_less_color'] = array(
            'label' => __('No Data Regeion','grdi-graphina-divi'),
            'type' => 'color-alpha',
            'toggle_slug' => 'google_main_content',
            'default' => '#fbffee',
        );

        $field['tooltip_show'] = array(
            'label' => __('Tooltip Show','grdi-graphina-divi'),
            'type' => 'yes_no_button',
            'option_category'  => 'configuration',
            'toggle_slug' => 'google_tooltip_setting',
            'options' => array(
                'on' => __('Yes', 'grdi-graphina-divi' ),
                'off' => __('No', 'grdi-graphina-divi' ),
            ),
            'default' => 'on',
            'mobile_options'   => true,
            'hover'            => 'tabs',
        );

        $field['geo_tooltip_trigger'] = array(
            'label' => __('Trigger','grdi-graphina-divi'),
            'type' => 'select',
            'toggle_slug' => 'google_tooltip_setting',
            'options' => array(
                'focus' => __('On Hover','grdi-graphina-divi'),
                'selection' => __('On Selection','grdi-graphina-divi'),
            ),
            'default' => 'focus',
            'show_if' => array(
                'tooltip_show' => 'on'
            )
        );

        $field['geo_tooltip_color'] = array(
            'label' => __('Tooltip Color','grdi-graphina-divi'),
            'type' => 'color-alpha',
            'toggle_slug' => 'google_tooltip_setting',
            'default' => '#000000',
            'show_if' => array(
                'tooltip_show' => 'on'
            )
        );

        $field['geo_tooltip_font_size'] = array(
            'label' => __('Tooltip Font Size', 'grdi-graphina-divi'),
            'type' => 'number',
            'toggle_slug' => 'google_tooltip_setting',
            'default' => 12,
            'min' => 0,
            'show_if' => array(
                'tooltip_show' => 'on'
            )
        );

        $field['geo_tooltip_bold'] = array(
            'label' => __('Bold','et_builder'),
            'type' => 'yes_no_button',
            'option_category'  => 'configuration',
            'toggle_slug' => 'google_tooltip_setting',
            'options' => array(
                'on' => __('Yes', 'grdi-graphina-divi' ),
                'off' => __('No', 'grdi-graphina-divi' ),
            ),
            'default' => 'off',
            'mobile_options'   => true,
            'hover'            => 'tabs',
            'show_if' => array(
                'tooltip_show' => 'on'
            )
        );

        $field['geo_tooltip_italic'] = array(
            'label' => __('Italic','et_builder'),
            'type' => 'yes_no_button',
            'option_category'  => 'configuration',
            'toggle_slug' => 'google_tooltip_setting',
            'options' => array(
                'on' => __('Yes', 'grdi-graphina-divi' ),
                'off' => __('No', 'grdi-graphina-divi' ),
            ),
            'default' => 'off',
            'mobile_options'   => true,
            'hover'            => 'tabs',
            'show_if' => array(
                'tooltip_show' => 'on'
            )
        );


        $field['geo_legend_show'] = array(
            'label' => __('Legend Show','grdi-graphina-divi'),
            'type' => 'yes_no_button',
            'option_category'  => 'configuration',
            'toggle_slug' => 'google_legend_setting',
            'options' => array(
                'on' => __('Yes', 'grdi-graphina-divi' ),
                'off' => __('No', 'grdi-graphina-divi' ),
            ),
            'default' => 'off',
            'mobile_options'   => true,
            'hover'            => 'tabs',
        );

        $field['geo_legend_size'] = array(
            'label' => __('legend','grdi-graphina-divi'),
            'type' => 'number',
            'toggle_slug' => 'google_legend_setting',
            'default' => 12,
            'min' => 0,
            'show_if' => array(
                'geo_legend_show' => 'on'
            )
        );

        $field['geo_legend_bold'] = array(
            'label' => __('Bold','et_builder'),
            'type' => 'yes_no_button',
            'option_category'  => 'configuration',
            'toggle_slug' => 'google_legend_setting',
            'options' => array(
                'on' => __('Yes', 'grdi-graphina-divi' ),
                'off' => __('No', 'grdi-graphina-divi' ),
            ),
            'default' => 'off',
            'mobile_options'   => true,
            'hover'            => 'tabs',
            'show_if' => array(
                'geo_legend_show' => 'on'
            )
        );

        $field['geo_legend_italic'] = array(
            'label' => __('Italic','et_builder'),
            'type' => 'yes_no_button',
            'option_category'  => 'configuration',
            'toggle_slug' => 'google_legend_setting',
            'options' => array(
                'on' => __('Yes', 'grdi-graphina-divi' ),
                'off' => __('No', 'grdi-graphina-divi' ),
            ),
            'default' => 'off',
            'mobile_options'   => true,
            'hover'            => 'tabs',
            'show_if' => array(
                'geo_legend_show' => 'on'
            )
        );

        $field['geo_legend_format'] = array(
            'label' => __('Format','et_builder'),
            'type' => 'yes_no_button',
            'option_category'  => 'configuration',
            'toggle_slug' => 'google_legend_setting',
            'options' => array(
                'on' => __('Yes', 'grdi-graphina-divi' ),
                'off' => __('No', 'grdi-graphina-divi' ),
            ),
            'default' => 'off',
            'mobile_options'   => true,
            'hover'            => 'tabs',
            'show_if' => array(
                'geo_legend_show' => 'on'
            )
        );

        return $field;
    }

    public function render($attrs, $content, $render_slug){
        graphinaDiviLoadModuleScript($this->type);
        $columnData = [];
        $chartID = !empty($this->props['google_chart_id']) ? $this->props['google_chart_id'] : graphinaDiviGoogleGenerateRandomString($this->type,$this->render_count());
        if($this->props['data_type'] === 'manual'){
            if(isset($this->props['data_element_name'])){
                $series = explode(',',str_replace('\n','',wp_strip_all_tags($this->props['data_element_name'])));
            }else{
                $series = [20, 50];
            }

            if(!empty($this->props['category'])){
                $categoryData = explode(',',str_replace('\n','',wp_strip_all_tags($this->props['category'])));
            }else{
                $categoryData = ['India', 'Japan'];
            }
            
            if(count($series) <= count($categoryData)){
                for($i = 0; $i < count($categoryData); $i++){
                    $new_list = [
                        $categoryData[$i],
                        (int)$series[$i]
                    ];
                    $columnData[] = $new_list;
                }
            }

        }
        $colors = implode('_,_', array_map('esc_html', array_fill(1, count($columnData), $this->props['geo_default_color'])));
        $columnData = wp_json_encode($columnData);
        ob_start();
        graphinaDiviCommonChartHtml($this, $chartID);
        ?>
        <script type='text/javascript'>
            document.addEventListener('readystatechange', event => {
                if (event.target.readyState === "complete") {
                    window.google.charts.load('current', {'packages':["geochart"]});
                    window.google.charts.setOnLoadCallback(drawChart);
        
                    function drawChart() {
                        var data = new google.visualization.DataTable();
                        data.addColumn('string','Country')
                        data.addColumn('number','<?php echo esc_html($this->props['geo_label_text']) ?>')
        
                        data.addRows(<?php echo wp_kses_post($columnData); ?>)
        
                        var options = {
                            height: parseInt(<?php echo !empty(esc_html($this->props['google_chart_height'])) ? esc_html($this->props['google_chart_height']) : ''; ?>),
                            datalessRegionColor: '<?php echo !empty(esc_html($this->props['geo_chart_data_less_color'])) ? esc_html($this->props['geo_chart_data_less_color']) : ''; ?>',
                            enableRegionInteractivity: <?php echo !empty(esc_html($this->props['tooltip_show'])) && esc_html($this->props['tooltip_show']) === 'on' ? 'true' : 'false';?>,
                            <?php if(!empty($colors)){ ?>
                            colorAxis: {
                                colors: '<?php echo esc_html($colors); ?>'.split('_,_'),
                            },
                            <?php } ?>
                            backgroundColor: {
                                fill: '<?php echo !empty(esc_html($this->props['geo_background_color'])) ? esc_html($this->props['geo_background_color']) : '#81d4fa' ?>',
                                stroke: '<?php echo !empty(esc_html($this->props['geo_background_stroke_color'])) ? esc_html($this->props['geo_background_stroke_color']) : '' ?>',
                                strokeWidth: parseInt(<?php echo !empty(esc_html($this->props['geo_stroke_width'])) ? esc_html($this->props['geo_stroke_width']) : 0 ?>)
                            },
                            defaultColor : '<?php echo !empty(esc_html($this->props['geo_default_color'])) ? esc_html($this->props['geo_default_color']) : '';?>',
                            tooltip:{
                                textStyle: {
                                    color: '<?php echo !empty(esc_html($this->props['geo_tooltip_color'])) ? esc_html($this->props['geo_tooltip_color']) : '#000000';?>',
                                    fontSize: parseInt(<?php echo !empty(esc_html($this->props['geo_tooltip_font_size'])) ? esc_html($this->props['geo_tooltip_font_size']) : '';?>),
                                    bold: '<?php echo !empty(esc_html($this->props['geo_tooltip_bold'])) && esc_html($this->props['geo_tooltip_bold']) == 'on' ? 'true' : 'false';?>',
                                    italic: '<?php echo !empty(esc_html($this->props['geo_tooltip_italic'])) && esc_html($this->props['geo_tooltip_italic']) == 'on' ? 'true' : 'false';?>'
                                },
                                trigger: '<?php echo !empty(esc_html($this->props['geo_tooltip_trigger'])) ? esc_html($this->props['geo_tooltip_trigger']) : '';?>'
                            }
                        };
        
                        if('<?php echo esc_html($this->props['geo_region_show']) === 'on' ?>'){
                            options.region = '<?php echo !empty(esc_html($this->props['geo_regions'])) ? esc_html($this->props['geo_regions']) : '' ?>',
                            options.resolution = 'provinces',
                            options.displayMode = 'region'
                        }
        
                        if('<?php echo esc_html($this->props['geo_legend_show']) === 'on' ?>'){
                            options.legend = {
                                textStyle: {
                                    color: '<?php echo esc_html(!empty(($this->props['geo_legend_color'])) ? ($this->props['geo_legend_color']) : '#000000'); ?>',
                                    fontSize: '<?php echo !empty(esc_html($this->props['geo_legend_size'])) ? esc_html($this->props['geo_legend_size']) : '';?>',
                                    bold: '<?php echo !empty(esc_html($this->props['geo_legend_bold'])) && esc_html($this->props['geo_legend_bold']) == 'on' ? 'true' : 'false';?>',
                                    italic: '<?php echo !empty(esc_html($this->props['geo_legend_italic'])) && esc_html($this->props['geo_legend_italic']) == 'on' ? 'true' : 'false';?>'
                                },
                                numberFormat: '<?php echo !empty(esc_html($this->props['geo_legend_format'])) && esc_html($this->props['geo_legend_format']) == 'on' ? '.###' : '';?>'
                            }
                        } else {
                            options.legend = 'none';
                        }
                        
                        var element = document.querySelector('<?php echo '#' . esc_html($chartID); ?>');
                        if (typeof graphinaBuilderGoogleChartInit !== "undefined") {
                            graphinaBuilderGoogleChartInit(
                                element,
                                {
                                    ele: element,
                                    options: options,
                                    series: data,
                                    animation: true,
                                    renderType: 'GeoChart',
                                },
                                '<?php echo esc_html($this->type); ?>',
                                '<?php echo esc_html($chartID); ?>'
                            )
                        }
                        if (typeof graphinaDiviDynamicData !== "undefined" )  {
                            graphinaDiviDynamicData(
                                      <?php echo wp_json_encode($this->props); ?>,
                                '<?php echo esc_html($this->type); ?>',
                                '<?php echo esc_html($chartID); ?>',
                                '<?php echo esc_html(!empty(($this->props['ajax_reload'])) && ($this->props['ajax_reload']) === 'true' ? 'true' :'false') ?>',
                                '<?php echo  esc_html(!empty(($this->props['ajax_reload_time'])) && ($this->props['ajax_reload_time']) != 0 ? ($this->props['ajax_reload_time']) : 5)  ?>'
                            )
                        }
                    }
                }
            });
        </script>
        <?php
        return  ob_get_clean();
        
    }

}

new GRDI_GoogleGeoChart;