<?php
class GRDI_Polarchart extends ET_Builder_Module {

    protected $module_credits = array(
		'module_uri' => '',
		'author'     => '',
		'author_uri' => '',
	);
    public $slug       = 'grdi_polar_chart';
	public $vb_support = 'on';

    public $type = 'polar';
    public $icon_path ;


    public function init() {

        $this->icon_path = plugin_dir_path( __FILE__ ) . 'icon.svg';
		$this->name = __( 'Polar Chart', 'grdi-graphina-divi' );
        $this->_use_unique_id  = true;

		$this->settings_modal_toggles = array(
			'general'  => array(
				'toggles' => array(
                    'card_setting' => __( 'Card Settings', 'grdi-graphina-divi' ),
                    'chart_data'         => __( 'Chart Data Settings', 'grdi-graphina-divi' ),
                    'main_content' => __( 'Basic Chart Settings', 'grdi-graphina-divi' ),
                    'data_series'  => __( 'Data', 'grdi-graphina-divi' ),
                    'plotoptions'  => __( 'Plotoptions Settings', 'grdi-graphina-divi' ),
                    'tooltip'      => __( 'Tooltip', 'grdi-graphina-divi' ),
                    'datalabel' => __('Data Labels', 'grdi-graphina-divi'),
                    'legend'       => __( 'Legend Settings', 'grdi-graphina-divi' ),
                    'responsive'    => __( 'Responsive', 'grdi-graphina-divi' ),
				),
			),
		);
	}

    public function get_fields() {
        $field = [];
        // card setting
        $field = array_merge($field,graphinadiviCardSetting($this->type));
        // chart height and color
        $field = array_merge($field,graphinaDiviChartHeightColorSetting($this->type));
        // chart Toolbar setting
        $field = array_merge($field,graphinaDiviToolbarSetting($this->type));
        //chart plotoption setting
        $field = array_merge($field,graphinaDiviChartPlotoptionSetting($this->type));
        //chart tooltip setting
        $field = array_merge($field,graphinaDiviChartToolTip($this->type));
        //chart stroke and grid setting
        $field = array_merge($field,graphinaDiviChartStrokeGridSetting($this->type));
        //chart animation setting
        $field = array_merge($field,graphinaDiviAnimationSetting($this->type));
        //chart Title setting
        $field = array_merge($field,graphinaDiviChartTitleSetting($this->type));
        //chart legend setting
        $field = array_merge($field,graphinaDiviLegendSetting($this->type));
        //chart datalabel setting
        $field = array_merge($field,graphinaDiviDataLabelSetting($this->type));
        //chart data setting
        $field = array_merge($field,graphinaDiviChartDataSetting($this->type));
        //chart responsive setting
        $field = array_merge($field,graphinaDiviChartResponsiveSetting($this->type));
        return $field;
    }

    public function get_advanced_fields_config() {
		return array();
	}

    public function render( $attrs, $content, $render_slug ) {
        graphinaDiviLoadModuleScript($this->type);

        /* Basic Chart Options */
        $chart_height   = $this->props['chart_height'];
		$chart_bg_color = $this->props['chart_bg_color'];
		$animation = $this->props['animation'];
		$animatiuonSpeed = $this->props['animation_speed'];

        /* toolbar */
        $toolbar = $this->props['toolbar'];
		$toolbar_offset_x = $this->props['toolbar_offset_x'];
		$toolbar_offset_y = $this->props['toolbar_offset_y'];

        /* datalabels */
        $data_label = $this->props['data_label'];
        $datalabel_fontsize = $this->props['datalabel_fontsize'];
        $datalabel_color = $this->props['datalabel_color'];

        /* plotoptions */
        $fill_color_opacity = $this->props['fill_color_opacity'];
		$fill_type = $this->props['fill_type'];
        $from_opacity = $this->props['gradient_opacity_from'];
        $to_opacity = $this->props['gradient_opacity_to'];

        /* legend */
        $legend = $this->props['legend_show'];
		$legend_color  = $this->props['lenend_color'];
		$legend_fontsize  = $this->props['lenend_fontsize'];
		$legendPosition = $this->props['legend_position'];
		$legendAlignment = $this->props['legend_alignment'];
        
        $brackpoint = $this->props['responsive_brackpoint'];
		$responsive_chart_height = $this->props['responsive_chart_height'];
        
        $data = ['series' => [], 'category' => []];
        if($this->props['data_type'] === 'manual'){
            if(isset($this->props['data_element_name'])){
                $data['series'] =
                     explode(',',str_replace('\n','',wp_strip_all_tags($this->props['data_element_name'])));
                
            }else{
                $data['series'] = [20, 50, 53, 15, 23, 15];
            }

            /* category data */

            if(!empty($this->props['category'])){
                $data['category'] = explode(',',str_replace('\n','',wp_strip_all_tags($this->props['category'])));
            }else{
                $data['category'] = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
            }
        }

        $colorArray = [];
        if(!empty($this->props['element_count'])){
            $element_count = $this->props['element_count'];
            for($i = 1;$i <= $element_count;$i++){
                $colorArray[]=!empty($this->props['fill_color'.$i]) ? $this->props['fill_color'.$i] : '#e53efc';
            }
        }

        $colorArray = implode('_,_', $colorArray);

        $category = implode('_,_', $data['category']);
        $series = implode('_,_',$data['series']);
        $category_data = array_map(function($catData) {
            return explode('[,]', $catData);
        }, explode('_,_', $category));
        
        $category_json = wp_json_encode($category_data);
        $chartID = !empty($this->props['chart_id']) ? $this->props['chart_id'] : graphinaDiviGenerateRandomString($this->type,$this->render_count());
        ob_start();
        graphinaDiviCommonChartHtml($this,$chartID);
		?>
        <script>
    document.addEventListener('readystatechange', event => {
        if (event.target.readyState === "complete") {
            var options = {
                series: <?php echo wp_json_encode(explode('_,_', $series)) ; ?>.map(catData => parseInt(catData)),
                chart: {
                    type: 'polarArea',
                    background: '<?php echo esc_html($chart_bg_color); ?>',
                    height: <?php echo intval(esc_html($chart_height)); ?>,
                    animations:{
                        enabled: <?php echo esc_html($animation);?>,
                        easing: 'easeinout',
                        speed: <?php echo intval(esc_html($animatiuonSpeed)); ?>,
                    },
                    toolbar: {
                        show: <?php echo esc_html($toolbar); ?>,
                        offsetX: '<?php echo esc_html($toolbar_offset_x);?>',
                        offsetY: '<?php echo esc_html($toolbar_offset_y); ?>',
                        tools: {
                            download: true,
                            reset: true,
                        },
                        export: {
                            svg: {
                                filename: 'graphina-charts',
                            },
                            png: {
                                filename: 'graphina-charts',
                            },
                            csv: {
                                filename: 'graphina-charts',
                                columnDelimiter: ",",
                                dateFormatter(timestamp) {
                                    return new Date(timestamp).toDateString()
                                }
                            },
                        }
                    },
                    legend: {
                        show: <?php echo esc_html($legend); ?>,
                        showForSingleSeries: true,
                        position: '<?php echo esc_html($legendPosition);?>',
                        horizontalAlign: '<?php echo esc_html($legendAlignment);?>',
                        fontSize: '<?php echo esc_html($legend_fontsize); ?>',
                        labels: {
                            colors: '<?php echo esc_html($legend_color);?>',
                        }
                    },
                    colors: '<?php echo esc_html($colorArray); ?>'.split('_,_'),
                    tooltip: {
                        enabled: '<?php echo esc_html($this->props['tooltip']); ?>',
                        theme: '<?php echo esc_html($this->props['tooltip_theme']); ?>',
                    },
                    fill: {
                        opacity: parseFloat('<?php echo esc_html($fill_color_opacity);?>'),
                        type:'<?php echo esc_html($fill_type);?>',
                        colors:'<?php echo esc_html($colorArray); ?>'.split('_,_'),
                        gradient: {
                            opacityFrom: parseFloat('<?php echo esc_html($from_opacity);?>'),
                            opacityTo: parseFloat('<?php echo esc_html($to_opacity);?>'),
                        }
                    },
                    dataLabels:{
                        enabled: <?php echo esc_html($data_label); ?>,
                        style:{
                            fontSize: '<?php echo esc_html($datalabel_fontsize); ?>'
                        },
                        background:{
                            enabled : true,
                            foreColor: '<?php echo esc_html($datalabel_color); ?>'
                        },
                        formatter: function (val,opts){
                            if(!val){
                                return val;
                            }
                            let decimal = parseInt('<?php echo !empty(esc_html($this->props['datalabel_decimal_point'])) ? esc_html($this->props['datalabel_decimal_point']) : 0 ?>') || 0;
                            if('<?php echo esc_html(!empty($this->props['datalabel_thousand_seperator_enable']) && $this->props['datalabel_thousand_seperator_enable'] === 'on'); ?>'){
                                val = graphinaDiviNumberThousandSeperate(val,decimal)
                            }else{
                                val = parseFloat(val).toFixed(decimal)
                            }
                            return '<?php echo esc_html($this->props['datalabel_label_prefix']);?>' + opts.w.config.series[opts.seriesIndex]  + '<?php echo esc_html($this->props['datalabel_label_postfix']);?>';
                        }
                    },
                    yaxis:{
                        show: true,
                        labels:{
                            style:{
                                fontSize: '<?php echo esc_html($this->props['yaxis_fontsize']); ?>'
                            }
                        }
                    },
                    labels: '<?php echo esc_attr($category); ?>'.split('_,_'),
                    title: {
                        text: '<?php echo esc_html($this->props['chart_title']); ?>',
                        align:'<?php echo esc_html($this->props['title_alignment']); ?>',
                        floating: false,
                        style: {
                            fontSize:'<?php echo esc_html($this->props['chart_title_fontsize']); ?>',
                            color: '<?php echo esc_html($this->props['chart_title_color']);?>',
                        }
                    },
                    plotOptions: {
                        polarArea: {
                            rings:{
                                strokeWidth: <?php echo esc_html($this->props['strock_width']); ?>,
                                strokeColor: '<?php echo esc_html($this->props['stroke_color']); ?>',
                            },
                            spokes:{
                                strokeWidth: 1,
                                connectorColors: '<?php echo esc_html($this->props['connector_color']); ?>',
                            }
                        }
                    },
                    responsive: [{
                        breakpoint: '<?php echo esc_html($brackpoint); ?>',
                        options: {
                            chart: {
                                height: parseInt('<?php echo esc_html($responsive_chart_height); ?>'),
                            },
                        }
                    }]
                }
            };

            var element = document.querySelector('<?php echo '#' . esc_html($chartID); ?>');
            if (typeof graphinaDiviRenderChart !== "undefined") {
                graphinaDiviRenderChart(
                    element,
                    {
                        ele: element,
                        options: options,
                        type: '<?php echo esc_js($this->type); ?>',
                        series: <?php echo wp_json_encode(array_map('intval', explode('_,_', $series))); ?>,
                        animation: <?php echo esc_js($animation); ?>,
                        category: <?php echo et_core_esc_previously($category_json); ?>
                    },
                    '<?php echo esc_js($this->type); ?>',
                    '<?php echo esc_js($chartID); ?>'
                );
            }

            if (typeof graphinaDiviDynamicData !== "undefined") {
                graphinaDiviDynamicData(
                    <?php echo et_core_esc_previously(wp_json_encode($this->props)); ?>,
                    '<?php echo esc_js($this->type); ?>',
                    '<?php echo esc_js($chartID); ?>',
                    '<?php echo (isset($this->props['ajax_reload']) && esc_js($this->props['ajax_reload']) === 'true') ? 'true' : 'false'; ?>',
                    '<?php echo esc_js((isset($this->props['ajax_reload_time']) && $this->props['ajax_reload_time'] != 0) ? $this->props['ajax_reload_time'] : 5); ?>'
                );
            }
        }
    });
</script>


        <?php
        return ob_get_clean();
    }

}

new GRDI_Polarchart;