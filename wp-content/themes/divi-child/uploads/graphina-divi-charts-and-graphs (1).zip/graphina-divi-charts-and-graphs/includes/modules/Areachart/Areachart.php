<?php
class GRDI_Areachart extends ET_Builder_Module
{

    protected $module_credits = array(
        'module_uri' => '',
        'author'     => '',
        'author_uri' => '',
    );
    public $slug       = 'grdi_area_chart';
    public $vb_support = 'on';
    public $type = 'area';
    public $icon_path ;
    
    public function init()
    {
        
        $this->icon_path = plugin_dir_path(__FILE__) . 'icon.svg';
        $this->name = __('Area Chart', 'grdi-graphina-divi');
        $this->_use_unique_id  = true;

        $this->settings_modal_toggles = array(
            'general'  => array(
                'toggles' => array(
                    'card_setting' => __('Card Settings', 'grdi-graphina-divi'),
                    'chart_data' => __('Chart Data Settings', 'grdi-graphina-divi'),
                    'main_content' => __('Basic Chart Settings', 'grdi-graphina-divi'),
                    'data_series' => __('Data', 'grdi-graphina-divi'),
                    'chart_title' => __('Chart Title', 'grdi-graphina-divi'),
                    'tooltip' => __('Tooltip', 'grdi-graphina-divi'),
                    'datalabel' => __('Data Labels', 'grdi-graphina-divi'),
                    'legend' => __('Legend Settings', 'grdi-graphina-divi'),
                    'xaxis' => __('X Axis Settings', 'grdi-graphina-divi'),
                    'yaxis' => __('Y Axis Settings', 'grdi-graphina-divi'),
                ),
            ),
        );
        $this->main_css_element = ".grahina-divi";


        $this->help_videos = array(
            array(
                'id'   => '-Z1OdCU_mP8',
                'name' => esc_html__( 'An introduction to the Graphina Area Chart module', 'grdi-graphina-divi' ),
            ),
        );
    }

    public function get_advanced_fields_config()
    {
        return array(
            'borders'               => array(
                'default' => array(),
                'image'   => array(
                    'css'             => array(
                        'main' => array(
                            'border_radii' => ".grahina-divi",
                            'border_styles' => ".grahina-divi",
                        )
                    ),
                ),
            ),
        );
    }

    public function get_fields()
    {

        $field = array();
        // card setting
        $field = array_merge($field, graphinadiviCardSetting('area'));
        // chart height and color
        $field = array_merge($field, graphinaDiviChartHeightColorSetting($this->type));
        // chart Toolbar setting
        $field = array_merge($field, graphinaDiviToolbarSetting($this->type));
        //chart stroke and grid setting
        $field = array_merge($field, graphinaDiviChartStrokeGridSetting($this->type));
        //chart animation setting
        $field = array_merge($field, graphinaDiviAnimationSetting($this->type));
        //chart tooltip setting
        $field = array_merge($field, graphinaDiviChartToolTip($this->type));
        //chart Title setting
        $field = array_merge($field, graphinaDiviChartTitleSetting($this->type));
        //chart tooltip setting
        $field = array_merge($field, graphinaDiviChartToolTip($this->type));
        //chart datalabel setting
        $field = array_merge($field, graphinaDiviDataLabelSetting($this->type));
        //chart legend setting
        $field = array_merge($field, graphinaDiviLegendSetting($this->type));
        //chart yaxis setting
        $field = array_merge($field, graphinaDiviYaxisSetting($this->type));
        //chart xaxis setting
        $field = array_merge($field, graphinaDiviXaxisSetting($this->type));
        //chart data setting
        $field = array_merge($field, graphinaDiviChartDataSetting($this->type));
        return $field;
    }


    public function render($attrs, $content, $render_slug)
    {

        /* add external js & css */
        graphinaDiviLoadModuleScript($this->type);

        /* chart options */
        $title = $this->props['chart_title'];
        $align = $this->props['title_alignment'];
        $color = $this->props['chart_title_color'];
        $fontsize = $this->props['chart_title_fontsize'];

        $legend_color  = $this->props['lenend_color'];
        $legend_fontsize  = $this->props['lenend_fontsize'];
        $chart_height   = $this->props['chart_height'];
        $chart_bg_color = $this->props['chart_bg_color'];
        $labelShow      = $this->props['xaxis_label'];
        $labelPossition = $this->props['xaxis_position'];
        $toolbar = $this->props['toolbar'];
        $toolbar_offset_x = $this->props['toolbar_offset_x'];
        $toolbar_offset_y = $this->props['toolbar_offset_y'];
        $animation = $this->props['animation'];
        $animationSpeed = $this->props['animation_speed'];
        $legend = $this->props['legend_show'];
        $legendPosition = $this->props['legend_position'];
        $legendAlignment = $this->props['legend_alignment'];

        /* xaxis */
        $xaxisTooltip = $this->props['xaxis_tooltip'];
        $xaxisLabelRotate = $this->props['xaxis_label_rotate'];
        $xaxisLabelRotateDeg = $this->props['xaxis_label_rotate_deg'];
        $xaxisOffsetX = $this->props['xaxis_offset_x'];
        $xaxisOffsetY = $this->props['xaxis_offset_y'];
        $xaxisLabelColor = $this->props['xaxis_label_color'];
        $xaxisLabelFontSize = $this->props['xaxis_label_fontsize'];

        // Y axis
        $yaxisLable = $this->props['yaxis_label'];
        //$yaxisMin = $this->props['yaxis_min'];
        //$yaxisMax = $this->props['yaxis_max'];
        $yaxisTooltip = $this->props['yaxis_tooltip'];
        $yaxisDatalabel = $this->props['yaxis_datalabel'];
        $yaxisLabelRotate = $this->props['yaxis_label_rotate'];
        $yaxisLabelRotateDeg = $this->props['yaxis_label_rotate_deg'];
        $yaxisOffset_x = $this->props['yaxis_offset_x'];
        $yaxisOffset_y = $this->props['yaxis_offset_y'];
        $yaxisColor = $this->props['yaxis_label_color'];
        $yaxisFontsize = $this->props['yaxis_label_fontsize'];

        /* datalabels */
        $data_label = $this->props['data_label'];
        $data_label_fontsize = $this->props['datalabel_fontsize'];
        $data_label_color = $this->props['datalabel_color'];

        $grid_line = $this->props['grid_line'];

        /* stroke */
        $stroke = $this->props['stroke'];
        $stroke_width = $this->props['strock_width'];
        $element_count = $this->props['element_count'];

        $data = ['series' => [], 'category' => []];
        if ($this->props['data_type'] === 'manual') {
            /* category data */
            if (!empty($this->props['category'])) {
                $data['category'] = explode(',', str_replace('\n', '', wp_strip_all_tags($this->props['category'])));
            } else {
                $data['category'] = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'July', 'Aug', 'Sup', 'Oct', 'Nov', 'Dec'];
            }
        }

        $colorArray = [];
        if (!empty($this->props['element_count'])) {
            for ($i = 1; $i <= $element_count; $i++) {
                if ($this->props['data_type'] === 'manual') {
                    $data['series'][] = [
                        'name' => !empty($this->props['data_element_name' . $i]) ? $this->props['data_element_name' . $i] : 'Series ' . $i,
                        'data' => !empty($this->props['data_element_value' . $i]) ? explode(",", str_replace('\n', '', wp_strip_all_tags($this->props['data_element_value' . $i]))) : [],
                    ];
                }
                $colorArray[] = !empty($this->props['fill_color' . $i]) ? $this->props['fill_color' . $i] : '#e53efc';
            }
        }
        $category = esc_html(implode('_,_', array_map('esc_html', $data['category'])));
        $series = wp_json_encode( $data['series']);
        $colorArray = esc_html(implode('_,_', array_map('esc_html', $colorArray)));
        $chartID = !empty($this->props['chart_id']) ? esc_html($this->props['chart_id']) : esc_html(graphinaDiviGenerateRandomString($this->type, $this->render_count()));
        ob_start();
        graphinaDiviCommonChartHtml($this, $chartID);
        ?>
        <script>
        document.addEventListener('readystatechange', event => {
            if (event.target.readyState === "complete") {
                var options = {
                    series: <?php echo et_core_esc_previously($series); ?>,
                    chart: {
                        type: "area",
                        height: parseInt('<?php echo esc_html($chart_height); ?>'),
                        background: '<?php echo esc_html($chart_bg_color); ?>',
                        animations: {
                            enabled: <?php echo esc_html($animation); ?>,
                            easing: 'easeinout',
                            speed: parseInt('<?php echo esc_html($animationSpeed); ?>'),
                        },
                        zoom: {
                            enabled: false
                        },
                        toolbar: {
                            show: <?php echo esc_html($toolbar); ?>,
                            offsetX: '<?php echo esc_html($toolbar_offset_x); ?>',
                            offsetY: '<?php echo esc_html($toolbar_offset_y); ?>',
                            tools: {
                                download: true,
                                reset: true,
                            },
                            export: {
                                svg: {
                                    filename: "graphina-charts",
                                },
                                png: {
                                    filename: "graphina-charts",
                                },
                                csv: {
                                    filename: "graphina-charts",
                                    columnDelimiter: ",",
                                    dateFormatter(timestamp) {
                                        return new Date(timestamp).toDateString()
                                    }
                                },
                            }
                        },
                        noData: {
                            text: '<?php echo esc_html__('Loading...', 'grdi-graphina-divi'); ?>',
                            align: 'center',
                            verticalAlign: 'middle',
                        },
                        dataLabels: {
                            enabled: <?php echo esc_html($data_label); ?>,
                            style: {
                                fontSize: '<?php echo esc_html($data_label_fontsize); ?>',
                            },
                            background: {
                                enabled: true,
                                foreColor: '<?php echo esc_html($data_label_color); ?>',
                            },
                            formatter: function (val, opts) {
                                if (!val) {
                                    return val;
                                }
                                let decimal = parseInt('<?php echo esc_attr(!empty($this->props['datalabel_decimal_point']) ? $this->props['datalabel_decimal_point'] : 0); ?>') || 0;
                                if ('<?php echo esc_js(!empty($this->props['datalabel_thousand_seperator_enable']) && $this->props['datalabel_thousand_seperator_enable'] === 'on'); ?>') {
                                    val = graphinaDiviNumberThousandSeperate(val, decimal);
                                } else {
                                    val = parseFloat(val).toFixed(decimal);
                                }
                                return '<?php echo esc_html($this->props['datalabel_label_prefix']); ?>' + val + '<?php echo esc_html($this->props['datalabel_label_postfix']); ?>';
                            },
                        },
                        legend: {
                            show: <?php echo esc_html($legend); ?>,
                            showForSingleSeries: <?php echo esc_html($legend); ?>,
                            position:'<?php echo esc_html($legendPosition);?>',
                            horizontalAlign: '<?php echo esc_html($legendAlignment);?>',
                            fontSize: parseInt('<?php echo esc_html($legend_fontsize); ?>'),
                            labels: {
                                colors:'<?php echo esc_html($legend_color);?>',
                            }
                        },
                        colors: '<?php echo esc_html($colorArray); ?>'.split('_,_'),
                        fill: {
                            type:'classic',
                            colors:'<?php echo esc_html($colorArray); ?>'.split('_,_'),
                            opacity:0.5
                        },
                        title: {
                            text: '<?php echo esc_html($title); ?>',
                            align:'<?php echo esc_html($align); ?>',
                            floating: false,
                            style: {
                                fontSize:'<?php echo esc_html($fontsize); ?>',
                                color: '<?php echo esc_html($color);?>',
                            }
                        },
                        grid: {
                            borderColor: '<?php echo esc_html($this->props['grid_line_color']); ?>',
                            yaxis: {
                                lines: {
                                    show: <?php echo esc_html($grid_line); ?>,
                                }
                            },
                        },
                        stroke: {
                            show: true,
                            curve: '<?php echo esc_html($stroke); ?>',
                            width: parseInt('<?php echo esc_html($stroke_width); ?>'),
                        },
                        xaxis: {
                            categories:'<?php echo esc_html($category); ?>'.split('_,_').map(
                                catData => catData.split('[,]')
                            ),
                            position: '<?php echo esc_html($labelPossition);?>',
                            labels: {
                                show:<?php echo esc_html($labelShow);?>,
                                rotateAlways: <?php echo esc_html($xaxisLabelRotate);?>,
                                rotate: parseInt('<?php echo esc_html($xaxisLabelRotateDeg); ?>'),
                                offsetX: parseInt('<?php echo esc_html($xaxisOffsetX); ?>'),
                                offsetY: parseInt('<?php echo esc_html($xaxisOffsetY); ?>'),
                                style:{
                                    colors:'<?php echo esc_html($xaxisLabelColor); ?>',
                                    fontSize:'<?php echo esc_html($xaxisLabelFontSize); ?>',
                                },
                                formatter: function (val, opts) {
                                    if(!val){
                                        return val;
                                    }
                                    return '<?php echo esc_html($this->props['xaxis_label_prefix']);?>' + val + '<?php echo esc_html($this->props['xaxis_label_postfix']);?>'
                                },
                            },
                            tooltip: {
                                enabled: <?php echo esc_html($xaxisTooltip); ?>,
                            },
                            crosshairs:{
                                show :<?php echo esc_html($this->props['xaxis_crosshair']); ?>
                            }
                        },
                        yaxis: {
                            show: <?php echo esc_html($yaxisLable); ?>,
                            // min:'<?php //echo esc_html($yaxisMin);?>',
                            // max:'<?php //echo esc_html($yaxisMax);?>',
                            tooltip: {
                                enabled: <?php echo esc_html($yaxisTooltip); ?>
                            },
                            labels: {
                                show: <?php echo esc_html($yaxisDatalabel); ?>,
                                rotateAlways: <?php echo esc_html($yaxisLabelRotate); ?>,
                                rotate: parseInt('<?php echo esc_html($yaxisLabelRotateDeg); ?>'),
                                offsetX: parseInt('<?php echo esc_html($yaxisOffset_x); ?>'),
                                offsetY: parseInt('<?php echo esc_html($yaxisOffset_y); ?>'),
                                trim: true,
                                style: {
                                    colors: '<?php echo esc_html($yaxisColor); ?>',
                                    fontSize: '<?php echo esc_html($yaxisFontsize); ?>'
                                },
                                formatter: function (val, opts) {
                                    if (!val) {
                                        return val;
                                    }
                                    let decimal = parseInt('<?php echo esc_attr(!empty($this->props['yaxis_decimal_point']) ? $this->props['yaxis_decimal_point'] : 0); ?>') || 0;
                                    if ('<?php echo esc_js(!empty($this->props['yaxis_thousand_seperator_enable']) && $this->props['yaxis_thousand_seperator_enable'] === 'on'); ?>') {
                                        val = graphinaDiviNumberThousandSeperate(val, decimal);
                                    } else {
                                        val = parseFloat(val).toFixed(decimal);
                                    }
                                    return '<?php echo esc_html($this->props['yaxis_label_prefix']); ?>' + val + '<?php echo esc_html($this->props['yaxis_label_postfix']); ?>';
                                },
                            }
                        },
                        tooltip: {
                            enabled: <?php echo esc_html($this->props['tooltip']); ?>,
                            intersect: false,
                            theme: '<?php echo esc_html($this->props['tooltip_theme']); ?>',
                            shared:true,
                            style: {
                                fontSize: "14px",
                            },
                        },
                    },
                }

                var element = document.querySelector('<?php echo '#'.esc_html($chartID); ?>');
                
                if(typeof graphinaDiviRenderChart !== "undefined"){
                    graphinaDiviRenderChart(
                        element,
                        {
                            ele: element,
                            options: options,
                            animation:      <?php echo esc_html($animation); ?>,
                            type: '<?php echo esc_html($this->type); ?>',
                            series: <?php echo et_core_esc_previously($series); ?>,
                            category: '<?php echo esc_html($category); ?>'.split('_,_').map(
                                catData => catData.split('[,]')
                            )
                        },
                        '<?php echo esc_html($this->type); ?>',
                        '<?php echo esc_html($chartID); ?>'
                    )
                }
                if (typeof graphinaDiviDynamicData !== "undefined") {
                    graphinaDiviDynamicData(
                        <?php echo wp_json_encode($this->props); ?>,
                        '<?php echo esc_html($this->type); ?>',
                        '<?php echo esc_html($chartID); ?>',
                        '<?php echo esc_html(!empty($this->props['ajax_reload']) && $this->props['ajax_reload'] === 'true' ? 'true' : 'false'); ?>',
                        '<?php echo esc_html(!empty($this->props['ajax_reload_time']) && $this->props['ajax_reload_time'] != 0 ? $this->props['ajax_reload_time'] : 5); ?>')
                }
            }
        });
        </script>
        
        <?php
        return ob_get_clean();
        
	}
}

new GRDI_Areachart;
