<?php
    class GRDI_Datatable extends ET_Builder_Module{
        protected $module_credits = array(
            'module_uri' => '',
            'author'     => '',
            'author_uri' => '',
        );
        public $slug       = 'grdi_datatable';
        public $vb_support = 'on';
        public $type = 'datatable';

        public function init()
        {

            $this->name = __('Data Table', 'grdi-graphina-divi');
            $this->_use_unique_id  = true;

            $this->settings_modal_toggles = array(
                'general'  => array(
                    'toggles' => array(
                        'table_data'    => __('Data Options', 'grdi-graphina-divi'),
                        'table_setting' => __('Table Setting', 'grdi-graphina-divi'),
                        'table_column'  => __('Column Data', 'grdi-graphina-divi'),
                        'data_row'      => __('Row Data', 'grdi-graphina-divi'),
                        'header_style'  => __('Header Style', 'grdi-graphina-divi'),
                        'responsive'    => __('Responsive', 'grdi-graphina-divi'),
                        'restriction_access_control' =>__('Restriction Access Control','grdi-graphina-divi'),
                    ),
                ),
            );
        }

        public function getCurrentDatabaseTableNames() {
            global $wpdb;
        
            $query = "SHOW TABLES";
            // phpcs:ignore
            $tables = $wpdb->get_results($query, ARRAY_N); 
        
            $tableNames = array();
            foreach ($tables as $table) {
                // Get the table name from the query result
                $tableName = reset($table);
        
                // Sanitize the table name
                $sanitizedTableName = sanitize_key($tableName);
        
                $tableNames[] = $sanitizedTableName;
            }
        
            return $tableNames;
        }

        public function get_fields()
        {
             $field = array();
             // card setting
            $field = array_merge($field, graphinadiviCardSetting('Datatable'));
            $field = array_merge($field,graphinadatatable_psettings($this->type));
            //chart plotoption setting
            $field = array_merge($field, graphinaDiviChartPlotoptionSetting($this->type));
            //chart responsive setting
            $field = array_merge($field, graphinaDiviChartResponsiveSetting($this->type));
        
            // ========== Table Settings =========== //
            $field['no_of_rows'] = array(
                'label'     => __('No of Rows', 'et_builder'),
                'type'      => 'number',
                'option_category'   => 'configuration',
                'toggle_slug'   => 'table_data',
                'default'   => '3',
                
            );
            $field['no_of_columns'] = array(
                'label'     => __('No of Columns', 'et_builder'),
                'type'      => 'number' ,
                'option_category'   => 'configuration',
                'toggle_slug'   => 'table_data',
                'default'   => 3,
            );

            $field['table_search'] = array(
                'label'        => __('Search Enabled', 'grdi-graphina-divi'),
                'type'         => 'yes_no_button',
                'option_category'  => 'configuration',
                'options'          => array(
                    'on'  => __('Yes', 'grdi-graphina-divi'),
                    'off' => __('No', 'grdi-graphina-divi'), 
                ),
                'toggle_slug'  => 'table_setting',
                'default' => 'on',
            );
            $field['search_align'] = array(
                'label'        => __('Search Alignment', 'grdi-graphina-divi'),
                'type'         => 'text_align',
                'option_category'  => 'configuration',
                'options'         => et_builder_get_text_orientation_options(array('justified')),
                'toggle_slug'  => 'table_setting',
                'default'  =>  'center',
                'mobile_options'  => true,
                'show_if'         => array(
                    'table_search'     => 'on'
                )
            );
        

    $field['show_header'] = array(
                'label'        => __('Show Header', 'grdi-graphina-divi'),
                'type'         => 'yes_no_button',
                'option_category'  => 'configuration',
                'options'          => array(
                    'on'  => __('Yes', 'grdi-graphina-divi'),
                    'off' => __('No', 'grdi-graphina-divi'),
                ),
                'toggle_slug'  => 'table_setting',
                'default' => 'on',
            );

    $field['show_index'] = array(
                'label'        => __('Show Indexing', 'grdi-graphina-divi'),
                'type'         => 'yes_no_button',
                'option_category'  => 'configuration',
                'options'          => array(
                    'on'  => __('Yes', 'grdi-graphina-divi'),
                    'off' => __('No', 'grdi-graphina-divi'),
                ),
                'toggle_slug'  => 'table_setting',
                'default' => 'on',
            );
        $field['index_type'] = array(
                'label'        => __('Index Numbers', 'grdi-graphina-divi'),
                'type'         => 'select',
                'option_category'  => 'configuration',
                'options'          => array(
                    'normal'  => __('normal', 'grdi-graphina-divi'),
                    'roman' => __('roman', 'grdi-graphina-divi'),
                ),
                'toggle_slug'  => 'table_setting',
                'default' => 'normal',
                'show_if' => [
                    'show_index'  =>  'on'
                ]
            );

        

          
        

            // for($i=2; $i < 4 ; $i++){
            //     $field['row_data' . $i] = array(
            //         'label'        => __(  'Row '.$i.' Data ' . ($i + 1), 'grdi-graphina-divi' ),
            //         'type' => 'text',
            //         'default'      => 'Data 1, Data 2, Data 3',
            //         'toggle_slug'  => 'data_row',
            //         'show_if' => [
            //         'data_type' => ['manual']
            //     ]
            //     );  
            // }
            // ============ Data Options ============ //

            $field['_section_column_2'] = array(
                'toggle_slug'    => 'table_data',
            );

            $field['data_type'] = array(
                'label'     => __('DataType', 'et_builder'),
                'type'    => 'select',
                'option_category'   => 'basic_option',
                'options'       => array(
                    'manual'     => __('Manual', 'grdi-graphina-divi'),
                    'dynamic'     => __('Dynamic', 'grdi-graphina-divi'),
                ),
                'toggle_slug'   => 'table_data',
                'default'   => 'manual',
            );

            $field['dynamic_data_type'] = array(
                'label' => __('Dynamic DataType', 'grdi-graphina-divi'),
                'type' => 'select',
                'option_category' => 'basic_option',
                'options'         => array(
                    'csv' => __('CSV', 'grdi-graphina-divi'),
                    'remote-csv' => __('Remote CSV', 'grdi-graphina-divi'),
                    'google-sheet' => __('Google Sheet', 'grdi-graphina-divi'),
                    'api' => __('API', 'grdi-graphina-divi'),
                    'database'=> __('Data Base', 'grdi-graphina-divi'),
                ),
                'toggle_slug' => 'table_data',
                'default' => 'csv',
                'show_if' => [
                    'data_type' => ['dynamic']
                ]
            );
            $field['table_name'] =  array(
                'label' => __('Select or Table', 'grdi-graphina-divi'),
                'type' => 'select',
                'option_category' => 'basic_option',
                'options'         => $this->getCurrentDatabaseTableNames(),
                'toggle_slug' => 'table_data',
                'show_if' => [
                    'data_type' => ['dynamic'],
                    'dynamic_data_type' => ['database']
                ]
            );
            $field['csv_url'] = array(
                'label' => __('Select or Upload CSV', 'grdi-graphina-divi'),
                'type' => 'upload',
                'option_category' => 'basic_option',
                'upload_button_text' => __('Upload an csv'),
                'choose_text' => __('Choose an CSV', 'grdi-graphina-divi'),
                'update_text' => __('Set As CSV', 'grdi-graphina-divi'),
                'data_type' => 'text/csv',
                'description' => sprintf("%s <a style='color:red' href='%s' download><p>%s</p></a>",__("Upload your desired CSV, or type in the URL to the CSV you would like to use. download sample csv from"),esc_url(GRAPHINA_DIVI_URL . '/sample-file/csv-file/' . $this->type . '-chart-sample.csv'),__("here","grdi-graphina-divi")),
                'toggle_slug' => 'table_data',
                'mobile_options' => true,
                'hover' => 'tabs',
                'show_if' => [
                    'data_type' => ['dynamic'],
                    'dynamic_data_type' => ['csv']
                ]
            );

            $field['googlesheet_url'] = array(
                'label' => __('Enter GoogleSheet Url', 'grdi-graphina-divi'),
                'type' => 'text',
                'option_category' => 'basic_option',
                'dynamic_content' => 'text',
                'show_if' => [
                    'data_type' => ['dynamic'],
                    'dynamic_data_type' => ['google-sheet']
                ],
                'description' => sprintf("%s <a style='color:red' href='%s' target='_blank'>%s</a> ",esc_html__("Publish googlesheet as csv and enter googlesheet url to use. get sample googlesheet from ","grdi-graphina-divi"), graphinaDiviGetSpreadsheet($this->type),__("here",'grdi-graphina-divi')),
                'toggle_slug' => 'table_data',
            );

            $field['remote_csv_url'] = array(
                'label' => __('Enter Remote CSV Url', 'grdi-graphina-divi'),
                'type' => 'text',
                'dynamic_content' => 'text',
                'option_category' => 'basic_option',
                'description' => sprintf("%s <a style='color:red' href='%s' target='_blank'>%s</a> ",esc_html__("Enter CSV Url you would like to use. download sample csv from ","grdi-graphina-divi"), GRAPHINA_DIVI_URL . '/sample-file/csv-file/' . $this->type . '-chart-sample.csv' ,__("here",'grdi-graphina-divi')),
                'show_if' => [
                    'data_type' => ['dynamic'],
                    'dynamic_data_type' => ['remote-csv']
                ],
                'toggle_slug' => 'table_data',
            );

            $field['api_url'] = array(
                'label' => __('Enter API Url', 'grdi-graphina-divi'),
                'type' => 'text',
                'option_category' => 'basic_option',
                'dynamic_content' => 'text',
                'description' => sprintf("%s <a style='color:red' href='%s' target='_blank'>%s</a> <hr> %s %s",esc_html__("Enter Api Url or json file url you would like to use. download sample json file from ","grdi-graphina-divi"), GRAPHINA_DIVI_URL . '/sample-file/json-file/' . $this->type . '-chart-sample.json' ,__("here",'grdi-graphina-divi'),esc_html__("Use Dynamic key in Api url , it will replace key will dynamic value","grdi-graphina-divi"),"<strong>(example : &user_id={{CURRENT_USER_ID}} <a href='https://wordpress.iqonic.design/docs/product/graphina-elementor-charts-and-graphs/use-dynamic-data-in-widgets/dynamic_key/' target='_blank'> <span style='color:#93003c'> List of Dynamic key </span> </a> </strong>"),
                'show_if' => [
                    'data_type' => ['dynamic'],
                    'dynamic_data_type' => ['api']
                ],
                'toggle_slug' => 'table_data',
            );

            $field['authrization_token_enable'] = array(
                'label' => __('Enable API Header Options', 'et_builder'),
                'type' => 'select',
                'option_category' => 'basic_option',
                'options' => array(
                    'true' => __('Yes', 'grdi-graphina-divi'),
                    'false' => __('No', 'grdi-graphina-divi'),
                ),
                'toggle_slug' => 'table_data',
                'default' => 'false',
                'show_if' => [
                    'data_type' => ['dynamic'],
                    'dynamic_data_type' => ['api']
                ],
            );

            $field['api_header_key'] = array(
                'label' => __('Header Key', 'grdi-graphina-divi'),
                'type' => 'text',
                'dynamic_content' => 'text',
                'option_category' => 'basic_option',
                'show_if' => [
                    'data_type' => ['dynamic'],
                    'dynamic_data_type' => ['api'],
                    'authrization_token_enable' => ['true']
                ],
                'toggle_slug' => 'table_data',
            );

            $field['api_header_token'] = array(
                'label' => __('Header Token', 'grdi-graphina-divi'),
                'type' => 'text',
                'option_category' => 'basic_option',
                'dynamic_content' => 'text',
                'show_if' => [
                    'data_type' => ['dynamic'],
                    'dynamic_data_type' => ['api'],
                    'authrization_token_enable' => 'true'
                ],
                'toggle_slug' => 'table_data',
            );

        
            // for($i=1; $i <= $field['no_of_rows']; $i++){
            //     $field['row_data' . $i] = array(
            //         'label' => __('Row' . $i . 'Data', 'grdi-graphina-divi'),
            //         'type'  => 'text',
            //         'toggle_slug'   => 'table_data',
            //         'default' => "Row" . $i,
            //         'dynamic_content' => 'text',
            //         'show_if' => [
            //             'data_type' => ['manual']
            //         ]
            //     );
            // }


            return $field;
        }


        public function render($attrs, $content, $render_slug)
        {
            graphinaDiviLoadModuleScript($this->type);
            graphinadividatatablescripts('datatype');
            $table_search = $this->props['table_search'];
            $table_search = esc_attr($this->props['table_search']);
            $no_of_rows = intval($this->props['no_of_rows']);
            $no_of_columns = intval($this->props['no_of_columns']);
            $show_index = esc_attr($this->props['show_index']);
            $show_header = esc_attr($this->props['show_header']);
            $index_type = esc_attr($this->props['index_type']);
            $csv_url = esc_url($this->props['csv_url']);
            $authrization_token_enable = esc_attr($this->props['authrization_token_enable']);
            $show_card = esc_attr($this->props['show_card']);
            $card_align = esc_attr($this->props['card_title_align']);
            $card_color = esc_attr($this->props['card_color']);
            $search_align = esc_attr($this->props['search_align']);
            $col = [];
            $row = [];
            $chartID = !empty($this->props['_unique_id']) ? $this->props['_unique_id'] : graphinaDiviGenerateRandomString($this->type, $this->render_count());
            ob_start();
        ?>
            <div id="<?php echo esc_attr($chartID)?>" class="dividata">
                <?php if($show_card == 'on'){ ?>
                    <div class="grp_table_header" style="text-align: <?php echo esc_attr($card_align); ?>;background-color: <?php echo esc_attr($card_color); ?>">
                        <h1><?php echo esc_html($this->props['title']);?></h1> 
                        <p><?php echo esc_html($this->props['description']);?></p>
                    </div>
                <?php } ?>
                <div class="graphina_table_mprev">
                    <div class="graphina_Search_filter"></div>
                    <div class="graphina_divi_table_frontend"></div>
                </div>
            </div>
        <script>
                document.addEventListener('readystatechange', event => {
                    
                    if (event.target.readyState === "complete"){
                        var numRows = <?php echo esc_js($no_of_rows); ?>;
                        // Number of columns
                        var numCols = <?php echo esc_js($no_of_columns); ?>;
                        // Show header
                        var showHeader = '<?php echo esc_js($show_header); ?>';
                        // Show index
                        var showIndex = '<?php echo esc_js($show_index); ?>';
                        // Index type
                        var indexType = '<?php echo esc_js($index_type); ?>';
                        // Table search option
                        var tableSearch = '<?php echo esc_js($table_search); ?>';
                        // chart id
                        var tableContainerId = '<?php echo esc_attr($chartID)?>';
                    }
                    if(showIndex==="on"){
                        numCols = numCols+1;
                    }
                    // Build the table HTML structure
                    console.log(tableSearch);
                    var tableHtml = '<table border="1" class="graphina_divi_table">';
                    if (showHeader == 'on') {
                        tableHtml += '<thead class="graphina" id="'+tableContainerId+'">';
                        tableHtml += '<tr>';
                        for (var j = 0; j < numCols; j++) {
                            tableHtml += '<th></th>';
                        }
                        tableHtml += '</tr>';
                        tableHtml += '</thead>';
                    }
                    tableHtml += '<tbody class="graphina" id="'+tableContainerId+'">';
                    for (var i = 0; i < numRows; i++) {
                        tableHtml += '<tr>';
                        for (var j = 0; j < numCols; j++) {
                            tableHtml += '<td></td>';
                        }
                        tableHtml += '</tr>';
                    }
                    tableHtml += '</tbody>';
                    tableHtml += '</table';
                    // Set the generated table HTML
                    jQuery('#' + tableContainerId + ' .graphina_divi_table_frontend').html(tableHtml);

                    // Add search input if table search is enabled
                    if (tableSearch === 'on') {
                        var searchHtml = '<div class="grp_searchbox" style="display: flex;justify-content: <?php echo esc_attr($search_align) ?>;align-items: <?php echo esc_attr($search_align) ?>;"><input type="text" id="search-input-' + tableContainerId + '" placeholder="Search"></div>';
                        jQuery('#' + tableContainerId +' .graphina_Search_filter').prepend(searchHtml);

                        jQuery('#' + tableContainerId).on('input', function() {
                            filterTable(tableContainerId);
                        });
                    }



                    // Function to filter the table
                    function filterTable(tableContainerId) {
                        var input = jQuery('#search-input-' + tableContainerId).val().toLowerCase();
                        jQuery('#' + tableContainerId + ' table.graphina_divi_table tbody tr').each(function() {
                            var rowText = jQuery(this).text().toLowerCase();
                            if (rowText.indexOf(input) === -1) {
                                jQuery(this).hide();
                            } else {
                                jQuery(this).show();
                            }
                        });
                    }

                    // Add Roman numerals to index cells if specified
                    if (showIndex === 'on' && indexType === 'roman') {
                        var rowIndex = 1;
                        jQuery('#' + tableContainerId + ' table.graphina_divi_table tbody tr').each(function() {
                            var indexCell = '<td>' + toRoman(rowIndex) + '</td>';
                            jQuery(this).prepend(indexCell);
                            rowIndex++;
                        });
                    }

                    // Function to convert Arabic numbers to Roman numerals
                    function toRoman(num) {
                        if (num < 1 || num > 3999) {
                            return "Invalid Number";
                        }

                        var romanNumerals = [
                            { value: 1000, numeral: "M" },
                            { value: 900, numeral: "CM" },
                            { value: 500, numeral: "D" },
                            { value: 400, numeral: "CD" },
                            { value: 100, numeral: "C" },
                            { value: 90, numeral: "XC" },
                            { value: 50, numeral: "L" },
                            { value: 40, numeral: "XL" },
                            { value: 10, numeral: "X" },
                            { value: 9, numeral: "IX" },
                            { value: 5, numeral: "V" },
                            { value: 4, numeral: "IV" },
                            { value: 1, numeral: "I" }
                        ];

                        var result = '';
                        for (var i = 0; i < romanNumerals.length; i++) {
                            while (num >= romanNumerals[i].value) {
                                result += romanNumerals[i].numeral;
                                num -= romanNumerals[i].value;
                            }
                        }

                        return result;
                    }

                    // Send an AJAX request to get table data
                    jQuery.ajax({
                        url: '<?php echo esc_url(admin_url('admin-ajax.php')); ?>',
                        type: 'POST',
                        data: {
                            action: 'get_jquery_datatable_data_fe',
                            chart_id: '<?php echo esc_js($this->props['_unique_id']); ?>',
                            chart_type: 'datatable',
                            page_id: '<?php echo esc_js(get_the_ID()) ?>',
                            security: window.graphina_divi_localize.nonce, // Pass the nonce for verification
                            fields: <?php echo (wp_json_encode($this->props)); ?>
                        },
                        success: function(response) {
                            if (response.status !== 'false') {
                                // Extract data from the response
                                console.log(response);
                                var header = response.data.header;
                                var body = response.data.body;
                                // Populate the table header if it's not empty
                                if (showHeader == 'on' && header.length > 0) { 
                                    var headerRow = jQuery('#'+tableContainerId+' table.graphina_divi_table thead tr');
                                    if (showIndex == 'on') {
                                        // Prepend 'Index' to the header
                                        header.unshift('Index');
                                    }
                                    for (var h = 0; h < header.length; h++) {
                                        headerRow.find('th:eq(' + h + ')').text(header[h]);
                                    }
                                } else {
                                    // Hide or remove the table header if 'showHeader' is true and 'header' is empty
                                    jQuery('#'+tableContainerId+' table.graphina_divi_table thead').hide();
                                }

                                // Populate the table body
                                var tableBody = jQuery('#'+tableContainerId+' table.graphina_divi_table tbody');
                                tableBody.empty(); // Clear existing rows

                                for (var i = 0; i < body.length; i++) {
                                    var rowData = body[i];
                                    var colData = <?php echo esc_js($no_of_columns); ?>;
                                    var rowHtml = '<tr>';
                                    if (showIndex == 'on') {
                                        // Add index column
                                        rowHtml += '<td>' + (i + 1) + '</td>';
                                    }
                                    for (var j = 0; j < colData; j++) {
                                        var cellValue = rowData[j] || '';// Get cell value or empty string if undefined
                                        rowHtml += '<td>' + cellValue + '</td>';
                                    }

                                    rowHtml += '</tr>';
                                    tableBody.append(rowHtml);
                                }
                                jQuery('#'+tableContainerId).css('display', 'block');
                            } else {
                                // Handle the case where there are issues getting data
                                jQuery('#'+tableContainerId+' .graphina_divi_table_frontend').html('There are some issues to get data; please recheck settings');
                            }
                        },
                        error: function(jqXHR, textStatus, errorThrown) {
                            console.log("AJAX request failed!");
                            console.log(textStatus + ": " + errorThrown);
                        }
                    });

                 }
                 );
        </script>

        <?php
            return ob_get_clean();
        }
        
    }

    new GRDI_Datatable;
