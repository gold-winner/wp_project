<?php
class GRDI_Piechart extends ET_Builder_Module {

	protected $module_credits = array(
		'module_uri' => '',
		'author'     => '',
		'author_uri' => '',
	);
	public $slug       = 'grdi_pie_chart';
	public $vb_support = 'on';
    public $type = 'pie';
    public $icon_path ;


	public function init() {

        $this->icon_path = plugin_dir_path( __FILE__ ) . 'icon.svg';
		$this->name = __( 'Pie Chart', 'grdi-graphina-divi' );
        $this->_use_unique_id  = true;

		$this->settings_modal_toggles = array(
			'general'  => array(
                'toggles' => array(
                    'card_setting' => __('Card Settings', 'grdi-graphina-divi'),
                    'chart_data' => __('Chart Data Settings', 'grdi-graphina-divi'),
                    'main_content' => __('Basic Chart Settings', 'grdi-graphina-divi'),
                    'data_series' => __('Data', 'grdi-graphina-divi'),
                    'chart_title' => __('Chart Title', 'grdi-graphina-divi'),
                    'tooltip' => __('Tooltip', 'grdi-graphina-divi'),
                    'datalabel' => __('Data Labels', 'grdi-graphina-divi'),
                    'legend' => __('Legend Settings', 'grdi-graphina-divi'),
                ),
			),
		);

        $this->help_videos = array(
            array(
                'id'   => 'K26IdPhgqyI',
                'name' => esc_html__( 'An introduction to the Graphina Pie Chart module', 'grdi-graphina-divi' ),
            ),
        );
	}

	public function get_fields() {
        $field = [];
        // card setting
        $field = array_merge($field,graphinadiviCardSetting($this->type));
        // chart height and color
        $field = array_merge($field,graphinaDiviChartHeightColorSetting($this->type));
        // chart Toolbar setting
        $field = array_merge($field,graphinaDiviToolbarSetting($this->type));
        //chart plotoption setting
        $field = array_merge($field,graphinaDiviChartPlotoptionSetting($this->type));
        //chart animation setting
        $field = array_merge($field,graphinaDiviAnimationSetting($this->type));
        //chart Title setting
        $field = array_merge($field,graphinaDiviChartTitleSetting($this->type));
        //chart tooltip setting
        $field = array_merge($field,graphinaDiviChartToolTip($this->type));
        //chart datalabel setting
        $field = array_merge($field,graphinaDiviDataLabelSetting($this->type));
        //chart legend setting
        $field = array_merge($field,graphinaDiviLegendSetting($this->type));
        //chart data setting
        $field = array_merge($field,graphinaDiviChartDataSetting($this->type));
        return $field;
	}

	public function get_advanced_fields_config() {
		return array();
	}
	
	public function render( $attrs, $content, $render_slug ) {

		/* add external js & css */
        graphinaDiviLoadModuleScript($this->type);

		/* Basic Chart Options */
        $chart_height   = $this->props['chart_height'];
		$chart_bg_color = $this->props['chart_bg_color'];
		$animation = $this->props['animation'];
		$animatiuonSpeed = $this->props['animation_speed'];

		/* toolbar */
		$toolbar = $this->props['toolbar'];
		$toolbar_offset_x = $this->props['toolbar_offset_x'];
		$toolbar_offset_y = $this->props['toolbar_offset_y'];

		/* datalabels  */
		$data_label = $this->props['data_label'];
		$data_label_fontsize = $this->props['datalabel_fontsize'];
		$data_label_color = $this->props['datalabel_color'];
		$datalabel_showbg = $this->props['datalabel_showbg'];
		$datalabel_boderColor = $this->props['datalabel_bodercolor'];

		/* legend */
		$legend = $this->props['legend_show'];
		$legend_color  = $this->props['lenend_color'];
		$legend_fontsize  = $this->props['lenend_fontsize'];
		$legendPosition = $this->props['legend_position'];
		$legendAlignment = $this->props['legend_alignment'];

		/* plotoptions */
		$label_show = $this->props['label_show'];
		$value_show = $this->props['value_show'];
		$total_show = $this->props['total_show'];
		$total_show_always = $this->props['total_show_always'];
		$total_title = $this->props['total_title'];
		$label_fontsize = $this->props['label_fontsize'];
		$label_color = $this->props['label_color'];
		$value_fontsize = $this->props['labelvalue_fontsize'];
        $element_count = $this->props['element_count'];
        
        $data = ['series' => [], 'category' => []];
        if($this->props['data_type'] === 'manual'){
            if(isset($this->props['data_element_name'])){
                $data['series'] =
                     explode(',',str_replace('\n','',wp_strip_all_tags($this->props['data_element_name'])));
                
            }else{
                $data['series'] = [20, 50, 53, 15, 23, 15];
            }

            /* category data */

            if(!empty($this->props['category'])){
                $data['category'] = explode(',',str_replace('\n','',wp_strip_all_tags($this->props['category'])));
            }else{
                $data['category'] = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
            }
        }
              

        $colorArray = [];
        if(!empty($this->props['element_count'])){
            $element_count = $this->props['element_count'];
            for($i = 1;$i <= $element_count;$i++){
                $colorArray[]=!empty($this->props['fill_color'.$i]) ? $this->props['fill_color'.$i] : '#e53efc';
            }
        }

        $colorArray = implode('_,_', array_map('esc_html', $colorArray));
        $category = implode('_,_', array_map('esc_html', $data['category']));
        $series = implode('_,_', array_map('esc_html', $data['series']));
        $chartID = !empty($this->props['chart_id']) ? esc_html($this->props['chart_id']) : graphinaDiviGenerateRandomString($this->type, esc_html($this->render_count()));
        ob_start();
        graphinaDiviCommonChartHtml($this, $chartID);
        ?>
        <script>
            document.addEventListener('readystatechange', event => {
                if (event.target.readyState === "complete") {
                    var options = {
                        series: <?php echo et_core_esc_previously(wp_json_encode($series));  ?>.split('_,_').map(catData => parseInt(catData)),
                        chart: {
                            type: "pie",
                            background: '<?php echo esc_html($chart_bg_color); ?>',
                            height: parseInt('<?php echo esc_html($chart_height); ?>'),
                            animations: {
                                enabled: <?php echo esc_html($animation); ?>,
                                easing: 'easeinout',
                                speed: parseInt('<?php echo esc_html($animatiuonSpeed); ?>'),
                            },
                            toolbar: {
                                show: <?php echo esc_html($toolbar); ?>,
                                offsetX: '<?php echo esc_html($toolbar_offset_x); ?>',
                                offsetY: '<?php echo esc_html($toolbar_offset_y); ?>',
                                tools: {
                                    download: true,
                                    reset: true,
                                },
                                export: {
                                    svg: {
                                        filename: 'graphina-charts',
                                    },
                                    png: {
                                        filename: 'graphina-charts',
                                    },
                                    csv: {
                                        filename: 'graphina-charts',
                                        columnDelimiter: ",",
                                        dateFormatter(timestamp) {
                                            return new Date(timestamp).toDateString()
                                        }
                                    },
                                }
                            },
                        },
                        noData: {
                            text: '<?php echo esc_html__('Loading...', 'grdi-graphina-divi'); ?>',
                            align: 'center',
                            verticalAlign: 'middle',
                        },
                        title: {
                            text: '<?php echo esc_html($this->props['chart_title']); ?>',
                            align:'<?php echo esc_html($this->props['title_alignment']); ?>',
                            floating: false,
                            style: {
                                fontSize:'<?php echo esc_html($this->props['chart_title_fontsize']); ?>',
                                color: '<?php echo esc_html($this->props['chart_title_color']);?>',
                            }
                        },
                        labels: '<?php echo wp_kses_post($category); ?>'.split('_,_'),
                        dataLabels: {
                            enabled:<?php echo esc_html($data_label); ?>,
                            style: {
                                fontSize: '<?php echo esc_html($data_label_fontsize); ?>',
                            },
                            background: {
                                enabled:<?php echo esc_html($datalabel_showbg); ?>,
                                foreColor: '<?php echo esc_html($data_label_color); ?>',
                                borderColor: '<?php echo esc_html($datalabel_boderColor); ?>',
                            },
                            formatter: function (val, opt) {
                                val = opt.w.config.series[opt.seriesIndex]
                                if (!val) {
                                    return val;
                                }
                                let decimal = parseInt('<?php echo !empty(esc_js($this->props['datalabel_decimal_point'])) ? esc_js($this->props['datalabel_decimal_point']) : 0 ?>') || 0;
                                if ('<?php echo  esc_js(!empty($this->props['datalabel_percentage']) && $this->props['datalabel_percentage'] === 'true') ?>') {
                                    let totals = opt.w.globals.seriesTotals.reduce((a, b) => {
                                        return a + b;
                                    }, 0)
                                    return parseFloat((val / totals) * 100).toFixed(parseInt(decimal)) + '%'
                                }
                                if('<?php echo esc_js(!empty($this->props['datalabel_thousand_seperator_enable'])  && $this->props['datalabel_thousand_seperator_enable'] === 'on'); ?>'){
                                    val = graphinaDiviNumberThousandSeperate(val,decimal)
                                }else{
                                    val = parseFloat(val).toFixed(decimal)
                                }
                                return '<?php echo esc_html($this->props['datalabel_label_prefix']);?>' + val + '<?php echo esc_html($this->props['datalabel_label_postfix']);?>'
                            },
                        },
                        legend: {
                            show: <?php echo esc_html($legend); ?>,
                            showForSingleSeries: true,
                            position: '<?php echo esc_html($legendPosition);?>',
                            horizontalAlign: '<?php echo esc_html($legendAlignment);?>',
                            fontSize: '<?php echo esc_html($legend_fontsize); ?>',
                            labels: {
                                colors: '<?php echo esc_html($legend_color);?>',
                            }
                        },
                        plotOptions: {
                            pie: {
                                donut: {
                                    labels: {
                                        show: <?php echo esc_html($label_show); ?>,
                                        value: {
                                            show: <?php echo esc_html($value_show); ?>,
                                            fontSize: '<?php echo esc_html($value_fontsize); ?>',
                                        },
                                        total: {
                                            show: true,
                                            showAlways: <?php echo esc_html($total_show_always); ?>,
                                            label: '<?php echo esc_html($total_title); ?>',
                                            fontSize: '<?php echo esc_html($label_fontsize); ?>',
                                            color: '<?php echo esc_html($label_color); ?>',
                                        },
                                        name: {
                                            show: <?php echo esc_html($total_show); ?>,
                                        }
                                    }
                                }
                            }
                        },
                        tooltip: {
                            enabled: <?php echo esc_html($this->props['tooltip']); ?>,
                            theme: '<?php echo esc_html($this->props['tooltip_theme']); ?>',
                            style: {
                                fontSize: "14px",
                            },
                        },
                        colors: '<?php echo esc_html(esc_js($colorArray)); ?>'.split('_,_'),
                        fill: {
                            type:'classic',
                            colors:'<?php echo esc_html(esc_js($colorArray)); ?>'.split('_,_'),
                        },
                    };
                    var element = document.querySelector('<?php echo '#'.esc_html($chartID); ?>');
                    if(typeof graphinaDiviRenderChart !== "undefined"){
                        graphinaDiviRenderChart(
                            element,
                            {
                                ele: element,
                                options: options,
                                animation: <?php echo esc_html($animation); ?>,
                                type: '<?php echo esc_html($this->type); ?>',
                                series:'<?php echo(esc_html($series));?>'.split('_,_').map(catData => parseInt(catData)),
                                category:'<?php echo esc_html($category); ?>'.split('_,_').map(catData => catData.split('[,]'))
                            },
                            '<?php echo esc_html($this->type); ?>',
                            '<?php echo esc_html($chartID); ?>'
                        )
                    }
                    if (typeof graphinaDiviDynamicData !== "undefined") {
                        graphinaDiviDynamicData(
                                  <?php echo wp_json_encode($this->props); ?>,
                            '<?php echo esc_html($this->type); ?>',
                            '<?php echo esc_html($chartID); ?>',
                            '<?php echo !empty(esc_html($this->props['ajax_reload'])) && esc_html($this->props['ajax_reload']) === 'true' ? 'true' :'false' ?>',
                            '<?php echo  !empty(esc_html($this->props['ajax_reload_time'])) && esc_html($this->props['ajax_reload_time']) != 0 ? esc_html($this->props['ajax_reload_time']) : 5 ?>')
                    }
                }
            });
        </script>
        <?php
        return ob_get_clean();
        
	}
}
new GRDI_Piechart;
