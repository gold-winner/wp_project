<?php

namespace GRDIGraphina;

use mysql_xdevapi\Exception;

defined( 'ABSPATH' ) || die();

class GRDIAssetsManager {

    public function __construct(){
        add_action('wp_enqueue_scripts', array($this, 'grdi_enqueue_assets'));
        add_action( 'wp_ajax_graphina_divi_get_dynamic_data',  array($this,'graphina_divi_get_dynamic_data') );
        add_action( 'wp_ajax_nopriv_graphina_divi_get_dynamic_data',  array($this,'graphina_divi_get_dynamic_data') );
        add_action('wp_ajax_get_jquery_datatable_data', array($this, 'get_jquery_datatable_data'));
        add_action('wp_ajax_nopriv_get_jquery_datatable_data', array($this, 'get_jquery_datatable_data'));
        add_action('wp_ajax_get_jquery_datatable_data_fe', array($this, 'get_jquery_datatable_data_fe'));
        add_action('wp_ajax_nopriv_get_jquery_datatable_data_fe', array($this, 'get_jquery_datatable_data_fe'));
        add_action('admin_enqueue_scripts', array($this, 'graphina_divi_cstm_sqljs'),10);
        add_action( 'wp_ajax_extractTableName',  array($this,'extractTableName_cstm'),10 );
        add_action( 'wp_ajax_nopriv_extractTableName',  array($this,'extractTableName_cstm'),10 );
        add_action( 'wp_ajax_savetabledata_divigraph',  array($this,'savetabledata_divigraph') );
        add_action( 'wp_ajax_nopriv_savetabledata_divigraph',  array($this,'savetabledata_divigraph') );
        add_action( 'wp_ajax_get_manual_data_inprv',  array($this,'get_manual_data_inprv') );
        add_action( 'wp_ajax_nopriv_get_manual_data_inprv',  array($this,'get_manual_data_inprv') );
    }   
    
    public function graphina_divi_cstm_sqljs() {
        $nonce = wp_create_nonce('get_graphina_chart_settings');
        wp_enqueue_script('custom-admin-script', GRAPHINA_DIVI_BASE_URL . 'scripts/cstm_sql.js?' . time(), array('jquery'), '1.0.0', true);
        wp_localize_script('custom-admin-script', 'graphina_divi_localize', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => $nonce // Pass nonce to JavaScript
        ));
    }
    
    public function extractTableName_cstm() {
        check_ajax_referer('get_graphina_chart_settings', 'security'); // Verify nonce
    
        if (isset($_POST['input_value'])) {
            global $wpdb;
            $query_ = sanitize_text_field($_POST['input_value']); // Sanitize input
    
            $pattern = '/(?:FROM|JOIN)\s+`?([a-zA-Z0-9_]+)`?/i';
            if (preg_match($pattern, $query_, $matches)) {
                $table_name = $matches[1];
                $sql = $wpdb->prepare("SHOW TABLES LIKE %s", $wpdb->esc_like($table_name . '%'));
                // phpcs:ignore
                $table_exists = $wpdb->get_var($sql);
    
                $response = array(); // Create an empty array to hold the response data
    
                if ($table_exists) {
                    $response['table_name'] = $table_name;
                }
    
                // Set the response content type to JSON
                header('Content-Type: application/json');
    
                // Encode the response data as JSON and echo it
                echo wp_json_encode($response);
            }
        }
        wp_die();
    }
    public function get_manual_data_inprv() {
        check_ajax_referer('get_graphina_chart_settings', 'security');
    
        $response = [
            'status' => false,
        ];
    
        if (isset($_POST['id'])) {
            $table_id = sanitize_text_field(wp_unslash($_POST['id']));
            $page_id = sanitize_text_field(wp_unslash(isset($_POST['page_id']) ? $_POST['page_id'] : ''));
            if ($table_id) {
                // phpcs:ignore
                $table_data = unserialize(get_post_meta(intval($page_id),'graphinatablesave_data_'.$table_id,true));
                $table_data = json_decode($table_data, true);
                if ($table_data && isset($table_data['body']) && isset($table_data['headers'])) {
                    $response = [
                        'status' => true,
                        'table_id' => $table_id,
                        'data' => [
                            'header' => $table_data['headers'],
                            'body' => $table_data['body'],
                        ],
                    ];
                } else {
                    $response = [
                        'status' => true,
                        'table_id' => $table_id,
                        'data'  => [
                            'header' => [],
                            'body' => $table_data['body'],
                        ]
                    ];
                }
            }
        }
    
        wp_send_json($response);
    }
    


    
        
        public function get_jquery_datatable_data() {
            check_ajax_referer('get_graphina_chart_settings', 'security');

            if (isset($_POST['action']) && $_POST['action'] == 'get_jquery_datatable_data') {
                try {
                    $msets = isset($_POST['setting']) ? stripslashes($_POST['setting']) : ''; // phpcs:ignore ET.Sniffs.ValidatedSanitizedInput.InputNotSanitized
                    $settings = json_decode($msets, true);
                    $id = $settings['_unique_id'];
                    $type = 'datatable';
                    $dataOption = $settings['data_type'];
                    $data = [];
        
                    $this->settings = $settings;
                    $msp = array('rows'=> $settings['no_of_rows'],
                                'cols'=>$settings['no_of_columns']
                            );

        
                    switch ($dataOption) {
                        case "manual" :
                            $manual_data = isset($_POST['current_data']) ? $_POST['current_data'] : ''; // phpcs:ignore ET.Sniffs.ValidatedSanitizedInput.InputNotSanitized
                            $data = graphinadivimanualdatasave($manual_data,$id);
                            case "dynamic": 
                            $dataType = $settings['dynamic_data_type'];
                            switch ($dataType) {
                                case "csv": 
                                    $csvFilePath = $settings['csv_url'];
                                    $data = graphinaDiviCsv($csvFilePath ,$msp);
                                    break;
                                case "google-sheet":
                                    $googleSheetId = $settings['googlesheet_url'];
                                    $data = grploadGoogleSheetData($googleSheetId,$msp);
                                    break;
                                case "remote-csv":
                                    $remoteCsvUrl = $settings['remote_csv_url'];
                                    $data = grploadGoogleSheetData($remoteCsvUrl,$msp);
                                    break;
                                case "api":
                                    $apiUrl = $settings['api_url'];
                                    $authrization_token_enable = $settings['authrization_token_enable'];
                                    $api_header_key = $settings['api_header_key'];
                                    $api_header_token = $settings['api_header_token'];
                                    $data = graphinsfetchDataFromApi($apiUrl,$authrization_token_enable,$api_header_key,$api_header_token,$msp);
                                    break;
                                case "database":
                                    $tableName = $settings['table_name'];
                                    $data = graphretrieveTableData($tableName,$msp);
                                    break;
                            }
                            break;
                    }
                    if (empty($data) || !is_array($data)) {
                        wp_send_json([
                            'status' => false,
                            'table_id' => '#table',
                            'data' => [
                                'header' => ['Name'],
                                'body' => [['Junaid']]
                            ]
                        ]);
                        die;
                    }
        
                    wp_send_json([
                        'status' => true,
                        'table_id' => $id,
                        'data' => [
                            'header' => $data['header'],
                            'body' => $data['body'],
                        ]
                    ]);
                    die;
                } catch (Exception $exception) {
                    wp_send_json([
                        'status' => false,
                        'table_id' => $id,
                        'data' => [
                            'header' => [],
                            'body' => []
                        ]
                    ]);
                    die;
                }
            }
        }
        
        public function get_jquery_datatable_data_fe(){
            check_ajax_referer('get_graphina_chart_settings', 'security');
            if (isset($_POST['action']) && $_POST['action'] == 'get_jquery_datatable_data_fe') {
                try {
                    $type = 'datatable';
                    $dataOption = isset($_POST['fields']['data_type']) ? sanitize_text_field($_POST['fields']['data_type']) : '';
                    $data = [];
                    $page_id = sanitize_text_field(wp_unslash(isset($_POST['page_id']) ? $_POST['page_id'] : ''));
                    $chart_id = isset($_POST['fields']['_unique_id']) ? sanitize_text_field($_POST['fields']['_unique_id']) : '';
                    $settings = array(
                        'show_header' => isset($_POST['fields']['show_header']) ? sanitize_text_field($_POST['fields']['show_header']) : '',
                        'no_of_columns' => isset($_POST['fields']['no_of_columns']) ? sanitize_text_field($_POST['fields']['no_of_columns']) : '',
                        'no_of_rows' => isset($_POST['fields']['no_of_rows']) ? sanitize_text_field($_POST['fields']['no_of_rows']) : '',
                        'table_search' => isset($_POST['fields']['table_search']) ? sanitize_text_field($_POST['fields']['table_search']) : '',
                        'restricted_content_access' => isset($_POST['fields']['restricted_content_access']) ? sanitize_text_field($_POST['fields']['restricted_content_access']) : '',
                        'username' => isset($_POST['fields']['user_names']) ? sanitize_text_field($_POST['fields']['user_names']) : '',
                        'useroles' => isset($_POST['fields']['user_roles']) ? sanitize_text_field($_POST['fields']['user_roles']) : '',
                        'password' => isset($_POST['fields']['password']) ? sanitize_text_field($_POST['fields']['password']) : '',
                        'cardcolor' => isset($_POST['fields']['card_color']) ? sanitize_text_field($_POST['fields']['card_color']) : '',
                        'csv_url' => isset($_POST['fields']['csv_url']) ? esc_url_raw($_POST['fields']['csv_url']) : '',
                        'googlesheet_url' => isset($_POST['fields']['googlesheet_url']) ? esc_url_raw($_POST['fields']['googlesheet_url']) : '',
                        'remote_csv_url' => isset($_POST['fields']['remote_csv_url']) ? esc_url_raw($_POST['fields']['remote_csv_url']) : '',
                        'api_url' => isset($_POST['fields']['api_url']) ? esc_url_raw($_POST['fields']['api_url']) : '',
                        'table_name' => isset($_POST['fields']['table_name']) ? sanitize_text_field($_POST['fields']['table_name']) : '',
                        'authrization_token_enable' => isset($_POST['fields']['authrization_token_enable']) ? sanitize_text_field($_POST['fields']['authrization_token_enable']) : '',
                        'api_header_key' => isset($_POST['fields']['api_header_key']) ? sanitize_text_field($_POST['fields']['api_header_key']) : '',
                        'api_header_token' => isset($_POST['fields']['api_header_token']) ? sanitize_text_field($_POST['fields']['api_header_token']) : '',
                    );
                    
                    switch ($dataOption) {
                        case 'manual' :
                            $data = graphinadivi_manual_preview($chart_id,$page_id);
                            break;
                        case "dynamic": 
                            $dataType = isset($_POST['fields']['dynamic_data_type']) ? $_POST['fields']['dynamic_data_type'] : ''; // phpcs:ignore ET.Sniffs.ValidatedSanitizedInput.InputNotSanitized
                        
                            switch ($dataType) {
                                case "csv": 
                                    $csvFilePath = $settings['csv_url'];
                                    $data = graphinaDiviCsv_preview($csvFilePath ,$settings);
                                    break;
                                case "google-sheet":
                                    $googleSheetId = $settings['googlesheet_url'];
                                    $data = grploadGoogleSheetData_prview($googleSheetId,$settings);
                                    break;
                                case "remote-csv":
                                    $remoteCsvUrl = $settings['remote_csv_url'];
                                    $data = grploadGoogleSheetData_prview($remoteCsvUrl,$settings);
                                    break;
                                case "api":
                                    $apiUrl = $settings['api_url'];
                                    $authrization_token_enable = $settings['authrization_token_enable'];
                                    $api_header_key = $settings['api_header_key'];
                                    $api_header_token = $settings['api_header_token'];
                                    $data = graphinsfetchDataFromApi_preview($apiUrl,$settings);
                                    break;
                                case "database":
                                    $tableName = $settings['table_name'];
                                    $data = graphretrieveTableData_frontnd($tableName,$settings);
                                    break;
                            }
                            break;
                    }
        
                    if (empty($data) || !is_array($data)) {
                        wp_send_json([
                            'status' => false,
                            'table_id' => '#table',
                            'data' => [
                                'header' => ['Name'],
                                'body' => [['Junaid']]
                            ]
                        ]);
                        die;
                    }
                    wp_send_json([
                        'status' => true,
                        'table_id' => $chart_id,
                        'data' => [ 
                            'header' => $data['header'],
                            'body' => $data['body'],
                        ]
                    ]);
                    die;
                } catch (Exception $exception) {
                    wp_send_json([
                        'status' => false,
                        'table_id' => $chart_id,
                        'data' => [
                            'header' => [],
                            'body' => []
                        ]
                    ]);
                    die;
                }
            }
            
        }
        public function graphina_divi_get_dynamic_data() {
            check_ajax_referer('get_graphina_chart_settings', 'security');
            $googlechart_data = [];
            $instantInit = $filterEnable = false;
            $colors = [];
        
            try {
                $dataType = isset($_POST['dataType']) && $_POST['dataType'] === 'simple' ? 'simple' : 'json';
                if(isset($_POST['setting'])){
                    $settings = $dataType === 'simple' ? $_POST['setting'] : json_decode(wp_unslash($_POST['setting']), true); // phpcs:ignore ET.Sniffs.ValidatedSanitizedInput.InputNotSanitized
                }
        
                $type = isset($_POST['type']) ? sanitize_text_field(wp_unslash($_POST['type'])) : '';
                $id = !empty($_POST['id']) ? sanitize_text_field(wp_unslash($_POST['id'])) : '';
        
                $data = graphinaDiviGetChartDynamicData($settings, $type, $id);
        
                if (in_array($type, ['gauge_google', 'geo_google'])) {
                    foreach ($data['category'] as $key => $value) {
                        if( empty($key) && empty($value)) continue;
                        $googlechart_data[$key] = [
                            sanitize_text_field(wp_unslash($value)),
                            (int)sanitize_text_field(wp_unslash($data['series'][$key]))
                        ];
                    }
                    if ($type === 'geo_google') {
                        $colors = array_fill(0, count($googlechart_data), sanitize_text_field(wp_unslash($settings['geo_default_color'])));
                    }
                }
        
                if ($type === 'distributed_column') {
                    $data['series'] = !empty($data['series'][0]) ? [wp_unslash($data['series'][0])] : []; 
                }
        
                if ((!empty($data['fail']) && $data['fail'] === 'permission') || (!empty($data['sql_fail']))) {
                    wp_send_json(['status' => false, 'googlechart_data' => $googlechart_data, 'instant_init' => $instantInit, 'fail_message' => !empty($data['fail_message']) ? sanitize_text_field(wp_unslash($data['fail_message'])) : '', 'chart_id' => $id, 'color' => $colors]);
                    die;
                }
        
                wp_send_json(['status' => true, 'googlechart_data' => $googlechart_data, 'instant_init' => $instantInit, 'fail_message' => '', 'chart_id' => $id, 'data' => $data, 'filterEnable' => $filterEnable, 'color' => $colors]);
                die;
            } catch (Exception $e) {
                wp_send_json(['status' => false, 'googlechart_data' => $googlechart_data, 'instant_init' => $instantInit, 'fail_message' => '', 'chart_id' => -1, 'color' => $colors]);
                die;
            }
        }
        
        public function savetabledata_divigraph() {
            check_ajax_referer('get_graphina_chart_settings', 'security');
            if (isset($_POST['id'], $_POST['current_data'])) {
                $tableid = sanitize_text_field(wp_unslash($_POST['id']));
                if(isset($_POST['current_data']['headers'])){
                    // phpcs:ignore
                    $_POST['current_data']['headers'] = array_map('sanitize_text_field',$_POST['current_data']['headers']);
                }
                $_POST['current_data']['body'] = array_map(function($body){
                    // phpcs:ignore
                    return array_map('sanitize_text_field',$body);
                    // phpcs:ignores
                },isset($_POST['current_data']['body']) ? $_POST['current_data']['body'] : '');
                // phpcs:ignore
                $tablecontent = wp_unslash(wp_json_encode($_POST['current_data']));
        
                if ($tableid && isset($_POST['page_id'])) {
                    $page_id = sanitize_text_field(wp_unslash(isset($_POST['page_id']) ? $_POST['page_id'] : ''));
                    // phpcs:ignore
                    $save_or_not = update_post_meta(intval($page_id),'graphinatablesave_data_'.$tableid,serialize($tablecontent));
                }
        
                wp_die();
            }
        }
        
    public function get_scripts() {
        $data =  array(
            'graphina_apex_chart_script' =>  array(
                'src'           =>  GRAPHINA_DIVI_BASE_URL . 'scripts/apexcharts.min.js',
                'version'       =>  GRAPHINA_DIVI_VERSION,
                'deps'          =>  array( 'jquery' ),
                'enqueue'       =>  false,
                'footer'        =>  true,
                'type'          => 'script'
            ),
            'graphina_divi_datatable_save' => array(
                'src'           =>  GRAPHINA_DIVI_BASE_URL . 'scripts/datatable_cstm.js',
                'version'       =>  GRAPHINA_DIVI_VERSION,
                'deps'          =>  array( 'jquery' ),
                'enqueue'       =>  true,
                'footer'        =>  true,
                'type'          => 'script'
            ),
            'graphina_divi_counter' =>  array(
                'src'           =>  GRAPHINA_DIVI_BASE_URL . 'scripts/jquery-numerator.js',
                'version'       =>  GRAPHINA_DIVI_VERSION,
                'deps'          =>  array( 'jquery' ),
                'enqueue'       =>  false,
                'footer'        =>  true,
                'type'          => 'script'
            ),
            'graphina-divi-common-public' =>  array(
                'src'           =>  GRAPHINA_DIVI_BASE_URL . 'scripts/graphina-divi-common.js',
                'version'       =>  GRAPHINA_DIVI_VERSION,
                'deps'          =>  array( 'jquery' ),
                'enqueue'       =>  false,
                'footer'        =>  true,
                'type'          => 'script'
            ),
            'graphina_divi_google_chart_script' =>  array(
                'src'           =>  GRAPHINA_DIVI_BASE_URL . 'scripts/loader.js',
                'version'       =>  GRAPHINA_DIVI_VERSION,
                'deps'          =>  array( 'jquery' ),
                'enqueue'       =>  false,
                'footer'        =>  true,
                'type'          => 'script'
            ),
            'graphina_divi_style'         =>  array(
                'src'               =>  GRAPHINA_DIVI_BASE_URL . 'styles/style.css',
                'version'           =>  GRAPHINA_DIVI_VERSION,
                'deps'              =>  array( ),
                'enqueue'           =>  false,
                'footer'            =>  true,
                'type'              => 'style'
            ),
            'graphina_datatable_style'         =>  array(
                'src'               =>  GRAPHINA_DIVI_BASE_URL . 'includes/css/jquery-datatable/graphina_datatable_style.css',
                'version'           =>  GRAPHINA_DIVI_VERSION,
                'deps'              =>  array( ),
                'enqueue'           =>  false,
                'footer'            =>  true,
                'type'              => 'style'
            ),
            'graphina_datatable_button_style'         =>  array(
                'src'               =>  GRAPHINA_DIVI_BASE_URL . 'includes/css/jquery-datatable/graphina_datatable_button_style.css',
                'version'           =>  GRAPHINA_DIVI_VERSION,
                'deps'              =>  array( ),
                'enqueue'           =>  false,
                'footer'            =>  true,
                'type'              => 'style'
            ),
            'graphina_datatable_responsive_css'         =>  array(
                'src'               =>  GRAPHINA_DIVI_BASE_URL . 'includes/css/jquery-datatable/graphina_datatable_responsive_css.css',
                'version'           =>  GRAPHINA_DIVI_VERSION,
                'deps'              =>  array( ),
                'enqueue'           =>  false,
                'footer'            =>  true,
                'type'              => 'style'
            ),
            'graphina_datatables' =>  array(
                'src'           =>  GRAPHINA_DIVI_BASE_URL . 'includes/js/jquery-datatable/graphina_datatables.min.js',
                'version'       =>  GRAPHINA_DIVI_VERSION,
                'deps'          =>  array( 'jquery' ),
                'enqueue'       =>  true,
                'footer'        =>  true,
                'type'          => 'script'
            ),       
            'graphina_datatable_button' =>  array(
                'src'           =>  GRAPHINA_DIVI_BASE_URL . 'includes/js/jquery-datatable/graphina_datatable_button.js',
                'version'       =>  GRAPHINA_DIVI_VERSION,
                'deps'          =>  array( 'jquery' ),
                'enqueue'       =>  true,
                'footer'        =>  true,
                'type'          => 'script'
            ),
            'graphina_datatables_button_print' =>  array(
                'src'           =>  GRAPHINA_DIVI_BASE_URL . 'includes/js/jquery-datatable/graphina_datatables_button_print.js',
                'version'       =>  GRAPHINA_DIVI_VERSION,
                'deps'          =>  array( 'jquery' ),
                'enqueue'       =>  true,
                'footer'        =>  true,
                'type'          => 'script'
            ),
            'graphina_datatables_row_responsive' =>  array(
                'src'           =>  GRAPHINA_DIVI_BASE_URL . 'includes/js/jquery-datatable/graphina_datatables_row_responsive.js',
                'version'       =>  GRAPHINA_DIVI_VERSION,
                'deps'          =>  array( 'jquery' ),
                'enqueue'       =>  true,
                'footer'        =>  true,
                'type'          => 'script'
            ),
            'graphina_datatables_rowreorder' =>  array(
                'src'           =>  GRAPHINA_DIVI_BASE_URL . 'includes/js/jquery-datatable/graphina_datatables_rowreorder.js',
                'version'       =>  GRAPHINA_DIVI_VERSION,
                'deps'          =>  array( 'jquery' ),
                'enqueue'       =>  true,
                'footer'        =>  true,
                'type'          => 'script'
            ),
            'graphina_datatable_button_flash' =>  array(
                'src'           =>  GRAPHINA_DIVI_BASE_URL . 'includes/js/jquery-datatable/graphina_datatable_button_flash.js',
                'version'       =>  GRAPHINA_DIVI_VERSION,
                'deps'          =>  array( 'jquery' ),
                'enqueue'       =>  true,
                'footer'        =>  true,
                'type'          => 'script'
            ),
            'graphina_datatable_button_html' =>  array(
                'src'           =>  GRAPHINA_DIVI_BASE_URL . 'includes/js/jquery-datatable/graphina_datatable_html.js',
                'version'       =>  GRAPHINA_DIVI_VERSION,
                'deps'          =>  array( 'jquery' ),
                'enqueue'       =>  true,
                'footer'        =>  true,
                'type'          => 'script'
            ),
            'graphina_datatable_button_zip' =>  array(
                'src'           =>  GRAPHINA_DIVI_BASE_URL . 'includes/js/jquery-datatable/graphina_datatable_zip.js',
                'version'       =>  GRAPHINA_DIVI_VERSION,
                'deps'          =>  array( 'jquery' ),
                'enqueue'       =>  true,
                'footer'        =>  true,
                'type'          => 'script'
            ),
            'graphina_datatable_button_pdf' =>  array(
                'src'           =>  GRAPHINA_DIVI_BASE_URL . 'includes/js/jquery-datatable/graphina_datatable_pdf.js',
                'version'       =>  GRAPHINA_DIVI_VERSION,
                'deps'          =>  array( 'jquery' ),
                'enqueue'       =>  true,
                'footer'        =>  true,
                'type'          => 'script'
            ),
            'graphina_datatable_button_font' =>  array(
                'src'           =>  GRAPHINA_DIVI_BASE_URL . 'includes/js/jquery-datatable/graphina_datatable_font.js',
                'version'       =>  GRAPHINA_DIVI_VERSION,
                'deps'          =>  array( 'jquery' ),
                'enqueue'       =>  true,
                'footer'        =>  true,
                'type'          => 'script'
            ),
            'graphina_datatable_button_colvis' =>  array(
                'src'           =>  GRAPHINA_DIVI_BASE_URL . 'includes/js/jquery-datatable/graphina_datatable_colvis.js',
                'version'       =>  GRAPHINA_DIVI_VERSION,
                'deps'          =>  array( 'jquery' ),
                'enqueue'       =>  true,
                'footer'        =>  true,
                'type'          => 'script'
            ), 
        );
        if(!empty($_GET['et_fb'])){ //phpcs:ignore WordPress.Security.NonceVerification.Recommended
//            $data['graphina-divi-public']  =  array(
//                'src'           =>  GRAPHINA_DIVI_BASE_URL . 'scripts/frontend-bundle.min.js',
//                'version'       =>  GRAPHINA_DIVI_VERSION,
//                'deps'          =>  array( 'jquery' ),
//                'enqueue'       =>  true,
//                'footer'        =>  false,
//                'type'          => 'script'
//            );
            $data['graphina-divi-common-public']['footer']  =  false;
            $data['graphina-divi-common-public']['enqueue'] = true;
            $data['graphina_divi_style']['enqueue'] = true;
            $data['graphina_divi_style']['footer'] = false;
            $data['graphina_divi_counter']['enqueue'] = true;
            $data['graphina_divi_counter']['footer'] = false;
        }
        return $data;
    }

    public function grdi_enqueue_assets() {

        $scripts  = $this->get_scripts();

        foreach ($scripts as $handle => $script ) {

            $deps   = !empty( $script['deps'] ) ? $script['deps']  : false;

            $wp_enqueue_type = !empty($script['type'])  && $script['type'] == 'style' ? 'wp_enqueue_style' : 'wp_enqueue_script';
            $wp_register_type = !empty($script['type'])  && $script['type'] == 'style' ? 'wp_register_style' : 'wp_register_script';

            if ( $script['enqueue'] ) {
                $wp_enqueue_type(  $handle, $script['src'], $deps, $script['version'], $script['footer'] );
            }else {
                $wp_register_type(  $handle, $script['src'], $deps, $script['version'], $script['footer'] );
            }

            if($handle === 'graphina-divi-common-public'){
                wp_localize_script('graphina-divi-common-public', 'graphina_divi_localize', array(
                    'ajaxurl' => admin_url('admin-ajax.php'),
                    'nonce' => wp_create_nonce('get_graphina_chart_settings'),
                    'graphinaAllGraphs' => [],
                    'graphinaAllGraphsOptions' => [],
                    'graphinaBlockCharts' => [],
                    'is_view_port_disable' => graphina_divi_common_setting_get('view_port'),
                    'thousand_seperator' => graphina_divi_common_setting_get('thousand_seperator')
                ));
            }
        }
    }    
}